# Pop-up și Aktionen – administrare și instalare IONOS

În meniul administratorului sunt două secțiuni independente, **Pop-up** și
**Aktionen**, în grupul MARKETING. Editorul pe pagini, prețurile, galeria,
statisticile, înscrierile, mesajele și administrarea utilizatorilor rămân disponibile.

## Pop-up

1. Apasă **Neues Pop-up**, apoi **Bild hochladen / ersetzen**.
2. Alege toate paginile, numai Startseite sau bifează paginile dorite.
3. Stabilește **Anzeigehäufigkeit**, perioada și prioritatea. Prioritatea mai mare
   apare prima; ferestrele se afișează succesiv.
4. Opțional, activează Countdown, alege ora finală, alinierea și distanța.
   Implicit, cronometrul este **sub imagine**, pentru a nu acoperi oferta.
5. Folosește Desktop / Tablet / Mobil și **Vorschau** înainte de publicare.
6. **Entwurf speichern** păstrează ciorna. **Veröffentlichen** publică versiunea
   curentă dacă opțiunea „Nach Veröffentlichung aktiv” este bifată.

Pop-up-ul public conține numai imaginea, butonul X și cronometrul opțional.
Imaginea nu este decupată sau deformată. Pentru o imagine foarte mică, un
countdown care nu ar încăpea lizibil peste imagine este mutat automat sub ea;
aceeași poziție se vede în previzualizare. Închiderea funcționează și cu Escape;
focusul tastaturii rămâne în fereastră.

Frecvențe:

- Bei jedem Besuch: o afișare la încărcarea paginii.
- Einmal pro Sitzung: o afișare pe sesiunea filei de browser, cu sessionStorage.
- Einmal täglich: o afișare pe zi calendaristică Europe/Berlin, cu localStorage.
- Einmal bis zum Ablauf: o afișare pe perioada campaniei, cu localStorage.

Identificatorul și intervalul campaniei separă evidența fiecărui pop-up.
O nouă perioadă pentru același pop-up reprezintă o campanie nouă. Dacă browserul
blochează stocarea, site-ul rămâne utilizabil și reține afișările în pagina curentă.
Publicarea unei imagini modificate nu redeschide forțat o campanie deja văzută.

Orele sunt interpretate în **Europe/Berlin**, inclusiv ora de vară. O oră
inexistentă la trecerea de primăvară este refuzată; pentru ora repetată toamna
se folosește a doua apariție. Countdown-ul este calculat din momentul final real,
se actualizează la fiecare secundă și rămâne la zero. Dacă perioada pop-up-ului
încă este activă, atingerea lui zero nu închide fereastra.

## Aktionen

**Neue Aktion** deschide instrumentele în stânga și previzualizarea privată în
pagina reală a site-ului, în dreapta. Sunt editabile titlul, descrierea, oferta,
prețurile, până la șase imagini, până la trei butoane și linkurile lor, culorile,
alinierea, poziția imaginilor, distanțele și colțurile rotunjite.

Poți alege o pagină sau mai multe. Standard, oferta apare după imaginea principală
sau înainte de subsol. „Position für einzelne Seiten anpassen” oferă și secțiunile
existente ale fiecărei pagini. Previzualizarea se derulează la oferta editată.
Modurile de previzualizare folosesc lățimi reale de 1200 / 768 / 390 px.

Reihenfolge controlează ordinea ofertelor: numerele mici apar primele. Modifică
numărul și publică oferta pentru a schimba ordinea publică. În lista ofertelor
există Bearbeiten, Duplizieren și Löschen. Copia este un draft inactiv.

Salvarea ciornei nu schimbă versiunea publicată. Poți reîncărca pagina și continua
editarea. Deaktivieren oprește versiunea publică; pentru reactivare bifează opțiunea
de activare și apasă Veröffentlichen. Ștergerea elimină ciorna și publicarea.

## Stocare, permisiuni și erori

- `private_admin/promotions.json`: ciorne și copii publicate separate, pentru
  ambele secțiuni, identificatori permanenți și versiunea stocării. Fișierul se
  creează automat la prima salvare; nu trebuie creat manual.
- `private_admin/promotions.lock`: blocare pentru salvări și curățarea imaginilor.
- `assets/uploads/promotions/`: imaginile promoționale, cu nume aleatoare.
- `admin/promotions-public.php`: furnizează numai versiunile publicate și active,
  niciodată ciornele. Perioadele sunt verificate și în browser, inclusiv cât timp
  pagina rămâne deschisă. Actualizările publicate/dezactivările sunt reîncărcate
  periodic, la cel mult aproximativ 30 de secunde; o încărcare nouă citește imediat
  versiunea curentă.

Fișierul existent site.json nu este rescris pentru salvarea promoțiilor. Astfel,
editarea promoțiilor nu suprascrie conținutul paginilor sau prețurile.
Salvările sunt atomice și verifică versiunea: dacă alt utilizator salvează între
timp, primești un mesaj, iar intrările din formular rămân disponibile. „Liste neu
laden” actualizează lista și versiunea fără să șteargă câmpurile nesalvate.

Accesul folosește autentificarea existentă. Administratorul și utilizatorii cu
rolul de editare a conținutului au acces la cele două secțiuni. Acțiunile API și
încărcările verifică permisiunile și CSRF pe server. Imaginile sunt verificate prin
MIME, getimagesize și limita PHP efectivă; SVG și fișierele executabile nu sunt
acceptate. Maximum 8 MB per imagine, sau limita mai mică impusă de hosting.

Imaginile înlocuite/șterse sunt eliminate numai când nu mai sunt referite de o
ciornă, o versiune publicată sau de configurația publică existentă. Copiile pot
folosi aceeași imagine în siguranță. Butonul de eliminare curăță și o încărcare
nouă încă nefolosită. Nu se șterg imaginile originale ale site-ului.

## Instalare prin Cyberduck pe IONOS

1. Descarcă o copie de rezervă a site-ului curent.
2. Dezarhivează ZIP-ul actualizării pe Mac.
3. În Cyberduck deschide directorul în care sunt index.html, admin și assets.
4. Încarcă **conținutul** actualizării păstrând structura și suprascrie numai
   fișierele cu același nume. Păstrează celelalte fișiere și directoare existente.
5. Include fișierul ascuns `assets/uploads/promotions/.htaccess`. Fișierul
   `admin/.user.ini` din pachet configurează încărcările de 8 MB pe PHP-FPM/CGI.
6. Deschide /admin/, reîncarcă fără cache și verifică cele două elemente noi.

Este necesar PHP 8.1+ cu sesiuni și fileinfo, conform aplicației existente;
validarea locală a folosit PHP 8.4. Nu sunt necesare baze de date, Composer, Node
sau servicii suplimentare pe IONOS. PHP trebuie să poată scrie în private_admin și
assets/uploads/promotions. Protecția existentă a private_admin prin .htaccess
trebuie păstrată. O cerere directă la private_admin/promotions.json trebuie să fie
refuzată. Fișierul și imaginile încărcate se includ în viitoarele copii de rezervă.

Arhiva de actualizare nu conține conturi, mesaje, documente, ciorne sau promoții
demonstrative. Nu înlocui private_admin, private_messages sau private_uploads.
Nu s-a făcut publicarea pe hostingul live în această sesiune.

Exportul JSON din Einstellungen und Sicherung include acum și datele Pop-up /
Aktionen, inclusiv ciornele. Exportul rămâne accesibil numai administratorului
principal. Fișierele imaginilor se salvează separat prin copia de rezervă a
directorului de upload.

## Fișiere și verificări

Fișiere noi: admin/promotions-lib.php, promotions-api.php, promotions-upload.php,
promotions-public.php, promotions-panel.php, admin/assets/promotions-admin.js și
promotions-admin.css, assets/js/promotions.js, assets/css/promotions.css și
assets/uploads/promotions/.htaccess. Integrarea modifică admin/index.php,
admin/lib.php, admin/export.php și assets/js/cms.js; paginile HTML au versiunea assetului CMS
actualizată. Editorul existent păstrează legătura cu nodurile originale atunci
când sunt inserate oferte, pentru a proteja modificările deja salvate.

Verificări în copia locală: încărcare/reînlocuire/eliminare imagini, salvare și
persistență, separarea draft/publicat, publicare/duplicare/dezactivare/ștergere,
ordinea ofertelor, pagini și poziții reale, schimbări de oră Berlin, toate cele
patru frecvențe, activare/expirare fără reîncărcare, countdown zero, coadă cu trei
pop-up-uri, X/Escape/focus, 16 combinații ecran/poziție pentru cronometrul public,
previzualizări desktop/tabletă/mobil și ecran complet, refuzul cererilor fără
autentificare/CSRF, refuzul fișierelor false/prea mari și linkurilor periculoase.
Au fost verificate și editorul celor 25 de pagini, prețurile și funcțiile de
administrare existente. Rezultatele și capturile sunt păstrate în mediul de lucru.

Accesul efectiv la contul IONOS și configurația serverului live nu au fost testate;
compatibilitatea este bazată pe aceleași cerințe PHP/Apache și pe verificările
locale. După instalare, verifică o ofertă cu o imagine de probă și protecția
directorului privat pe hostingul tău.
