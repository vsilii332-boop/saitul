# Fahrschule BV – permisiuni și pagini noi

Proprietarul este identificat pe server exclusiv prin contul autentificat
`vsilii332@gmail.com`. Câmpul „role” transmis de browser nu acordă drepturi.

| Secțiune | Proprietar | Alți utilizatori activi |
| --- | --- | --- |
| Übersicht și Website-Statistik | Complet | Complet, inclusiv exportul statisticii |
| Kunden | Înscrieri, mesaje și spam separat | Înscrieri și mesaje normale |
| Marketing / Pop-up și Aktionen | Complet | Complet |
| Website-Seiten | Toate paginile și ciornele | Numai paginile publicate din meniul public |
| Verwaltung | Complet | Fără acces |
| Konto und Passwort | Parola proprie | Parola proprie |

## Pagini și meniu

Din contul proprietarului, deschide **Verwaltung → Seiten und Menü / Neue Seite**.
Butonul **Neue Seite** apare și în editorul unei pagini. Introdu titlul, URL-ul
scurt, primul text și numele din meniu. Bifează **Veröffentlichen** și
**Im öffentlichen Menü anzeigen** dacă pagina trebuie publicată și accesibilă
angajaților. Fără prima bifă, pagina rămâne ciornă, vizibilă numai proprietarului.

Pagina nouă are un șablon cu titlu, text și fotografie existentă a site-ului.
Textele și fotografia se schimbă prin butoanele editorului vizual. URL-ul este
`custom-page.php?slug=numele-paginii`, fără reguli speciale de rescriere pe IONOS.
Ciornele sunt excluse din configurația publică și răspund cu 404 pentru vizitatori.
Previzualizarea lor verifică sesiunea proprietarului.

În **Bestehende Seiten und Menü**, proprietarul poate schimba numele din meniu,
ordinea și vizibilitatea fiecărei pagini. Numerele mai mici apar mai sus. Pentru
paginile create aici există și publicare/retragere în ciornă și **Seite löschen**,
cu confirmare. Paginile HTML existente se pot scoate din meniu; fișierele lor nu
sunt șterse de această funcție și rămân accesibile public prin URL.

Dreptul angajaților se recalculează la fiecare acces și salvare, inclusiv pentru
încărcarea fotografiilor. Publicarea unei pagini în meniu acordă imediat acces;
scoaterea din meniu îl retrage fără o nouă autentificare. Structura meniului
rămâne protejată inclusiv împotriva modificărilor prin editorul vizual.

## Mesaje

În **Kunden → Nachrichten**, toți utilizatorii pot modifica starea/notița și
pot apăsa **Löschen**. Confirmarea poate fi anulată; după confirmare, ștergerea
este definitivă. Ștergerea înscrierilor rămâne exclusiv la proprietar.

**Spam und Angebote** apare numai proprietarului. Un filtru local identifică
semnale explicite de publicitate nesolicitată, precum servicii SEO, backlinkuri
și guest posts. Solicitările obișnuite de preț pentru cursuri rămân în Nachrichten.
Filtrul este euristic: nu garantează clasificarea tuturor reclamelor. Proprietarul
poate folosi **Als Spam / Angebot markieren** sau **Zu Nachrichten verschieben**;
alegerea manuală are prioritate. Nu se șterge nimic automat din spam.

Mesajele din această zonă sunt excluse pentru angajați din listă, căutare și
contoare. Accesul prin ID la modificarea stării, reclasificare ori ștergere este
verificat separat pe server. Fișierele originale se păstrează la reclasificare.

## Instalare cu Cyberduck

Arhiva este o actualizare cumulativă de cod: include editorul pe pagini,
Pop-up, Aktionen și noile permisiuni. Nu este întregul site.

1. Păstrează o copie de rezervă a site-ului existent.
2. Dezarhivează actualizarea pe calculator și deschide în Cyberduck directorul
   site-ului unde se află `index.html`.
3. Copiază fișierele din arhivă, păstrând directoarele și acceptând înlocuirea
   fișierelor cu aceleași nume. Nu șterge site-ul înainte.
4. Nu înlocui directoarele `private_admin`, `private_messages`, `private_uploads`
   și configurația existentă `assets/data/site-config.json` cu date de test.
   Aceste date nu sunt incluse în actualizare. La prima deschidere a administratorului,
   copia publică este actualizată automat pentru a exclude setările administrative
   și ciornele, păstrând configurația privată completă.
5. Reîncarcă administratorul și verifică ambele conturi. Creează o pagină ciornă,
   public-o în meniu, apoi ascunde-o și verifică schimbarea accesului angajatului.

Nu sunt necesare baze de date, Composer, Node sau server nou pe IONOS. Se păstrează
PHP 8.1+, sesiunile, extensia fileinfo și drepturile de scriere deja folosite de
CMS. Salvările rămân în fișierele JSON existente; nu se resetează parole sau conturi.

## Verificare efectuată

Teste locale în Chromium și PHP 8.4, cu proprietar și angajat fictivi: secțiuni,
25 de pagini pentru proprietar / 9 pagini publice pentru angajat, URL-uri directe,
API, salvări vechi, fotografii, ciorne, publicare/ascundere și retragerea imediată
a accesului, mesaje și confirmarea ștergerii, spam și reclasificare, Marketing,
parola proprie și revocarea unei sesiuni după eliminarea contului. Sintaxa PHP
și JavaScript a fost verificată. Datele de test nu intră în arhivă.

Nu a fost efectuată publicarea pe IONOS. Fișierele private originale au fost
păstrate; testele folosesc numai o copie separată, cu trimiterea e-mailurilor oprită.
