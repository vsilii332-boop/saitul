<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
cms_require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
cms_check_csrf();

$action = (string)($_POST['action'] ?? '');
$site = cms_site();
$staffActions = ['self_password', 'status', 'delete_message'];
if (!cms_is_owner() && !in_array($action, $staffActions, true)) {
    http_response_code(403);
    exit('Keine Berechtigung für diese Aktion.');
}

try {
    if ($action === 'homepage') {
        foreach (['eyebrow','title','accent','primary_text','primary_link','secondary_text','secondary_link','desktop_image','mobile_image'] as $k) {
            $site['homepage'][$k] = trim((string)($_POST[$k] ?? ''));
        }
        cms_save_site($site); cms_log_activity('Startseite geändert'); cms_redirect('homepage', 'Startseite gespeichert');
    }
    if ($action === 'team') {
        $posted = $_POST['team'] ?? [];
        $team = [];
        if (is_array($posted)) foreach ($posted as $member) if (is_array($member) && empty($member['remove'])) {
            $name = trim((string)($member['name'] ?? ''));
            if ($name === '') continue;
            $team[] = [
                'name'=>$name, 'role'=>trim((string)($member['role']??'')), 'classes'=>trim((string)($member['classes']??'')),
                'tagline'=>trim((string)($member['tagline']??'')), 'description_1'=>trim((string)($member['description_1']??'')),
                'description_2'=>trim((string)($member['description_2']??'')), 'image'=>trim((string)($member['image']??'')),
                'active'=>isset($member['active']),
            ];
        }
        $site['team'] = $team; cms_save_site($site); cms_log_activity('Team geändert'); cms_redirect('team', 'Team gespeichert');
    }
    if ($action === 'gallery') {
        $posted = $_POST['gallery'] ?? [];
        $gallery = [];
        if (is_array($posted)) foreach ($posted as $img) if (is_array($img) && empty($img['remove'])) {
            $path = trim((string)($img['path'] ?? ''));
            if ($path === '') continue;
            $gallery[] = ['path'=>$path, 'alt'=>trim((string)($img['alt']??'')), 'active'=>isset($img['active'])];
        }
        $newPath = trim((string)($_POST['new_gallery_path'] ?? ''));
        if ($newPath !== '') $gallery[] = ['path'=>$newPath, 'alt'=>trim((string)($_POST['new_gallery_alt']??'')), 'active'=>true];
        $site['gallery'] = $gallery; cms_save_site($site); cms_log_activity('Galerie geändert'); cms_redirect('gallery', 'Galerie gespeichert');
    }
    if ($action === 'forms') {
        $site['forms'] = [
            'registration_enabled'=>isset($_POST['registration_enabled']),
            'contact_enabled'=>isset($_POST['contact_enabled']),
            'max_upload_mb'=>max(1,min(25,(int)($_POST['max_upload_mb']??8))),
            'registration_notice'=>trim((string)($_POST['registration_notice']??'')),
            'contact_notice'=>trim((string)($_POST['contact_notice']??'')),
        ];
        $site['settings']['retention_days'] = max(1,min(365,(int)($_POST['retention_days']??30)));
        $site['settings']['notification_email'] = trim((string)($_POST['notification_email']??''));
        $site['settings']['timezone'] = trim((string)($_POST['timezone']??'Europe/Berlin'));
        cms_save_site($site); cms_log_activity('Formulareinstellungen geändert'); cms_redirect('forms', 'Formulareinstellungen gespeichert');
    }
    if ($action === 'smtp') {
        $mail = cms_mail_config();
        $mail['enabled'] = isset($_POST['enabled']);
        $mail['host'] = trim((string)($_POST['host'] ?? 'smtp.gmail.com'));
        $mail['port'] = max(1, min(65535, (int)($_POST['port'] ?? 587)));
        $mail['username'] = strtolower(trim((string)($_POST['username'] ?? '')));
        $newPassword = preg_replace('/\s+/', '', (string)($_POST['app_password'] ?? '')) ?? '';
        if ($newPassword !== '') $mail['app_password'] = $newPassword;
        if (!empty($mail['enabled']) && (!filter_var($mail['username'], FILTER_VALIDATE_EMAIL) || empty($mail['app_password']))) {
            throw new RuntimeException('Bitte Google-E-Mail und App-Passwort vollständig eingeben.');
        }
        cms_save_mail_config($mail);
        cms_log_activity('Google SMTP geändert', !empty($mail['enabled']) ? 'Aktiv' : 'Inaktiv');
        if (isset($_POST['send_test']) && !empty($mail['enabled'])) {
            require_once __DIR__ . '/../private_admin/mailer.php';
            $target = (string)($site['settings']['notification_email'] ?? $mail['username']);
            $ok = site_send_mail($target, 'SMTP-Test – Fahrschule BV', "Die Google-SMTP-Verbindung der Website funktioniert.\n\nZeit: " . date('d.m.Y H:i'));
            if (!$ok) throw new RuntimeException('SMTP-Test fehlgeschlagen: ' . site_mail_last_error());
            cms_log_activity('Google SMTP getestet', 'Erfolgreich');
            cms_redirect('forms', 'SMTP gespeichert und Test-E-Mail gesendet');
        }
        cms_redirect('forms', 'SMTP sicher gespeichert');
    }
    if ($action === 'general') {
        $generalKeys = [
            'school_name','owner','address','postal_city','phone','phone_href','mobile','mobile_href','email','whatsapp','office_hours','theory_hours',
            'footer_tagline','footer_year','footer_owner_label','footer_creator_label','footer_creator_name',
            'footer_contact_title','footer_school_title','footer_forms_title','footer_legal_title',
            'dock_whatsapp_label','dock_email_label','dock_phone_label',
            'footer_licenses_label','footer_licenses_href','footer_motorcycle_label','footer_motorcycle_href',
            'footer_prices_label','footer_prices_href','footer_calendar_label','footer_calendar_href',
            'footer_registration_label','footer_registration_href','footer_form1_label','footer_form1_href',
            'footer_form2_label','footer_form2_href','footer_privacy_label','footer_privacy_href',
            'footer_imprint_label','footer_imprint_href','footer_agb_label','footer_agb_href','footer_cookie_label','footer_cookie_href'
        ];
        foreach ($generalKeys as $k) {
            if (array_key_exists($k, $_POST)) $site['general'][$k] = trim((string)$_POST[$k]);
        }
        cms_save_site($site); cms_log_activity('Kontaktdaten und globale Website-Texte geändert'); cms_redirect('website', 'Kontaktdaten und globale Texte gespeichert');
    }
    if ($action === 'theme') {
        foreach (['orange','orange2','black','text','font','base_size'] as $k) $site['theme'][$k] = trim((string)($_POST[$k] ?? ''));
        cms_save_site($site); cms_log_activity('Design geändert'); cms_redirect('design', 'Design gespeichert');
    }
    if ($action === 'summer') {
        $postedCourses = $_POST['courses'] ?? [];
        $courses = [];
        if (is_array($postedCourses)) foreach ($postedCourses as $course) {
            if (!is_array($course) || !empty($course['remove'])) continue;
            $row = [
                'label' => trim((string)($course['label'] ?? '')),
                'date' => trim((string)($course['date'] ?? '')),
                'time' => trim((string)($course['time'] ?? '')),
                'active' => isset($course['active']),
            ];
            if ($row['label'] === '' && $row['date'] === '' && $row['time'] === '') continue;
            $courses[] = $row;
        }
        // Compatibility with the previous two-course form.
        if ($postedCourses === []) {
            for ($i = 1; $i <= 2; $i++) {
                $row = [
                    'label' => trim((string)($_POST['c'.$i.'_label'] ?? '')),
                    'date' => trim((string)($_POST['c'.$i.'_date'] ?? '')),
                    'time' => trim((string)($_POST['c'.$i.'_time'] ?? '')),
                    'active' => true,
                ];
                if ($row['label'] !== '' || $row['date'] !== '' || $row['time'] !== '') $courses[] = $row;
            }
        }
        $enabled = isset($_POST['enabled']) && $courses !== [];
        $site['summerCourse'] = [
            'enabled' => $enabled,
            'label' => trim((string)($_POST['label'] ?? '')),
            'title' => trim((string)($_POST['title'] ?? '')),
            'courses' => $courses,
            'buttonText' => trim((string)($_POST['buttonText'] ?? '')),
            'buttonLink' => trim((string)($_POST['buttonLink'] ?? '')),
        ];
        cms_save_site($site); cms_log_activity('Kurse geändert', $enabled ? 'Bereich sichtbar' : 'Bereich ausgeblendet'); cms_redirect('summer', $enabled ? 'Kurse gespeichert und veröffentlicht' : 'Kurse gespeichert; der Bereich ist ausgeblendet');
    }
    if ($action === 'summer_hide') {
        $site['summerCourse']['enabled'] = false;
        cms_save_site($site); cms_log_activity('Kursbereich ausgeblendet'); cms_redirect('summer', 'Der Kursbereich wurde von der Website ausgeblendet');
    }
    if ($action === 'summer_clear') {
        $site['summerCourse'] = [
            'enabled'=>false, 'label'=>'Theorieunterricht', 'title'=>'', 'courses'=>[],
            'buttonText'=>'Jetzt online anmelden', 'buttonLink'=>'anmeldung.html',
        ];
        cms_save_site($site); cms_log_activity('Alle Kurse gelöscht'); cms_redirect('summer', 'Alle Kurse wurden gelöscht und der Bereich wurde ausgeblendet');
    }
    if ($action === 'banner_add') {
        $title = trim((string)($_POST['title'] ?? ''));
        if ($title === '') throw new RuntimeException('Bitte einen Titel eingeben.');
        $site['banners'][] = [
            'id'=>bin2hex(random_bytes(5)), 'active'=>isset($_POST['active']), 'title'=>$title,
            'text'=>trim((string)($_POST['text'] ?? '')), 'image'=>trim((string)($_POST['image'] ?? '')),
            'buttonText'=>trim((string)($_POST['buttonText'] ?? '')), 'buttonLink'=>trim((string)($_POST['buttonLink'] ?? '')),
            'start'=>trim((string)($_POST['start'] ?? '')), 'end'=>trim((string)($_POST['end'] ?? '')),
            'position'=>(string)($_POST['position'] ?? 'after-hero'),
        ];
        cms_save_site($site); cms_log_activity('Banner erstellt', $title); cms_redirect('banner', 'Banner erstellt');
    }
    if ($action === 'banner_delete') {
        $id = (string)($_POST['id'] ?? '');
        $site['banners'] = array_values(array_filter($site['banners'] ?? [], fn($b) => (string)($b['id'] ?? '') !== $id));
        cms_save_site($site); cms_log_activity('Banner gelöscht'); cms_redirect('banner', 'Banner gelöscht');
    }
    if ($action === 'banner_update') {
        $id = (string)($_POST['id'] ?? '');
        foreach ($site['banners'] as &$banner) if ((string)($banner['id']??'') === $id) {
            $banner['active'] = isset($_POST['active']);
            foreach(['title','text','image','buttonText','buttonLink','start','end','position'] as $k) $banner[$k] = trim((string)($_POST[$k]??''));
        }
        unset($banner); cms_save_site($site); cms_log_activity('Banner geändert'); cms_redirect('banner', 'Banner gespeichert');
    }
    if ($action === 'media_delete') {
        $name = basename((string)($_POST['name'] ?? ''));
        $file = __DIR__ . '/../assets/uploads/' . $name;
        if ($name !== '' && is_file($file)) @unlink($file);
        cms_log_activity('Bild gelöscht', $name); cms_redirect('media', 'Bild gelöscht');
    }
    if ($action === 'prices') {
        $posted = $_POST['price'] ?? [];
        if (is_array($posted)) foreach ($posted as $cl=>$vals) if (is_array($vals)) foreach ($vals as $k=>$v) $site['prices'][$cl][$k] = trim((string)$v);
        cms_save_site($site); cms_log_activity('Preise geändert'); cms_redirect('prices', 'Preise gespeichert');
    }
    if ($action === 'page_full') {
        $page = basename((string)($_POST['page'] ?? ''));
        if ($page === '' || !is_file(__DIR__ . '/../' . $page)) throw new RuntimeException('Die ausgewählte Seite wurde nicht gefunden.');
        $posted = $_POST['full'] ?? [];
        if (!is_array($posted)) $posted = [];
        $rows = cms_page_editor_items($page);
        $overrides = [];
        foreach ($rows as $row) {
            if (!is_array($row) || empty($row['id']) || empty($row['xpath']) || empty($row['kind'])) continue;
            $id = (string)$row['id'];
            if (!array_key_exists($id, $posted)) continue;
            $value = trim(str_replace(["\r\n", "\r"], "\n", (string)$posted[$id]));
            $base = trim((string)($row['value'] ?? ''));
            $cmsId = trim((string)($row['cms_id'] ?? ''));
            if ($cmsId !== '' && isset($site['content'][$page][$cmsId]) && is_array($site['content'][$page][$cmsId])) {
                $legacy = $site['content'][$page][$cmsId];
                if (($row['kind'] ?? '') === 'text' && array_key_exists('text', $legacy)) $base = trim((string)$legacy['text']);
                if (($row['kind'] ?? '') === 'attr' && ($row['attr'] ?? '') === 'href' && array_key_exists('href', $legacy)) $base = trim((string)$legacy['href']);
            }
            if (($row['kind'] ?? '') === 'attr' && ($row['attr'] ?? '') === 'href' && preg_match('/^\s*javascript:/i', $value)) $value = '#';
            if ($value === $base) continue;
            $entry = [
                'kind'=>(string)$row['kind'], 'xpath'=>(string)$row['xpath'], 'value'=>$value,
            ];
            if (!empty($row['slot'])) $entry['slot'] = (string)$row['slot'];
            if (!empty($row['attr'])) $entry['attr'] = (string)$row['attr'];
            $overrides[$id] = $entry;
        }
        if ($overrides) $site['pageEditor'][$page] = $overrides;
        else unset($site['pageEditor'][$page]);
        cms_save_site($site);
        cms_log_activity('Vollständiger Seiteninhalt geändert', $page);
        cms_redirect('pages', 'Seite vollständig gespeichert');
    }

    if ($action === 'content') {
        $page = basename((string)($_POST['page'] ?? ''));
        $texts = $_POST['text'] ?? []; $hrefs = $_POST['href'] ?? [];
        $site['content'][$page] = [];
        if (is_array($texts)) foreach ($texts as $id=>$text) {
            $row = ['text'=>(string)$text];
            if (isset($hrefs[$id])) $row['href'] = trim((string)$hrefs[$id]);
            $site['content'][$page][$id] = $row;
        }
        cms_save_site($site); cms_log_activity('Seiteninhalt geändert', $page); cms_redirect('pages', 'Seiteninhalt gespeichert');
    }
    if ($action === 'block_add') {
        $page = basename((string)($_POST['page'] ?? ''));
        $site['blocks'][$page][] = [
            'id'=>bin2hex(random_bytes(5)), 'type'=>(string)($_POST['type'] ?? 'text'), 'title'=>trim((string)($_POST['title'] ?? '')),
            'text'=>trim((string)($_POST['text'] ?? '')), 'image'=>trim((string)($_POST['image'] ?? '')),
            'buttonText'=>trim((string)($_POST['buttonText'] ?? '')), 'buttonLink'=>trim((string)($_POST['buttonLink'] ?? '')),
            'placement'=>(string)($_POST['placement'] ?? 'before-footer'),
        ];
        cms_save_site($site); cms_log_activity('Seitenelement hinzugefügt', $page); cms_redirect('pages', 'Element hinzugefügt');
    }
    if ($action === 'block_delete') {
        $page = basename((string)($_POST['page'] ?? '')); $id = (string)($_POST['id'] ?? '');
        $site['blocks'][$page] = array_values(array_filter($site['blocks'][$page] ?? [], fn($b) => (string)($b['id'] ?? '') !== $id));
        cms_save_site($site); cms_log_activity('Seitenelement gelöscht', $page); cms_redirect('pages', 'Element gelöscht');
    }
    if ($action === 'custom_page_add') {
        $title = trim((string)($_POST['title'] ?? '')); $slug = cms_slug((string)($_POST['slug'] ?? $title));
        if ($title === '' || $slug === '') throw new RuntimeException('Titel und URL sind erforderlich.');
        $site['customPages'][] = ['id'=>bin2hex(random_bytes(5)), 'title'=>$title, 'slug'=>$slug, 'active'=>isset($_POST['active']), 'menu_label'=>trim((string)($_POST['menu_label'] ?? $title)), 'seo_title'=>trim((string)($_POST['seo_title'] ?? $title)), 'seo_desc'=>trim((string)($_POST['seo_desc'] ?? '')), 'blocks'=>[]];
        cms_save_site($site); cms_log_activity('Neue Seite erstellt', $title); cms_redirect('pages', 'Neue Seite erstellt');
    }
    if ($action === 'custom_page_delete') {
        $id = (string)($_POST['id'] ?? '');
        $site['customPages'] = array_values(array_filter($site['customPages'] ?? [], fn($p) => (string)($p['id'] ?? '') !== $id));
        cms_save_site($site); cms_log_activity('Eigene Seite gelöscht'); cms_redirect('pages', 'Seite gelöscht');
    }
    if ($action === 'custom_page_update') {
        $id = (string)($_POST['id'] ?? '');
        foreach ($site['customPages'] as &$page) if ((string)($page['id']??'') === $id) {
            $page['title'] = trim((string)($_POST['title']??''));
            $page['menu_label'] = trim((string)($_POST['menu_label']??''));
            $page['seo_title'] = trim((string)($_POST['seo_title']??''));
            $page['seo_desc'] = trim((string)($_POST['seo_desc']??''));
            $page['active'] = isset($_POST['active']);
        }
        unset($page); cms_save_site($site); cms_log_activity('Eigene Seite geändert'); cms_redirect('pages', 'Eigene Seite gespeichert');
    }
    if ($action === 'custom_block_add') {
        $pid = (string)($_POST['page_id'] ?? '');
        foreach ($site['customPages'] as &$p) if ((string)($p['id'] ?? '') === $pid) {
            $p['blocks'][] = ['id'=>bin2hex(random_bytes(5)), 'type'=>(string)($_POST['type'] ?? 'text'), 'title'=>trim((string)($_POST['title'] ?? '')), 'text'=>trim((string)($_POST['text'] ?? '')), 'image'=>trim((string)($_POST['image'] ?? '')), 'buttonText'=>trim((string)($_POST['buttonText'] ?? '')), 'buttonLink'=>trim((string)($_POST['buttonLink'] ?? ''))];
        }
        unset($p); cms_save_site($site); cms_log_activity('Element zu eigener Seite hinzugefügt'); cms_redirect('pages', 'Element hinzugefügt');
    }
    if ($action === 'custom_block_delete') {
        $pid = (string)($_POST['page_id'] ?? ''); $bid = (string)($_POST['block_id'] ?? '');
        foreach ($site['customPages'] as &$page) if ((string)($page['id']??'') === $pid) {
            $page['blocks'] = array_values(array_filter($page['blocks']??[], fn($b)=>(string)($b['id']??'')!==$bid));
        }
        unset($page); cms_save_site($site); cms_log_activity('Element von eigener Seite gelöscht'); cms_redirect('pages', 'Element gelöscht');
    }
    if ($action === 'navigation') {
        $labels = $_POST['label'] ?? []; $hrefs = $_POST['href'] ?? []; $buttons = $_POST['button'] ?? []; $enabled = $_POST['enabled'] ?? []; $remove = $_POST['remove'] ?? []; $nav = [];
        if (is_array($labels)) foreach ($labels as $i=>$label) {
            $label = trim((string)$label); $href = trim((string)($hrefs[$i] ?? ''));
            if ($label === '' || $href === '' || isset($remove[$i])) continue;
            $nav[] = ['label'=>$label, 'href'=>$href, 'button'=>isset($buttons[$i]), 'enabled'=>isset($enabled[$i])];
        }
        $site['navigation'] = $nav; cms_save_site($site); cms_log_activity('Navigation geändert'); cms_redirect('navigation', 'Navigation gespeichert');
    }
    if ($action === 'seo') {
        $page = basename((string)($_POST['page'] ?? ''));
        $site['seo'][$page] = ['title'=>trim((string)($_POST['title'] ?? '')), 'description'=>trim((string)($_POST['description'] ?? '')), 'index'=>isset($_POST['index'])];
        cms_save_site($site); cms_log_activity('SEO geändert', $page); cms_redirect('seo', 'SEO gespeichert');
    }
    if ($action === 'settings') {
        $site['settings']['retention_days'] = max(1, min(365, (int)($_POST['retention_days'] ?? 30)));
        $site['settings']['notification_email'] = trim((string)($_POST['notification_email'] ?? ''));
        $site['settings']['timezone'] = trim((string)($_POST['timezone'] ?? 'Europe/Berlin'));
        cms_save_site($site); cms_log_activity('Einstellungen geändert'); cms_redirect('settings', 'Einstellungen gespeichert');
    }
    if ($action === 'sync_public') {
        if (!cms_sync_public_site()) throw new RuntimeException('Veröffentlichung fehlgeschlagen. Bitte die Schreibrechte des Ordners assets/data prüfen.');
        cms_log_activity('Website-Daten erneut veröffentlicht');
        cms_redirect('dashboard', 'Die Website-Daten wurden erfolgreich erneut veröffentlicht');
    }
    if ($action === 'status') {
        $kind = (string)($_POST['kind'] ?? ''); $id = (string)($_POST['id'] ?? '');
        if ($kind === 'messages') { $message = cms_require_message($id); $id = (string)($message['message_id'] ?? $message['_file']); }
        elseif ($kind === 'registrations') {
            $known = false; foreach (cms_registrations() as $r) if ($id === (string)($r['request_id'] ?? $r['_dir'])) $known = true;
            if (!$known) { http_response_code(403); exit('Keine Berechtigung.'); }
        } else { http_response_code(400); exit('Ungültiger Bereich.'); }
        $allowed = $kind === 'messages' ? ['Neu','Kontaktiert','Erledigt'] : ['Neu','Kontaktiert','In Bearbeitung','Erledigt'];
        $newStatus = (string)($_POST['status'] ?? 'Neu');
        if (!in_array($newStatus, $allowed, true)) $newStatus = 'Neu';
        $s = cms_status();
        if (in_array($kind, ['registrations','messages'], true)) {
            $s[$kind][$id] = array_merge((array)($s[$kind][$id] ?? []), ['status'=>$newStatus, 'note'=>trim((string)($_POST['note'] ?? ''))]);
            cms_save_status($s);
            cms_log_activity($kind === 'messages' ? 'Kontaktanfrage aktualisiert' : 'Anmeldung aktualisiert', $newStatus);
        }
        cms_redirect($kind === 'messages' ? 'messages' : 'registrations', 'Status gespeichert');
    }
    if ($action === 'delete_registration') {
        $id = basename((string)($_POST['id'] ?? ''));
        $dir = realpath(__DIR__ . '/../private_uploads/' . $id); $root = realpath(__DIR__ . '/../private_uploads');
        if ($dir && $root && str_starts_with($dir, $root . DIRECTORY_SEPARATOR)) {
            $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
            foreach ($it as $f) $f->isDir() ? rmdir($f->getPathname()) : unlink($f->getPathname());
            rmdir($dir);
        }
        cms_log_activity('Anmeldung gelöscht', $id); cms_redirect('registrations', 'Anmeldung gelöscht');
    }
    if ($action === 'message_visibility') {
        cms_require_owner();
        $r = cms_require_message((string)($_POST['id'] ?? ''));
        $id = (string)($r['message_id'] ?? $r['_file']);
        $visibility = ($_POST['visibility'] ?? '') === 'spam' ? 'spam' : 'normal';
        $state = cms_status(); $state['messages'][$id]['visibility'] = $visibility; cms_save_status($state);
        cms_log_activity('Nachricht zugeordnet', $visibility);
        cms_redirect($visibility === 'spam' ? 'spam' : 'messages', 'Nachricht verschoben');
    }
    if ($action === 'delete_message') {
        $r = cms_require_message((string)($_POST['id'] ?? ''));
        $id = (string)$r['_file']; $f = __DIR__ . '/../private_messages/' . $id;
        if (!is_file($f) || !unlink($f)) throw new RuntimeException('Nachricht konnte nicht gelöscht werden.');
        cms_log_activity('Kontaktanfrage gelöscht', $id); cms_redirect('messages', 'Nachricht gelöscht');
    }
    if ($action === 'user_add') {
        $users = cms_users(); $username = strtolower(trim((string)($_POST['username'] ?? ''))); $pass = (string)($_POST['password'] ?? '');
        if (!filter_var($username, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Bitte eine gültige E-Mail-Adresse verwenden.');
        if (strlen($pass) < 10) throw new RuntimeException('Das Passwort muss mindestens 10 Zeichen lang sein.');
        if (cms_is_superuser_name($username)) throw new RuntimeException('Der Hauptadministrator ist bereits fest definiert.');
        foreach ($users as $u) if (strtolower((string)$u['username']) === $username) throw new RuntimeException('Dieser Benutzer existiert bereits.');
        $users[] = ['username'=>$username, 'password_hash'=>password_hash($pass, PASSWORD_DEFAULT), 'role'=>'staff', 'active'=>true];
        cms_json_write(CMS_USERS_FILE, $users); cms_log_activity('Mitarbeiter hinzugefügt', $username); cms_redirect('users', 'Mitarbeiter hinzugefügt');
    }
    if ($action === 'user_password') {
        $username = (string)($_POST['username'] ?? ''); $pass = (string)($_POST['password'] ?? '');
        if (strlen($pass) < 10) throw new RuntimeException('Das Passwort muss mindestens 10 Zeichen lang sein.');
        $users = cms_users(); $found = false;
        foreach ($users as &$u) if ((string)$u['username'] === $username) { $u['password_hash'] = password_hash($pass, PASSWORD_DEFAULT); $found = true; }
        unset($u);
        if (!$found) throw new RuntimeException('Benutzer nicht gefunden.');
        cms_json_write(CMS_USERS_FILE, $users); cms_log_activity('Passwort geändert', $username); cms_redirect('users', 'Passwort wurde erfolgreich geändert.');
    }
    if ($action === 'self_password') {
        $username = (string)(cms_user()['username'] ?? ''); $pass = (string)($_POST['password'] ?? ''); $confirm = (string)($_POST['password_confirm'] ?? '');
        if (strlen($pass) < 10) throw new RuntimeException('Das Passwort muss mindestens 10 Zeichen lang sein.');
        if ($pass !== $confirm) throw new RuntimeException('Die Passwörter stimmen nicht überein.');
        $users = cms_users(); $found = false;
        foreach ($users as &$u) if (strtolower((string)$u['username']) === strtolower($username)) { $u['password_hash'] = password_hash($pass, PASSWORD_DEFAULT); $found = true; }
        unset($u);
        if (!$found) throw new RuntimeException('Benutzer nicht gefunden.');
        cms_json_write(CMS_USERS_FILE, $users); cms_log_activity('Eigenes Passwort geändert'); cms_redirect('profile', 'Passwort wurde erfolgreich geändert.');
    }
    if ($action === 'user_delete') {
        $me = (string)(cms_user()['username'] ?? ''); $username = (string)($_POST['username'] ?? '');
        if (strtolower($username) === strtolower($me)) throw new RuntimeException('Sie können Ihr eigenes Konto nicht löschen.');
        if (cms_is_superuser_name($username)) throw new RuntimeException('Der Hauptadministrator kann nicht gelöscht werden.');
        $users = array_values(array_filter(cms_users(), fn($u) => (string)$u['username'] !== $username));
        cms_json_write(CMS_USERS_FILE, $users); cms_log_activity('Mitarbeiter gelöscht', $username); cms_redirect('users', 'Mitarbeiter gelöscht');
    }
    throw new RuntimeException('Unbekannte Aktion.');
} catch (Throwable $e) {
    $_SESSION['cms_error'] = $e->getMessage();
    $return = (string)($_POST['return_section'] ?? 'dashboard');
    if (!cms_section_allowed($return)) $return = 'dashboard';
    header('Location: index.php?section=' . rawurlencode($return));
    exit;
}
