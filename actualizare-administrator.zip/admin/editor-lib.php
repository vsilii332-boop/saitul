<?php
declare(strict_types=1);

function cms_editor_upload_limit(): int {
    $limit = 8 * 1024 * 1024;
    foreach (['upload_max_filesize','post_max_size'] as $setting) {
        $raw = trim((string)ini_get($setting));
        $amount = (float)$raw;
        $suffix = strtolower(substr($raw, -1));
        $factor = ['k'=>1024,'m'=>1048576,'g'=>1073741824][$suffix] ?? 1;
        $bytes = (int)($amount * $factor);
        if ($bytes > 0) $limit = min($limit, $setting === 'post_max_size' ? max(1,$bytes-65536) : $bytes);
    }
    return $limit;
}

function cms_editor_image_path(string $path): bool {
    if (!preg_match('~^(?:assets/[A-Za-z0-9_./-]+|[A-Za-z0-9_-]+\.(?:png|jpg|jpeg|webp|gif|avif|ico))$~iD', $path) || str_contains($path, '..')) return false;
    $root = realpath(__DIR__ . '/..');
    $file = realpath(__DIR__ . '/../' . $path);
    return $root !== false && $file !== false && str_starts_with($file, $root . DIRECTORY_SEPARATOR)
        && is_file($file) && preg_match('/\.(?:png|jpe?g|webp|gif|avif|ico)$/iD', $file);
}

function cms_editor_change(array $row): array {
    $xpath = (string)($row['xpath'] ?? '');
    // Only element paths inside the visible document; never executable attributes.
    if (strlen($xpath) > 2000 || !preg_match('~^/html\[1\]/body\[1\](?:/[a-z][a-z0-9-]*\[[1-9][0-9]{0,4}\])*$~D', $xpath)
        || preg_match('~/(?:script|style|noscript|iframe|object|embed|template)\[~', $xpath)) {
        throw new InvalidArgumentException('Dieses Element kann nicht bearbeitet werden.');
    }
    $type = (string)($row['type'] ?? '');
    $value = str_replace(["\r\n", "\r"], "\n", (string)($row['value'] ?? ''));
    if (strlen($value) > 30000) throw new InvalidArgumentException('Der Text ist zu lang.');
    $entry = ['xpath'=>$xpath, 'type'=>$type, 'value'=>$value];
    if ($type === 'text') {
        $index = filter_var($row['index'] ?? null, FILTER_VALIDATE_INT);
        if ($index === false || $index < 0 || $index > 1000) throw new InvalidArgumentException('Ungültiges Textfeld.');
        $entry['index'] = $index;
    } elseif ($type === 'attribute') {
        $attr = (string)($row['attr'] ?? '');
        if (!in_array($attr, ['alt','title','placeholder','aria-label'], true)) throw new InvalidArgumentException('Ungültiges Textfeld.');
        $entry['attr'] = $attr;
    } elseif ($type === 'image') {
        if (!in_array($row['attr'] ?? '', ['src','srcset','background'], true) || !cms_editor_image_path($value)) {
            throw new InvalidArgumentException('Bitte ein Bild aus der Website auswählen oder ein neues Bild hochladen.');
        }
        $entry['attr'] = $row['attr'];
        if (isset($row['pseudo'])) {
            if ($entry['attr'] !== 'background' || !in_array($row['pseudo'], ['::before','::after'], true)) throw new InvalidArgumentException('Ungültiges Hintergrundbild.');
            $entry['pseudo'] = $row['pseudo'];
        }
    } else {
        throw new InvalidArgumentException('Ungültiger Inhaltstyp.');
    }
    return $entry;
}

function cms_editor_key(array $row): string {
    return hash('sha256', $row['xpath'] . '|' . $row['type'] . '|' . ($row['index'] ?? $row['attr'] ?? '') . '|' . ($row['pseudo'] ?? ''));
}
