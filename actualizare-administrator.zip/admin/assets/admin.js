(() => {
  const body = document.body;
  const menuButton = document.querySelector('[data-menu-open]');
  const sidebar = document.querySelector('.sidebar');
  const navSearch = document.querySelector('[data-nav-search]');
  const mobileMenu = window.matchMedia('(max-width: 760px)');
  const setMenu = (open, restoreFocus = false) => {
    body.classList.toggle('menu-open', open);
    menuButton?.setAttribute('aria-expanded', String(open));
    if (sidebar) sidebar.inert = mobileMenu.matches && !open;
    if (open) sidebar?.querySelector('[data-menu-close]')?.focus();
    else if (restoreFocus) menuButton?.focus();
  };
  menuButton?.addEventListener('click', () => setMenu(!body.classList.contains('menu-open')));
  document.querySelectorAll('[data-menu-close], .sidebar a').forEach(el => el.addEventListener('click', () => setMenu(false, true)));
  mobileMenu.addEventListener('change', () => setMenu(false));
  setMenu(false);
  sidebar?.querySelector('.nav-link[aria-current="page"]')?.scrollIntoView({block:'nearest'});

  const filterNavigation = () => {
    const normalize = value => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('de');
    const query = normalize(navSearch?.value.trim() || '');
    let count = 0;
    document.querySelectorAll('.nav-group').forEach(group => {
      let visible = 0;
      group.querySelectorAll('.nav-link').forEach(link => {
        link.hidden = !normalize(link.textContent + ' ' + (link.dataset.pageLink || '')).includes(query);
        if (!link.hidden) visible++;
      });
      group.hidden = visible === 0;
      count += visible;
    });
    const empty = document.querySelector('[data-nav-empty]');
    if (empty) empty.hidden = count > 0;
  };
  navSearch?.addEventListener('input', filterNavigation);
  navSearch?.addEventListener('keydown', event => {
    if (event.key === 'Escape' && navSearch.value) {
      event.stopPropagation(); navSearch.value = ''; filterNavigation();
    }
    if (event.key === 'Enter') {
      event.preventDefault();
      const links = sidebar?.querySelectorAll('.nav-group:not([hidden]) .nav-link:not([hidden])');
      if (links?.length === 1) links[0].click();
    }
  });
  document.addEventListener('keydown', event => {
    const typing = event.target instanceof Element && event.target.closest('input, textarea, select, [contenteditable]');
    if (event.key === '/' && !typing && !event.ctrlKey && !event.metaKey && !event.altKey && navSearch) {
      event.preventDefault();
      if (mobileMenu.matches) setMenu(true);
      navSearch.focus();
    }
    if (event.key === 'Escape' && body.classList.contains('menu-open')) setMenu(false, true);
    if (event.key === 'Tab' && mobileMenu.matches && body.classList.contains('menu-open')) {
      const elements = [...sidebar.querySelectorAll('a[href], button, input')].filter(el => !el.disabled && el.getClientRects().length);
      const first = elements[0], last = elements[elements.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    }
  });

  const applyFilter = (key) => {
    const list = document.querySelector(`[data-list="${key}"]`);
    if (!list) return;
    const q = (document.querySelector(`[data-list-search="${key}"]`)?.value || '').trim().toLowerCase();
    const status = document.querySelector(`[data-list-filter="${key}"]`)?.value || '';
    list.querySelectorAll('[data-item]').forEach(item => {
      const hay = (item.dataset.search || '').toLowerCase();
      const st = item.dataset.status || '';
      item.hidden = !(hay.includes(q) && (!status || st === status));
    });
  };
  ['registrations','messages'].forEach(key => {
    document.querySelector(`[data-list-search="${key}"]`)?.addEventListener('input', () => applyFilter(key));
    document.querySelector(`[data-list-filter="${key}"]`)?.addEventListener('change', () => applyFilter(key));
  });

  document.querySelectorAll('[data-copy]').forEach(btn => btn.addEventListener('click', async () => {
    const value = btn.dataset.copy || '';
    try {
      await navigator.clipboard.writeText(value);
      const old = btn.textContent;
      btn.textContent = 'Kopiert ✓';
      setTimeout(() => btn.textContent = old, 1500);
    } catch (_) {
      const ta = document.createElement('textarea'); ta.value = value; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove();
    }
  }));

  document.querySelector('[data-refresh-preview]')?.addEventListener('click', () => {
    const frame = document.querySelector('[data-preview]');
    if (frame) {
      const url = new URL(frame.src, location.href);
      url.searchParams.set('preview', Date.now());
      frame.src = url.toString();
    }
  });

  document.querySelectorAll('[data-toast]').forEach(toast => {
    setTimeout(() => { toast.style.opacity = '0'; toast.style.transform = 'translateY(-4px)'; }, 3800);
    setTimeout(() => toast.remove(), 4300);
  });

  document.querySelectorAll('input[type=color]').forEach(input => input.addEventListener('input', () => {
    const span = input.parentElement?.querySelector('span'); if (span) span.textContent = input.value;
  }));

  // Clear, understandable feedback for all editor forms.
  let dirtyForm = null;
  document.querySelectorAll('form[action="save.php"]').forEach(form => {
    form.addEventListener('input', () => {
      dirtyForm = form;
      form.classList.add('has-unsaved-changes');
    });
    form.addEventListener('submit', () => {
      dirtyForm = null;
      const button = form.querySelector('button[type="submit"], button:not([type])');
      if (button) {
        button.disabled = true;
        button.dataset.oldText = button.textContent;
        button.textContent = 'Wird gespeichert und veröffentlicht…';
      }
    });
  });
  window.addEventListener('beforeunload', event => {
    if (!dirtyForm) return;
    event.preventDefault();
    event.returnValue = '';
  });

  const courseList = document.querySelector('[data-course-list]');
  const updateCourseState = () => {
    if (!courseList) return;
    const visible = [...courseList.querySelectorAll('[data-course-card]')].filter(card => !card.hidden);
    visible.forEach((card, index) => {
      const title = card.querySelector('.course-card-title span');
      if (title) title.textContent = `KURS ${index + 1}`;
    });
    const empty = document.querySelector('[data-course-empty]');
    if (empty) empty.hidden = visible.length > 0;
  };
  const bindCourseRemove = card => {
    card.querySelector('[data-remove-course]')?.addEventListener('click', () => {
      if (!confirm('Diesen Kurs aus der Liste entfernen? Die Änderung wird nach dem Speichern endgültig.')) return;
      const remove = card.querySelector('[data-remove-value]');
      if (remove) remove.value = '1';
      card.hidden = true;
      dirtyForm = card.closest('form');
      dirtyForm?.classList.add('has-unsaved-changes');
      updateCourseState();
      updateLivePreview();
    });
  };
  courseList?.querySelectorAll('[data-course-card]').forEach(bindCourseRemove);
  document.querySelector('[data-add-course]')?.addEventListener('click', () => {
    if (!courseList) return;
    const index = Number(courseList.dataset.nextIndex || 0);
    courseList.dataset.nextIndex = String(index + 1);
    const card = document.createElement('article');
    card.className = 'course-card';
    card.dataset.courseCard = '';
    card.innerHTML = `<div class="course-card-title"><span>NEUER KURS</span><button type="button" class="remove-course" data-remove-course>Entfernen</button></div>
      <label class="check"><input type="checkbox" name="courses[${index}][active]" checked> Kurs sichtbar</label>
      <label>Bezeichnung<input name="courses[${index}][label]" placeholder="z. B. 1. Kurs"></label>
      <label>Datum<input name="courses[${index}][date]" placeholder="z. B. 03.08.–11.08.2026"></label>
      <label>Uhrzeit<input name="courses[${index}][time]" placeholder="täglich · 9:00–12:00 Uhr"></label>
      <input type="hidden" name="courses[${index}][remove]" value="0" data-remove-value>`;
    courseList.appendChild(card);
    bindCourseRemove(card);
    dirtyForm = card.closest('form');
    dirtyForm?.classList.add('has-unsaved-changes');
    updateCourseState();
    updateLivePreview();
    card.querySelector('input[type="text"], input:not([type])')?.focus();
  });
  updateCourseState();

  // Live editor: changes stay private inside the preview until the form is saved.
  const params = new URLSearchParams(location.search);
  const section = params.get('section') || 'dashboard';
  const previewPages = {
    homepage: '../index.html',
    team: '../fahrschule.html',
    prices: '../preisliste.html',
    summer: '../index.html#summer-course-block',
    banner: '../index.html',
    website: '../kontakt.html',
    navigation: '../index.html',
    design: '../index.html',
    media: '../galerie.html',
    seo: `../${params.get('page') || 'index.html'}`
  };

  const createPreview = () => {
    if (!previewPages[section] || document.querySelector('.live-preview-shell')) return;
    const content = document.querySelector('.content');
    const heading = content?.querySelector('.page-heading');
    if (!content || !heading) return;
    const editableNodes = [];
    let node = heading.nextElementSibling;
    while (node) {
      const next = node.nextElementSibling;
      editableNodes.push(node);
      node = next;
    }
    if (!editableNodes.length) return;

    const layout = document.createElement('div');
    layout.className = 'live-editor-layout';
    const editor = document.createElement('div');
    editor.className = 'live-editor-main';
    editableNodes.forEach(item => editor.appendChild(item));
    const preview = document.createElement('section');
    preview.className = 'preview-panel live-preview-shell is-loading';
    preview.innerHTML = `<div class="preview-toolbar"><span><i></i> Live-Vorschau <small class="preview-saving-note">Nur Vorschau – <strong>noch nicht veröffentlicht</strong></small></span><div class="preview-toolbar-actions"><button type="button" class="preview-mode active" data-preview-mode="desktop">Desktop</button><button type="button" class="preview-mode" data-preview-mode="mobile">Mobil</button><button type="button" class="icon-btn" data-live-refresh title="Vorschau neu laden">↻</button></div></div><iframe data-live-preview title="Live-Vorschau der Website"></iframe>`;
    layout.append(editor, preview);
    heading.after(layout);
    const frame = preview.querySelector('[data-live-preview]');
    frame.src = previewPages[section];
    frame.addEventListener('load', () => {
      preview.classList.remove('is-loading');
      setTimeout(updateLivePreview, 350);
      setTimeout(updateLivePreview, 1100);
    });
    preview.querySelector('[data-live-refresh]')?.addEventListener('click', () => {
      preview.classList.add('is-loading');
      const url = new URL(frame.src, location.href);
      url.searchParams.set('preview', Date.now());
      frame.src = url.toString();
    });
    preview.querySelectorAll('[data-preview-mode]').forEach(button => button.addEventListener('click', () => {
      preview.querySelectorAll('[data-preview-mode]').forEach(item => item.classList.toggle('active', item === button));
      preview.classList.toggle('is-mobile', button.dataset.previewMode === 'mobile');
    }));
    editor.addEventListener('input', updateLivePreview);
    editor.addEventListener('change', updateLivePreview);
  };

  const formValues = form => {
    const values = {};
    if (!form) return values;
    form.querySelectorAll('input, textarea, select').forEach(field => {
      if (!field.name || ['csrf','action','return_section'].includes(field.name)) return;
      values[field.name] = field.type === 'checkbox' ? field.checked : field.value;
    });
    return values;
  };
  const previewDocument = () => document.querySelector('[data-live-preview]')?.contentDocument || document.querySelector('[data-preview]')?.contentDocument;
  const assetUrl = (doc, path) => {
    if (!path) return '';
    try { return new URL(path, doc.baseURI).toString(); } catch (_) { return path; }
  };
  const value = (values, name, fallback = '') => Object.prototype.hasOwnProperty.call(values, name) ? values[name] : fallback;

  function updateLivePreview() {
    const doc = previewDocument();
    if (!doc?.body) return;
    const editorRoot = document.querySelector('.live-editor-main') || document;
    const primaryForm = editorRoot.querySelector('form[action="save.php"]');
    const values = formValues(primaryForm);

    if (section === 'pages') {
      const resolveXPath = path => {
        try { return doc.evaluate(path, doc, null, doc.defaultView.XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; } catch (_) { return null; }
      };
      document.querySelectorAll('.editor-panel [data-full-id]').forEach(field => {
        const target = resolveXPath(field.dataset.fullXpath || '');
        if (!target) return;
        if (field.dataset.fullKind === 'attr') {
          const attr = field.dataset.fullAttr || '';
          if (attr) target.setAttribute(attr, field.value);
          return;
        }
        let textNode = null;
        if (field.dataset.fullSlot === 'tail') textNode = target.nextSibling?.nodeType === 3 ? target.nextSibling : null;
        else textNode = [...target.childNodes].find(node => node.nodeType === 3 && node.nodeValue.trim() !== '') || [...target.childNodes].find(node => node.nodeType === 3) || null;
        if (!textNode) return;
        const raw = textNode.nodeValue || '';
        const lead = (raw.match(/^\s*/) || [''])[0];
        const trail = (raw.match(/\s*$/) || [''])[0];
        textNode.nodeValue = lead + field.value + trail;
      });
      return;
    }
    if (section === 'homepage') {
      const eyebrow = doc.querySelector('.hero .eyebrow');
      const title = doc.querySelector('.hero h1');
      const primary = doc.querySelector('[data-cms-id="index-a-1"]');
      const secondary = doc.querySelector('[data-cms-id="index-a-2"]');
      if (eyebrow) eyebrow.textContent = value(values, 'eyebrow');
      if (title) title.innerHTML = `${escapeHtml(value(values, 'title'))}<br><span>${escapeHtml(value(values, 'accent'))}</span>`;
      if (primary) { primary.textContent = value(values, 'primary_text'); primary.href = value(values, 'primary_link', '#'); }
      if (secondary) { secondary.textContent = value(values, 'secondary_text'); secondary.href = value(values, 'secondary_link', '#'); }
      const hero = doc.querySelector('.hero-bg');
      const mobile = doc.querySelector('.hero picture source');
      if (hero && values.desktop_image) hero.src = assetUrl(doc, values.desktop_image);
      if (mobile && values.mobile_image) mobile.srcset = assetUrl(doc, values.mobile_image);
    }
    if (section === 'team') {
      const indices = [...new Set([...editorRoot.querySelectorAll('[name^="team["]')].map(field => field.name.match(/^team\[(\d+)\]/)?.[1]).filter(Boolean))];
      const grid = doc.querySelector('.team-grid');
      let cards = [...doc.querySelectorAll('.instructor-card')];
      const template = cards.at(-1);
      while (grid && template && cards.length < indices.length) {
        grid.appendChild(template.cloneNode(true));
        cards = [...doc.querySelectorAll('.instructor-card')];
      }
      indices.forEach((index, position) => {
        const get = key => editorRoot.querySelector(`[name="team[${index}][${key}]"]`);
        const name = get('name')?.value.trim();
        if (!cards[position]) return;
        const card = cards[position];
        card.hidden = !name || !get('active')?.checked;
        const set = (selector, text) => { const el = card.querySelector(selector); if (el) el.textContent = text || ''; };
        set('h2', name); set('.team-role-note', get('role')?.value); set('h3:not(.team-tagline)', get('classes')?.value); set('.team-tagline', get('tagline')?.value);
        const paragraphs = card.querySelectorAll('p');
        if (paragraphs[0]) paragraphs[0].textContent = get('description_1')?.value || '';
        if (paragraphs[1]) paragraphs[1].textContent = get('description_2')?.value || '';
        const image = card.querySelector('img'); if (image && get('image')?.value) image.src = assetUrl(doc, get('image').value);
      });
    }
    if (section === 'gallery') {
      const gallery = doc.querySelector('.gallery');
      if (gallery) {
        gallery.innerHTML = '';
        const indices = [...new Set([...editorRoot.querySelectorAll('[name^="gallery["]')].map(field => field.name.match(/^gallery\[(\d+)\]/)?.[1]).filter(Boolean))];
        indices.forEach(index => {
          const get = key => editorRoot.querySelector(`[name="gallery[${index}][${key}]"]`);
          if (!get('path')?.value || !get('active')?.checked || get('remove')?.checked) return;
          const image = doc.createElement('img'); image.src = assetUrl(doc, get('path').value); image.alt = get('alt')?.value || ''; gallery.appendChild(image);
        });
        if (values.new_gallery_path) { const image = doc.createElement('img'); image.src = assetUrl(doc, values.new_gallery_path); image.alt = values.new_gallery_alt || ''; gallery.appendChild(image); }
      }
    }
    if (section === 'prices') {
      const table = doc.querySelector('.price-matrix');
      if (table) {
        const priceFields = new Map();
        editorRoot.querySelectorAll('input[name^="price["]').forEach(field => {
          const match = field.name.match(/^price\[([^\]]+)\]\[(.+)\]$/);
          if (match) priceFields.set(`${match[1]}\u0000${match[2]}`, field.value);
        });
        const headers = [...table.querySelectorAll('thead th')].slice(1).map(item => item.textContent.trim());
        [...table.querySelectorAll('tbody tr')].forEach(row => {
          const label = row.querySelector('th')?.textContent.trim() || '';
          [...row.querySelectorAll('td')].forEach((cell, index) => {
            const fieldValue = priceFields.get(`${headers[index] || ''}\u0000${label}`);
            if (fieldValue !== undefined) cell.textContent = fieldValue;
          });
        });
        const mobileSelect = doc.querySelector('#mobile-price-class');
        const mobileCard = doc.querySelector('[data-mobile-price-card]');
        if (mobileSelect && mobileCard) {
          const selectedClass = mobileSelect.options[mobileSelect.selectedIndex]?.textContent.trim() || headers[0] || '';
          const columnIndex = headers.indexOf(selectedClass);
          if (columnIndex >= 0) {
            const heading = table.querySelectorAll('thead th')[columnIndex + 1];
            const rows = [...table.querySelectorAll('tbody tr')].map(row => ({
              label: row.querySelector('th')?.textContent.trim() || '',
              value: row.querySelectorAll('td')[columnIndex]?.textContent.trim() || ''
            }));
            const href = heading?.querySelector('a')?.getAttribute('href') || '#';
            mobileCard.innerHTML = `<header><div><span>Ausgewählte Klasse</span><h3>Klasse ${escapeHtml(selectedClass)}</h3></div><a href="${escapeHtml(href)}">Klassendetails →</a></header><div class="mobile-price-rows">${rows.map(item => `<div class="mobile-price-row${item.value === '–' ? ' is-empty' : ''}"><span>${escapeHtml(item.label)}</span><strong>${escapeHtml(item.value)}</strong></div>`).join('')}</div>`;
          }
        }
      }
    }
    if (section === 'summer') {
      const block = doc.querySelector('#summer-course-block');
      if (block) {
        const enabled = editorRoot.querySelector('[name="enabled"]')?.checked;
        const courseCards = [...editorRoot.querySelectorAll('[data-course-card]')].filter(card => !card.hidden && card.querySelector('[name$="[active]"]')?.checked);
        block.hidden = !enabled || courseCards.length === 0;
        const label = block.querySelector('#summer-course-label'); if (label) label.textContent = value(values, 'label');
        const title = block.querySelector('#summer-course-title'); if (title) title.textContent = value(values, 'title');
        const dates = block.querySelector('.summer-dates');
        if (dates) { dates.innerHTML = ''; courseCards.forEach((card, index) => { const get = key => card.querySelector(`[name$="[${key}]"]`)?.value || ''; const item = doc.createElement('div'); item.className = 'summer-date'; item.innerHTML = `<small>${escapeHtml(get('label') || `Kurs ${index + 1}`)}</small><strong>${escapeHtml(get('date'))}</strong><span>${escapeHtml(get('time'))}</span>`; dates.appendChild(item); }); }
        const button = block.querySelector('#summer-course-button'); if (button) { button.textContent = value(values, 'buttonText'); button.href = value(values, 'buttonLink', '#'); }
        if (!block.hidden) setTimeout(() => block.scrollIntoView({block:'center'}), 0);
      }
    }
    if (section === 'banner') {
      doc.querySelectorAll('.cms-banner[data-admin-live]').forEach(item => item.remove());
      const activeForm = editorRoot.querySelector('form.has-unsaved-changes') || primaryForm;
      const banner = formValues(activeForm);
      if (banner.title && banner.active !== false) {
        const el = doc.createElement('section'); el.className = 'cms-banner'; el.dataset.adminLive = '1';
        el.innerHTML = `<div class="container cms-banner-inner">${banner.image ? `<img src="${assetUrl(doc, banner.image)}" alt="">` : ''}<div><span class="eyebrow">Aktuell</span><h2>${escapeHtml(banner.title)}</h2><p>${escapeHtml(banner.text || '')}</p>${banner.buttonText ? `<a class="btn btn-primary" href="${escapeHtml(banner.buttonLink || '#')}">${escapeHtml(banner.buttonText)}</a>` : ''}</div></div>`;
        const hero = doc.querySelector('.hero');
        if (banner.position === 'before-hero' && hero) hero.before(el); else if (hero) hero.after(el); else doc.body.prepend(el);
      }
    }
    if (section === 'website') {
      const address = [values.address, values.postal_city].filter(Boolean).join(', ');
      doc.querySelectorAll('[data-cms-contact]').forEach(target => {
        const key = target.dataset.cmsContact;
        if (key === 'address') target.textContent = address;
        if (key === 'phone') { target.textContent = values.phone || ''; target.href = `tel:${values.phone_href || ''}`; }
        if (key === 'mobile') { target.textContent = values.mobile || ''; target.href = `tel:${values.mobile_href || ''}`; }
        if (key === 'email') { target.textContent = values.email || ''; target.href = `mailto:${values.email || ''}`; }
      });
      [
        ['kontakt-strong-1', address],
        ['kontakt-strong-2', [values.phone, values.mobile].filter(Boolean).join(' · ')],
        ['kontakt-strong-3', values.email],
        ['index-strong-3', values.office_hours],
        ['index-strong-4', values.theory_hours],
        ['index-strong-5', values.phone],
        ['index-strong-6', values.address]
      ].forEach(([id, text]) => {
        const target = doc.querySelector(`[data-cms-id="${id}"]`);
        if (target) target.textContent = text || '';
      });
      doc.querySelectorAll('a[href^="tel:"]').forEach(link => {
        const compact = link.textContent.replace(/\s+/g, '');
        if (compact.includes((values.mobile || '').replace(/\s+/g, ''))) link.href = `tel:${values.mobile_href || ''}`;
        else link.href = `tel:${values.phone_href || ''}`;
      });
      doc.querySelectorAll('a[href^="mailto:"]').forEach(link => { link.href = `mailto:${values.email || ''}`; });

      const footer = doc.querySelector('.footer');
      if (footer) {
        const cols = [...footer.querySelectorAll('.footer-grid > div')];
        const tagline = cols[0]?.querySelector('p'); if (tagline) tagline.textContent = values.footer_tagline || tagline.textContent;
        const heading = (col, idx, text) => { const el = cols[col]?.querySelectorAll('h4')?.[idx]; if (el && text) el.textContent = text; };
        heading(1,0,values.footer_contact_title); heading(2,0,values.footer_school_title); heading(2,1,values.footer_forms_title); heading(3,0,values.footer_legal_title);
        const setLinks = (column, rows) => { const links=[...(cols[column]?.querySelectorAll('a')||[])]; rows.forEach((row,i)=>{ if(!links[i]) return; if(row[0]) links[i].textContent=row[0]; if(row[1]) links[i].href=row[1]; }); };
        setLinks(2, [[values.footer_licenses_label,values.footer_licenses_href],[values.footer_motorcycle_label,values.footer_motorcycle_href],[values.footer_prices_label,values.footer_prices_href],[values.footer_calendar_label,values.footer_calendar_href],[values.footer_registration_label,values.footer_registration_href],[values.footer_form1_label,values.footer_form1_href],[values.footer_form2_label,values.footer_form2_href]]);
        setLinks(3, [[values.footer_privacy_label,values.footer_privacy_href],[values.footer_imprint_label,values.footer_imprint_href],[values.footer_agb_label,values.footer_agb_href],[values.footer_cookie_label,values.footer_cookie_href]]);
        const note=footer.querySelector('.footer-note');
        if(note){ note.innerHTML=`<span class="footer-owner">© ${escapeHtml(values.footer_year||'2026')} ${escapeHtml(values.school_name||'Fahrschule BV')} · ${escapeHtml(values.footer_owner_label||'Inhaber')} ${escapeHtml(values.owner||'Vitali Bek')}</span><span class="footer-creator">${escapeHtml(values.footer_creator_label||'Webdesign & Entwicklung')}: ${escapeHtml(values.footer_creator_name||'Vladimir Sili')}</span>`; }
      }
      const dock=[values.dock_whatsapp_label||'WhatsApp',values.dock_email_label||'E-Mail',values.dock_phone_label||'Telefon'];
      doc.querySelectorAll('.contact-dock .dock-btn strong').forEach((el,i)=>{ if(dock[i]) el.textContent=dock[i]; });
    }
    if (section === 'navigation') {
      const nav = doc.querySelector('.navlinks');
      if (nav) {
        nav.innerHTML = '';
        const indices = [...new Set([...editorRoot.querySelectorAll('[name^="label["]')].map(field => field.name.match(/^label\[(\d+)\]/)?.[1]).filter(Boolean))];
        indices.forEach(index => {
          const get = key => editorRoot.querySelector(`[name="${key}[${index}]"]`);
          if (!get('label')?.value || !get('enabled')?.checked || get('remove')?.checked) return;
          const link = doc.createElement('a'); link.textContent = get('label').value; link.href = get('href')?.value || '#'; if (get('button')?.checked) link.className = 'btn btn-primary'; nav.appendChild(link);
        });
      }
    }
    if (section === 'design') {
      const root = doc.documentElement;
      ['orange','orange2','black','text'].forEach(key => { if (values[key]) root.style.setProperty(`--${key}`, values[key]); });
      if (values.font) doc.body.style.fontFamily = values.font;
      if (values.base_size) root.style.fontSize = `${values.base_size}px`;
    }
    if (section === 'seo') {
      if (values.title) doc.title = values.title;
      const title = document.querySelector('.google-card h3'); if (title) title.textContent = values.title || title.textContent;
      const desc = document.querySelector('.google-card p'); if (desc) desc.textContent = values.description || desc.textContent;
    }
  }

  function escapeHtml(input) {
    return String(input ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  }

  createPreview();
  if (section === 'pages') {
    const frame = document.querySelector('[data-preview]');
    const resolvePreviewTarget = field => {
      const doc = frame?.contentDocument;
      if (!doc || !field?.dataset.fullXpath) return null;
      try { return doc.evaluate(field.dataset.fullXpath, doc, null, doc.defaultView.XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; } catch (_) { return null; }
    };
    const clearHighlight = () => {
      const doc = frame?.contentDocument;
      doc?.querySelectorAll('[data-admin-highlight]').forEach(el => { el.style.outline = el.dataset.adminOldOutline || ''; el.style.outlineOffset = el.dataset.adminOldOutlineOffset || ''; delete el.dataset.adminHighlight; delete el.dataset.adminOldOutline; delete el.dataset.adminOldOutlineOffset; });
    };
    const highlightField = field => {
      clearHighlight();
      const target = resolvePreviewTarget(field);
      if (!target || target.nodeType !== 1) return;
      target.dataset.adminOldOutline = target.style.outline || '';
      target.dataset.adminOldOutlineOffset = target.style.outlineOffset || '';
      target.dataset.adminHighlight = '1';
      target.style.outline = '3px solid #f47a20';
      target.style.outlineOffset = '4px';
      target.scrollIntoView({behavior:'smooth', block:'center'});
    };
    frame?.addEventListener('load', () => { setTimeout(updateLivePreview, 350); setTimeout(updateLivePreview, 1000); });
    document.querySelectorAll('.editor-panel [data-full-id]').forEach(field => {
      field.addEventListener('input', updateLivePreview);
      field.addEventListener('focus', () => highlightField(field));
    });
    document.querySelector('[data-full-editor-search]')?.addEventListener('input', event => {
      const q = String(event.target.value || '').trim().toLowerCase();
      document.querySelectorAll('[data-full-row]').forEach(row => { row.hidden = !!q && !(row.dataset.search || '').includes(q); });
      document.querySelectorAll('[data-full-group]').forEach(group => {
        const visible = [...group.querySelectorAll('[data-full-row]')].some(row => !row.hidden);
        group.hidden = !visible;
        if (q && visible) group.open = true;
      });
    });
    document.querySelectorAll('[data-page-preview-mode]').forEach(button => button.addEventListener('click', () => {
      document.querySelectorAll('[data-page-preview-mode]').forEach(item => item.classList.toggle('active', item === button));
      document.querySelector('.studio-layout')?.classList.toggle('page-preview-mobile', button.dataset.pagePreviewMode === 'mobile');
    }));
  }
})();
