(() => {
  const root = document.querySelector('[data-visual-editor]');
  if (!root) return;
  const frame = root.querySelector('[data-visual-frame]');
  const list = root.querySelector('[data-visual-list]');
  const status = root.querySelector('[data-visual-status]');
  const save = root.querySelector('[data-visual-save]');
  const discard = root.querySelector('[data-visual-discard]');
  const dialog = root.querySelector('[data-visual-dialog]');
  const fields = root.querySelector('[data-visual-fields]');
  const apply = root.querySelector('[data-visual-apply]');
  const error = root.querySelector('[data-visual-error]');
  const search = root.querySelector('[data-visual-search]');
  const changes = new Map();
  let entries = [], tab = 'all', selected = null, readyDocument = null, version = root.dataset.version;
  let loading = false, saving = false, returnFocus = null;
  const maxUpload = Number(root.dataset.maxUpload) || 2*1024*1024;
  const uploadSize = (maxUpload/1024/1024).toLocaleString('de-DE',{maximumFractionDigits:1});
  const key = row => `${row.xpath}|${row.type}|${row.index ?? row.attr ?? row.field ?? ''}|${row.pseudo || ''}`;
  const xpath = element => {
    const parts = [];
    for (let el = element; el?.nodeType === 1; el = el.parentElement) {
      let index = 1;
      for (let previous = el.previousElementSibling; previous; previous = previous.previousElementSibling) {
        if (previous.localName === el.localName) index++;
      }
      parts.unshift(`${el.localName}[${index}]`);
    }
    return '/' + parts.join('/');
  };
  const previewUrl = value => {
    try { return new URL(value.split(',')[0].trim().split(/\s+/)[0], frame.contentDocument.baseURI).href; } catch (_) { return ''; }
  };
  const updateState = message => {
    status.textContent = message || (changes.size ? `${changes.size} Änderungen · noch nicht veröffentlicht` : 'Bereit. Wählen Sie einen Text oder ein Bild.');
    save.disabled = !changes.size || saving || loading;
    save.textContent = saving ? 'Wird gespeichert …' : 'Speichern & veröffentlichen';
    discard.hidden = !changes.size;
  };
  function renderList() {
    const query = search.value.trim().toLocaleLowerCase('de');
    const isLink = entry => entry.type === 'attribute' && entry.attr === 'href';
    const group = entry => {
      if (entry.type === 'metadata') return 'Seitendaten für Google';
      if (entry.element.closest('header, nav')) return 'Kopfzeile und Menü';
      if (entry.element.closest('footer, .footer')) return 'Fußzeile';
      if (entry.element.closest('.contact-dock')) return 'Kontaktbuttons';
      return 'Seiteninhalt';
    };
    const order = ['Seiteninhalt','Kopfzeile und Menü','Fußzeile','Kontaktbuttons','Seitendaten für Google'];
    const visible = entries.filter(entry => (tab === 'all' || (tab === 'image' ? entry.type === 'image' : tab === 'link' ? isLink(entry) : entry.type !== 'image' && !isLink(entry))) && `${entry.label} ${entry.value}`.toLocaleLowerCase('de').includes(query));
    visible.sort((a,b)=>order.indexOf(group(a))-order.indexOf(group(b)));
    list.replaceChildren();
    let lastGroup = '';
    for (const entry of visible) {
      if (group(entry) !== lastGroup) {
        lastGroup = group(entry);
        const heading = document.createElement('h3');heading.className='visual-group-heading';heading.textContent=lastGroup;list.append(heading);
      }
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'visual-list-item';button.dataset.contentType=entry.type;button.dataset.contentAttr=entry.attr || entry.field || '';
      if (entry.type === 'image') {
        const image = document.createElement('img'); image.src = previewUrl(entry.value); image.alt = ''; image.loading = 'lazy'; button.append(image);
      }
      const title = document.createElement('span');title.className='visual-card-copy';
      const label = document.createElement('b');label.textContent=entry.binding ? `Preis · ${entry.binding.class} · ${entry.binding.label}` : entry.type==='image' ? entry.label : entry.type==='metadata' ? entry.label : isLink(entry) ? 'Linkziel' : entry.type==='attribute' ? entry.label : 'Text';
      const content = document.createElement('span');content.className='visual-card-value';content.textContent=entry.type==='image' ? 'Bild dieser Seite ersetzen' : entry.value || '(Noch kein Text)';
      title.append(label,content);button.title = entry.label;
      const action = document.createElement('small'); action.textContent = entry.type==='image' ? 'Bild ändern' : isLink(entry) ? 'Link ändern' : 'Text ändern';
      button.append(title, action); button.addEventListener('click', () => openEditor(entry)); list.append(button);
    }
    if (!visible.length) { const empty = document.createElement('p'); empty.className = 'visual-list-empty'; empty.textContent = query ? 'Keine passenden Inhalte gefunden.' : 'Keine Inhalte in dieser Kategorie.'; list.append(empty); }
    root.querySelector('[data-text-count]').textContent = entries.filter(row => row.type !== 'image' && !isLink(row)).length;
    root.querySelector('[data-image-count]').textContent = entries.filter(row => row.type === 'image').length;
    root.querySelector('[data-link-count]').textContent = entries.filter(isLink).length;
  }
  function scan(doc) {
    entries = [];
    const excluded = 'script,style,noscript,iframe,object,embed,template,svg';
    const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      const parent = node.parentElement;
      if (!parent || parent.closest(excluded)) continue;
      const index = [...parent.childNodes].filter(child => child.nodeType === Node.TEXT_NODE).indexOf(node);
      if (!node.nodeValue.trim() && !parent.bvVisualTextSlots?.has(index)) continue;
      entries.push({xpath:xpath(parent), type:'text', index, value:node.nodeValue, label:node.nodeValue.trim() || '(Leerer Text)', element:parent, node});
    }
    doc.body.querySelectorAll('*').forEach(element => {
      if (element.closest(excluded)) return;
      const attributes = ['alt','title','placeholder','aria-label'];
      if (element.matches('a[href]')) attributes.push('href');
      if (element.matches('input[type=submit], input[type=button], input[type=reset]')) attributes.push('value');
      for (const attr of attributes) {
        if (!element.hasAttribute(attr)) continue;
        const value = element.getAttribute(attr);
        entries.push({xpath:xpath(element),type:'attribute',attr,value,label:`${attr === 'alt' ? 'Bildbeschreibung' : 'Beschriftung'}: ${value || element.localName}`,element});
      }
      if (element.matches('img[src], source[srcset]')) {
        const attr = element.matches('source') ? 'srcset' : 'src';
        const value = element.getAttribute(attr);
        entries.push({xpath:xpath(element),type:'image',attr,value,label:element.matches('source') ? `Bildvariante${element.media?.includes('max-width') ? ' (Mobil)' : ''}` : element.alt || value.split('/').pop(),element});
      }
      const background = doc.defaultView.getComputedStyle(element).backgroundImage;
      const match = background.match(/url\(["']?([^"')]+)["']?\)/);
      if (match) entries.push({xpath:xpath(element),type:'image',attr:'background',value:match[1],label:`Hintergrundbild · ${element.closest('section')?.querySelector('h1,h2')?.textContent.trim() || element.localName}`,element});
      for (const pseudo of ['::before','::after']) {
        const image = doc.defaultView.getComputedStyle(element,pseudo).backgroundImage.match(/url\(["']?([^"')]+)["']?\)/);
        if (image) entries.push({xpath:xpath(element),type:'image',attr:'background',pseudo,value:image[1],label:`Hintergrundeffekt · ${element.closest('section')?.querySelector('h1,h2')?.textContent.trim() || element.localName}`,element});
      }
    });
    entries.forEach(entry=>{
      if(entry.type!=='text')return;
      const binding=entry.element.bvPriceBinding || entry.element.closest('td, .mobile-price-row strong')?.bvPriceBinding;
      if(binding){entry.binding=binding;entry.label=`Preis · ${binding.class} · ${binding.label}`;}
    });
    entries.push({xpath:'/html[1]/head[1]',type:'metadata',field:'title',value:doc.title,label:'Seitentitel für Google',element:doc.head});
    entries.push({xpath:'/html[1]/head[1]',type:'metadata',field:'description',value:doc.querySelector('meta[name=description]')?.content || '',label:'Beschreibung für Google',element:doc.head});
    renderList();
  }
  function writeChange(entry, value) {
    if(entry.binding) {
      const peers=entries.filter(item=>item.binding?.class===entry.binding.class && item.binding?.label===entry.binding.label);
      peers.forEach(item=>{item.node.nodeValue=value;item.value=value;});
      changes.set(`price|${entry.binding.class}|${entry.binding.label}`,{xpath:entry.xpath,type:'price',class:entry.binding.class,label:entry.binding.label,value,paths:[...new Set(peers.map(item=>item.xpath))]});
      return;
    }
    if (entry.type === 'text') entry.node.nodeValue = value;
    else if (entry.type === 'metadata') {
      const doc=frame.contentDocument;
      if(entry.field==='title')doc.title=value;
      else {let meta=doc.querySelector('meta[name=description]');if(!meta){meta=doc.createElement('meta');meta.name='description';doc.head.append(meta);}meta.content=value;}
    }
    else if (entry.attr === 'background') {
      // Preserve gradient layers over background photos.
      const background = frame.contentWindow.getComputedStyle(entry.element,entry.pseudo || null).backgroundImage;
      const replacement = `url("${new URL(value, frame.contentDocument.baseURI).href}")`;
      const result = /url\(/.test(background) ? background.replace(/url\(["']?[^"')]+["']?\)/, replacement) : (background === 'none' ? replacement : `${background}, ${replacement}`);
      if (entry.pseudo) {
        const selector = entry.xpath.slice(1).replace(/\/+/g,' > ').replace(/\[(\d+)\]/g,':nth-of-type($1)') + entry.pseudo;
        let style = entry.previewStyle;
        if (!style) {style = frame.contentDocument.createElement('style');frame.contentDocument.head.append(style);entry.previewStyle=style;}
        style.textContent = `${selector}{background-image:${result}!important}`;
      } else entry.element.style.setProperty('background-image',result,'important');
    } else entry.element.setAttribute(entry.attr, value);
    entry.value = value;
    if (entry.type === 'text') entry.label = value.trim() || '(Leerer Text)';
    changes.set(key(entry), {xpath:entry.xpath,type:entry.type,value,...(entry.type === 'text' ? {index:entry.index} : entry.type==='metadata' ? {field:entry.field} : {attr:entry.attr}),...(entry.pseudo ? {pseudo:entry.pseudo} : {})});
  }
  function openEditor(entry) {
    if (loading || saving) return;
    selected = entry; returnFocus = document.activeElement;
    const slide = entry.element.closest('.home-slide');
    if (slide) {
      frame.contentDocument.querySelectorAll('.home-slide').forEach(item => {const active=item===slide;item.classList.toggle('is-active',active);item.setAttribute('aria-hidden',String(!active));item.inert=!active;});
    }
    fields.replaceChildren(); error.textContent = '';
    root.querySelector('#visual-dialog-title').textContent = entry.type === 'image' ? 'Bild ändern' : entry.attr==='href' ? 'Link ändern' : entry.type==='metadata' ? entry.label : 'Text bearbeiten';
    const doc = frame.contentDocument;
    doc.querySelectorAll('[data-bv-selected]').forEach(element => element.removeAttribute('data-bv-selected'));
    const highlight = entry.element.matches('source') ? entry.element.parentElement.querySelector('img') : entry.element;
    if (highlight && entry.type!=='metadata') { highlight.setAttribute('data-bv-selected',''); highlight.scrollIntoView({block:'center',behavior:'smooth'}); }
    if (entry.type === 'image') {
      const image = document.createElement('img'); image.className = 'visual-image-preview'; image.src = previewUrl(entry.value); image.alt = 'Ausgewähltes Bild';
      const label = document.createElement('label'); label.textContent = 'Neues Bild auswählen';
      const input = document.createElement('input'); input.type = 'file'; input.name = 'image'; input.accept = 'image/jpeg,image/png,image/webp,image/gif,image/avif'; label.append(input);
      const note = document.createElement('p'); note.className = 'visual-upload-note'; note.textContent = `JPG, PNG, WEBP, GIF oder AVIF · maximal ${uploadSize} MB. Das ursprüngliche Bild bleibt erhalten. Die Änderung gilt nur an dieser Stelle auf dieser Seite.`;
      fields.append(image,label,note);
      input.addEventListener('change', () => {
        if (!input.files[0]) return;
        const reader = new FileReader(); reader.onload = () => {image.src = reader.result;}; reader.readAsDataURL(input.files[0]);
      });
      if (entry.element.matches('img') && entry.element.closest('picture')?.querySelector('source')) {
        const related = document.createElement('label'); related.className = 'check';
        const checkbox = document.createElement('input'); checkbox.type='checkbox'; checkbox.name='variants'; checkbox.checked=true;
        related.append(checkbox,document.createTextNode('Auch für die Bildvarianten (z. B. Mobil) verwenden')); fields.append(related);
      }
    } else {
      const label = document.createElement('label'); label.textContent = entry.attr==='href' ? 'Zieladresse des Links' : entry.type === 'metadata' ? entry.label : entry.type === 'attribute' ? 'Beschriftung ändern' : 'Text ändern';
      const input = document.createElement('textarea'); input.name='text'; input.value=entry.value; input.maxLength=10000; label.append(input); fields.append(label);
    }
    dialog.showModal();
    fields.querySelector('textarea,input')?.focus();
  }
  function closeDialog() { dialog.close(); returnFocus?.focus(); }
  root.querySelectorAll('[data-visual-cancel]').forEach(button => button.addEventListener('click', () => {if (!loading) closeDialog();}));
  dialog.addEventListener('cancel', event => {if (loading) event.preventDefault();});
  root.querySelector('[data-visual-form]').addEventListener('submit', async event => {
    event.preventDefault(); if (!selected || loading) return;
    loading=true; apply.disabled=true; error.textContent='';
    try {
      if (selected.type === 'image') {
        const file = fields.querySelector('input[type=file]').files[0];
        if (!file) throw new Error('Bitte ein neues Bild auswählen.');
        if (file.size > maxUpload) throw new Error(`Das Bild ist zu groß. Maximal ${uploadSize} MB.`);
        const data = new FormData(); data.set('csrf',root.dataset.csrf);data.set('image',file);
        const response = await fetch('editor-upload.php',{method:'POST',body:data});
        const result = await response.json(); if (!response.ok || !result.ok) throw new Error(result.error || 'Upload fehlgeschlagen.');
        writeChange(selected,result.path);
        if (fields.querySelector('[name=variants]')?.checked) {
          const picture = selected.element.closest('picture');
          entries.filter(entry=>entry.type==='image' && entry.attr==='srcset' && entry.element.parentElement===picture).forEach(entry=>writeChange(entry,result.path));
        }
      } else writeChange(selected,fields.querySelector('textarea').value);
      renderList(); closeDialog();
    } catch (exception) {error.textContent=exception.message || 'Die Änderung konnte nicht übernommen werden.';}
    finally {loading=false;apply.disabled=false;updateState();}
  });
  function connect() {
    const doc = frame.contentDocument;
    if (!doc?.body || doc===readyDocument) return;
    const setup = () => {
      if (doc===readyDocument || frame.contentDocument!==doc) return;
      readyDocument=doc;doc.defaultView.bvEditorPreview=true;
      const style=doc.createElement('style');
      style.textContent='[data-bv-selected]{outline:3px solid #f47a20!important;outline-offset:4px!important}body{cursor:crosshair!important}a,button{cursor:crosshair!important}';doc.head.append(style);
      // Freeze automatic slideshows so choosing a photo stays predictable.
      doc.querySelectorAll('.home-slide').forEach((slide,index)=>slide.style.animationPlayState='paused');
      scan(doc);updateState();
      doc.addEventListener('click',event=>{
        event.preventDefault();event.stopImmediatePropagation();
        const target=event.target;
        if (!(target instanceof doc.defaultView.Element)) return;
        let entry=entries.find(row=>row.type==='image' && row.element===target);
        if (!entry) entry=entries.find(row=>row.type==='text' && row.element===target);
        if (!entry) entry=entries.find(row=>row.type==='text' && target.contains(row.element));
        if (!entry) entry=entries.find(row=>row.type==='attribute' && row.element===target);
        if (!entry) {for(let el=target;el && !entry;el=el.parentElement)entry=entries.find(row=>row.type==='image' && row.element===el);}
        if (entry) openEditor(entry);
      },true);
      doc.addEventListener('submit',event=>event.preventDefault(),true);
    };
    if (doc.documentElement.dataset.cmsReady==='true') setup();
    else doc.addEventListener('bv:cms-ready',setup,{once:true});
    // A failed CMS request is an error, not an empty editable page.
    setTimeout(()=>{if(readyDocument!==doc && frame.contentDocument===doc)updateState('Die Vorschau konnte nicht vollständig geladen werden. Bitte neu laden.');},15000);
  }
  frame.addEventListener('load',connect);if(frame.contentDocument?.readyState==='complete')connect();
  root.querySelectorAll('[data-visual-tab]').forEach(button=>button.addEventListener('click',()=>{
    tab=button.dataset.visualTab;
    root.querySelectorAll('[data-visual-tab]').forEach(item=>{const active=item===button;item.classList.toggle('active',active);item.setAttribute('aria-pressed',String(active));});
    renderList();
  }));
  search.addEventListener('input',renderList);
  if (root.dataset.initialTab === 'image') root.querySelector('[data-visual-tab=image]').click();
  root.querySelectorAll('[data-visual-mode]').forEach(button=>button.addEventListener('click',()=>{
    root.querySelector('.visual-preview').classList.toggle('is-mobile',button.dataset.visualMode==='mobile');
    root.querySelectorAll('[data-visual-mode]').forEach(item=>{const active=item===button;item.classList.toggle('active',active);item.setAttribute('aria-pressed',String(active));});
  }));
  const confirmDiscard=()=>!changes.size || confirm('Ungespeicherte Änderungen verwerfen?');
  discard.addEventListener('click',()=>{if(confirmDiscard()){changes.clear();readyDocument=null;frame.src=`../${encodeURIComponent(root.dataset.page)}?editor-preview=${Date.now()}`;updateState('Vorschau wird neu geladen …');}});
  save.addEventListener('click',async()=>{
    if(!changes.size || saving)return;
    saving=true;updateState('Änderungen werden gespeichert …');
    try {
      const data=new FormData();data.set('csrf',root.dataset.csrf);data.set('page',root.dataset.page);data.set('version',version);data.set('changes',JSON.stringify([...changes.values()]));
      const response=await fetch('editor-save.php',{method:'POST',body:data});const result=await response.json();
      if(!response.ok || !result.ok)throw new Error(result.error || 'Speichern fehlgeschlagen.');
      version=String(result.version);changes.clear();saving=false;updateState('Gespeichert und veröffentlicht.');
    } catch(exception){saving=false;updateState(exception.message || 'Speichern fehlgeschlagen. Ihre Änderungen bleiben in der Vorschau.');}
  });
  window.addEventListener('beforeunload',event=>{if(changes.size){event.preventDefault();event.returnValue='';}});
})();
