(() => {
  'use strict';
  const root=document.querySelector('[data-promo-admin]');if(!root)return;
  const kind=root.dataset.kind,popup=kind==='popups',form=root.querySelector('[data-promo-form]');
  const library=root.querySelector('[data-promo-library]'),recordsHost=root.querySelector('[data-promo-records]');
  const notice=root.querySelector('[data-promo-notice]'),canvas=root.querySelector('[data-promo-canvas]'),viewport=root.querySelector('[data-promo-viewport]'),frame=root.querySelector('[data-promo-frame]');
  let items=[],pages={},defaults={},model={},id='',version=0,dirty=false,busy=false,device='desktop',previewCleanup=()=>{},previewPage='index.html';
  const clone=value=>JSON.parse(JSON.stringify(value));
  const element=(tag,cls,text)=>{const el=document.createElement(tag);if(cls)el.className=cls;if(text!==undefined)el.textContent=text;return el;};
  const message=(text,error=false)=>{notice.textContent=text;notice.hidden=false;notice.className=`alert ${error?'error':'success'}`;};
  const field=name=>form.elements.namedItem(name);
  const publicPath=path=>new URL('../'+path,location.href).href;
  const state=()=>{
    root.querySelectorAll('[data-promo-save],[data-promo-publish]').forEach(button=>button.disabled=busy);
    root.querySelector('[data-promo-delete]').disabled=busy||!id;
    const record=items.find(record=>record.id===id);root.querySelector('[data-promo-deactivate]').disabled=busy||!record?.published?.active;
    root.querySelector('[data-promo-dirty]').textContent=dirty?'Ungespeicherte Änderungen. Die öffentliche Version bleibt unverändert.':'Die Vorschau ist privat. Erst „Veröffentlichen“ verändert die öffentliche Version.';
  };
  function collect(){
    const result=clone(model);
    for(const input of form.querySelectorAll('[data-promo-field]')){
      if(['targetMode','countdownEnabled','countdownEnd','countdownPlacement','countdownAlign','countdownOffset'].includes(input.name))continue;
      result[input.name]=input.type==='checkbox'?input.checked:input.type==='number'?(Number(input.value)||0):input.value;
    }
    result.targets={mode:field('targetMode').value,pages:[...root.querySelectorAll('[data-promo-page]:checked')].map(input=>input.value)};
    result.startAt=BVPromotions.berlinTime(result.start);result.endAt=BVPromotions.berlinTime(result.end);
    if(popup)result.countdown={enabled:field('countdownEnabled').checked,end:field('countdownEnd').value,endAt:BVPromotions.berlinTime(field('countdownEnd').value),placement:field('countdownPlacement').value,align:field('countdownAlign').value,offset:Number(field('countdownOffset').value)||0};
    else {
      result.buttons=[...root.querySelectorAll('[data-promo-button-row]')].map(row=>({text:row.querySelector('[data-button-text]').value,url:row.querySelector('[data-button-url]').value}));
      result.placements={...(result.placements||{})};for(const select of root.querySelectorAll('[data-promo-position]')){if(select.value)result.placements[select.dataset.promoPosition]=select.value;else delete result.placements[select.dataset.promoPosition];}
    }
    return result;
  }
  function effectivePages(data){return data.targets.mode==='all'?Object.keys(pages):data.targets.mode==='home'?['index.html']:data.targets.pages;}
  function targetControls(){
    const selected=effectivePages(model);root.querySelector('[data-promo-target-box]').hidden=model.targets.mode!=='selected';
    if(popup){root.querySelector('[data-promo-countdown-fields]').hidden=!model.countdown.enabled;return;}
    const select=root.querySelector('[data-promo-preview-page]');const previous=select.value||previewPage;select.replaceChildren();
    for(const file of selected.length?selected:['index.html']){const option=element('option','',pages[file]?.label||file);option.value=file;select.append(option);}select.value=selected.includes(previous)?previous:select.options[0].value;previewPage=select.value;
    const positions=root.querySelector('[data-promo-placements]');positions.replaceChildren();
    for(const file of selected){const label=element('label','',pages[file]?.label||file);const input=element('select');input.dataset.promoPosition=file;const normal=element('option','','Standardposition');normal.value='';input.append(normal);
      for(const [key,title] of Object.entries(pages[file].positions)){const option=element('option','',title);option.value=key;input.append(option);}input.value=model.placements?.[file]||'';label.append(input);positions.append(label);}
  }
  function imageControls(){
    const host=root.querySelector('[data-promo-images]');host.replaceChildren();
    const images=popup?(model.image?[model.image]:[]):model.images;
    images.forEach((path,index)=>{const row=element('div','promo-image-row');const image=element('img');image.src=publicPath(path);image.alt=popup?'Pop-up-Bild':`Aktionsbild ${index+1}`;const actions=element('div');
      if(!popup){const label=element('label','promo-file-button','Ersetzen');const input=element('input');input.type='file';input.accept='image/jpeg,image/png,image/webp,image/gif,image/avif';input.addEventListener('change',()=>upload(input.files,index));label.append(input);actions.append(label);}
      const remove=element('button','btn danger smallbtn','Entfernen');remove.type='button';remove.addEventListener('click',()=>{if(busy)return;model=collect();if(popup)model.image='';else model.images.splice(index,1);dirty=true;imageControls();renderPreview();state();releaseImage(path).catch(()=>message('Bild aus dem Entwurf entfernt. Die Dateibereinigung kann später erneut versucht werden.',true));});actions.append(remove);row.append(image,actions);host.append(row);});
  }
  function buttonControls(){
    if(popup)return;const host=root.querySelector('[data-promo-buttons]');host.replaceChildren();
    model.buttons.forEach((data,index)=>{const row=element('div','promo-button-editor');row.dataset.promoButtonRow='';
      for(const [key,label] of [['text','Button-Text'],['url','Button-Link']]){const wrapper=element('label','',label);const input=element('input');input.value=data[key]||'';input.maxLength=key==='text'?100:1000;input.dataset[key==='text'?'buttonText':'buttonUrl']='';wrapper.append(input);row.append(wrapper);}
      const remove=element('button','btn danger smallbtn','Button entfernen');remove.type='button';remove.addEventListener('click',()=>{model=collect();model.buttons.splice(index,1);dirty=true;buttonControls();renderPreview();state();});row.append(remove);host.append(row);});
    root.querySelector('[data-promo-add-button]').disabled=model.buttons.length>=3;
  }
  function fill(data){
    model=clone(data);for(const input of form.querySelectorAll('[data-promo-field]')){if(input.type==='checkbox')input.checked=Boolean(model[input.name]);else if(Object.prototype.hasOwnProperty.call(model,input.name))input.value=model[input.name];}
    field('targetMode').value=model.targets.mode;
    root.querySelectorAll('[data-promo-page]').forEach(input=>input.checked=model.targets.pages.includes(input.value));
    if(popup){field('countdownEnabled').checked=model.countdown.enabled;field('countdownEnd').value=model.countdown.end;field('countdownPlacement').value=model.countdown.placement;field('countdownAlign').value=model.countdown.align;field('countdownOffset').value=model.countdown.offset;}
    buttonControls();imageControls();targetControls();dirty=false;state();renderPreview();
  }
  function choose(next){
    if(!defaults.targets)return;
    if(dirty&&!confirm('Ungespeicherte Änderungen verwerfen?'))return;
    const record=items.find(item=>item.id===next);id=record?.id||'';
    root.querySelector('[data-promo-heading]').textContent=popup?(id?'Pop-up bearbeiten':'Neues Pop-up'):(id?'Aktion bearbeiten':'Neue Aktion');
    root.querySelector('[data-promo-state]').textContent=record?.published?'VERÖFFENTLICHTE VERSION UND ENTWURF':'ENTWURF · NICHT ÖFFENTLICH';
    fill(record?record.draft:{...clone(defaults),active:true});if(id)library.open=false;
  }
  function recordStatus(record){
    const pub=record.published;if(!pub)return 'Entwurf';if(!pub.active)return 'Deaktiviert';if(pub.endAt!=null&&pub.endAt<=Date.now())return 'Abgelaufen';if(pub.startAt!=null&&pub.startAt>Date.now())return 'Geplant';return JSON.stringify(record.draft)!==JSON.stringify(pub)?'Veröffentlicht · Entwurf geändert':'Veröffentlicht';
  }
  function renderRecords(){
    recordsHost.replaceChildren();root.querySelector('[data-promo-total]').textContent=String(items.length);
    const sorted=[...items].sort((a,b)=>popup?b.draft.priority-a.draft.priority:a.draft.order-b.draft.order);
    if(!sorted.length)recordsHost.append(element('p','promo-help',popup?'Noch keine Pop-ups vorhanden.':'Noch keine Aktionen vorhanden.'));
    for(const record of sorted){const card=element('article','promo-record');const imagePath=popup?record.draft.image:record.draft.images[0];if(imagePath){const image=element('img');image.src=publicPath(imagePath);image.alt=popup?'Pop-up-Vorschaubild':record.draft.title||'Aktionsbild';card.append(image);}
      card.append(element('strong','',popup?`Pop-up ${record.id.slice(-6)}`:record.draft.title||'Unbenannte Aktion'),element('span','badge',recordStatus(record)),element('small','',popup?`Priorität: ${record.draft.priority}`:`Reihenfolge: ${record.draft.order}`));
      const controls=element('div','promo-record-actions');for(const [label,op] of [['Bearbeiten','edit'],['Duplizieren','duplicate'],['Löschen','delete']]){const button=element('button',`btn ${op==='delete'?'danger':'ghost'}`,label);button.type='button';button.addEventListener('click',()=>{if(op==='edit')choose(record.id);else if(op==='delete'){if(confirm('Diesen Eintrag und seine Veröffentlichung wirklich löschen?'))mutate('delete',record.id);}else if(!dirty||confirm('Ungespeicherte Änderungen verwerfen?'))mutate('duplicate',record.id);});controls.append(button);}card.append(controls);recordsHost.append(card);}
  }
  function resizePreview(){
    const width=device==='mobile'?390:device==='tablet'?768:popup?900:1200;
    if(!viewport.clientWidth)return;
    const scale=Math.min(1,viewport.clientWidth/width);const height=viewport.clientHeight/scale;
    canvas.style.width=`${width}px`;canvas.style.height=`${height}px`;canvas.style.transform=`scale(${scale})`;
    canvas.style.setProperty('--bv-preview-image-height',`${Math.max(200,height-70-(popup&&model.countdown?.enabled&&model.countdown.placement==='below'?100+model.countdown.offset:0))}px`);
  }
  function sendPreview(){if(!frame?.contentWindow)return;const item={...collect(),id:id||'private-preview'};frame.contentWindow.postMessage({type:'bv:promo-preview',item},location.origin);}
  function renderPreview(){
    if(!Object.keys(model).length)return;
    previewCleanup();previewCleanup=()=>{};
    if(popup){canvas.replaceChildren();canvas.classList.add('promo-popup-canvas');const current=collect();const preview={...current,image:current.image?publicPath(current.image):''};const bar=element('div','bv-popup-closebar');const close=element('button','bv-popup-close','×');close.type='button';close.setAttribute('aria-label','Pop-up in voller Vorschau öffnen');close.addEventListener('click',()=>{if(full.open)closeFull();else{previewCleanup();canvas.replaceChildren(element('p','bv-promo-empty','Vorschau geschlossen. Über „Vorschau“ erneut öffnen.'));}});bar.append(close);const visual=BVPromotions.popupVisual(preview);canvas.append(bar,visual.element);previewCleanup=visual.destroy;}
    else {const selected=root.querySelector('[data-promo-preview-page]').value||'index.html';if(frame.dataset.page!==selected){frame.dataset.page=selected;frame.src=`../${encodeURIComponent(selected)}?promo-preview=1`;}else sendPreview();}
    resizePreview();
  }
  async function releaseImage(path){
    const body=new FormData();body.set('csrf',root.dataset.csrf);body.set('remove',path);
    const response=await fetch(`promotions-upload.php?kind=${kind}`,{method:'POST',body});if(!response.ok)throw new Error('Bereinigung fehlgeschlagen.');
  }
  async function upload(files,replace=null){
    if(!files?.length||busy)return;model=collect();const list=[...files];if(!popup&&replace===null&&model.images.length+list.length>6){message('Maximal sechs Bilder pro Aktion.',true);return;}
    busy=true;state();message('Bild wird geprüft und hochgeladen …');
    try{for(const file of popup?list.slice(0,1):list){if(file.size>Number(root.dataset.maxUpload))throw new Error('Das Bild überschreitet die erlaubte Dateigröße.');const body=new FormData();body.set('csrf',root.dataset.csrf);body.set('image',file);const response=await fetch(`promotions-upload.php?kind=${kind}`,{method:'POST',body});let result;try{result=await response.json();}catch(_){throw new Error('Der Server hat den Upload abgelehnt. Bitte Dateigröße und Verbindung prüfen.');}if(!response.ok||!result.ok)throw new Error(result.error||'Upload fehlgeschlagen.');const previous=popup?model.image:replace!==null?model.images[replace]:null;if(popup)model.image=result.path;else if(replace!==null)model.images[replace]=result.path;else model.images.push(result.path);dirty=true;imageControls();renderPreview();if(previous)await releaseImage(previous);}message('Bild hochgeladen. Noch nicht veröffentlicht.');}
    catch(error){message(error.message,true);}finally{busy=false;state();form.querySelectorAll('input[type=file]').forEach(input=>input.value='');}
  }
  async function mutate(op,target=id){
    if(busy)return;const input=collect();busy=true;state();
    try{const response=await fetch(`promotions-api.php?kind=${kind}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({csrf:root.dataset.csrf,version,op,id:target,data:input})});let result;try{result=await response.json();}catch(_){throw new Error('Die Verbindung wurde unterbrochen. Ihre Eingaben bleiben erhalten.');}if(!response.ok||!result.ok)throw new Error(result.error||'Speichern fehlgeschlagen.');
      version=result.version;items=result.items;renderRecords();
      if(['save','publish','duplicate'].includes(op)){dirty=false;choose(result.id);}
      if(op==='delete'&&target===id){dirty=false;choose('');}
      if(op==='deactivate'&&target===id){field('active').checked=false;model.active=false;}
      const labels={save:'Entwurf dauerhaft gespeichert. Die öffentliche Version ist unverändert.',publish:input.active?'Veröffentlicht. Der Zeitraum und die Seitenauswahl werden automatisch berücksichtigt.':'Gespeichert und deaktiviert.',delete:'Eintrag und Veröffentlichung gelöscht.',duplicate:'Kopie als inaktiver Entwurf angelegt.',deactivate:'Die öffentliche Version wurde deaktiviert.'};message(labels[op]);
    }catch(error){message(error.message,true);}finally{busy=false;state();}
  }
  async function load(initial=false){
    try{const response=await fetch(`promotions-api.php?kind=${kind}`,{cache:'no-store'});const data=await response.json();if(!response.ok)throw new Error(data.error||'Laden fehlgeschlagen.');version=data.version;items=data.items;pages=data.pages;defaults=data.defaults;renderRecords();
      if(initial){const checks=root.querySelector('[data-promo-pages]');for(const [file,page] of Object.entries(pages)){const label=element('label');const input=element('input');input.type='checkbox';input.value=file;input.dataset.promoPage='';label.append(input,element('span','',page.label));checks.append(label);}choose('');root.dataset.ready='true';}
      else message('Liste neu geladen. Nicht gespeicherte Eingaben bleiben erhalten.');
    }catch(error){message(error.message||'Daten konnten nicht geladen werden.',true);}
  }
  form.addEventListener('input',event=>{if(event.target.type==='file'||event.target.hasAttribute('data-promo-page-search'))return;model=collect();dirty=true;if(event.target.name==='targetMode'||event.target.hasAttribute('data-promo-page'))targetControls();if(popup)root.querySelector('[data-promo-countdown-fields]').hidden=!model.countdown.enabled;renderPreview();state();});
  form.addEventListener('submit',event=>{event.preventDefault();mutate('publish');});
  root.querySelector('[data-promo-save]').addEventListener('click',()=>mutate('save'));
  root.querySelector('[data-promo-deactivate]').addEventListener('click',()=>mutate('deactivate'));
  root.querySelector('[data-promo-delete]').addEventListener('click',()=>{if(confirm('Diesen Eintrag und seine Veröffentlichung wirklich löschen?'))mutate('delete');});
  document.querySelector('[data-promo-new]').addEventListener('click',()=>choose(''));
  root.querySelector('[data-promo-reload]').addEventListener('click',()=>load());
  root.querySelector('[data-promo-popup-file]')?.addEventListener('change',event=>upload(event.target.files));
  root.querySelector('[data-promo-action-files]')?.addEventListener('change',event=>upload(event.target.files));
  root.querySelector('[data-promo-add-button]')?.addEventListener('click',()=>{model=collect();if(model.buttons.length>=3)return;model.buttons.push({text:'',url:''});buttonControls();dirty=true;renderPreview();state();});
  root.querySelector('[data-promo-select-all]').addEventListener('click',()=>{root.querySelectorAll('[data-promo-page]').forEach(input=>input.checked=true);model=collect();targetControls();dirty=true;renderPreview();state();});
  root.querySelector('[data-promo-page-search]').addEventListener('input',event=>{const query=event.target.value.toLowerCase();root.querySelectorAll('[data-promo-pages] label').forEach(label=>label.hidden=!label.textContent.toLowerCase().includes(query));});
  root.querySelector('[data-promo-preview-page]')?.addEventListener('change',renderPreview);
  root.querySelectorAll('[data-promo-device]').forEach(button=>button.addEventListener('click',()=>{device=button.dataset.promoDevice;root.querySelectorAll('[data-promo-device]').forEach(other=>{const active=other===button;other.classList.toggle('active',active);other.setAttribute('aria-pressed',String(active));});resizePreview();}));
  if(frame)frame.addEventListener('load',()=>{try{if(frame.contentWindow.BVPromotions)sendPreview();else frame.contentWindow.addEventListener('bv:promotions-ready',sendPreview,{once:true});}catch(_){message('Die Vorschau konnte nicht geöffnet werden.',true);}});
  const full=root.querySelector('[data-promo-full]'),content=root.querySelector('[data-promo-preview-content]'),home=content.parentElement;
  root.querySelector('[data-promo-preview]').addEventListener('click',()=>{renderPreview();root.querySelector('[data-promo-full-body]').append(content);full.showModal();resizePreview();});
  const closeFull=()=>{full.close();home.append(content);resizePreview();};root.querySelector('[data-promo-close-preview]').addEventListener('click',closeFull);full.addEventListener('cancel',event=>{event.preventDefault();closeFull();});
  new ResizeObserver(resizePreview).observe(viewport);
  window.addEventListener('beforeunload',event=>{if(dirty){event.preventDefault();event.returnValue='';}});
  load(true);
})();
