<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
require __DIR__ . '/editor-lib.php';
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');
if (!cms_logged_in() || !cms_section_allowed('pages')) { http_response_code(403); echo json_encode(['error'=>'Bitte erneut anmelden.']); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo '{}'; exit; }
if (empty($_SESSION['cms_csrf']) || empty($_POST['csrf'])) { http_response_code(403); echo json_encode(['error'=>'Sitzung abgelaufen. Bitte neu laden.']); exit; }
cms_check_csrf();
try {
    $file = $_FILES['image'] ?? null;
    if (!$file || $file['error'] !== UPLOAD_ERR_OK || $file['size'] < 1 || $file['size'] > cms_editor_upload_limit()) {
        throw new RuntimeException('Bitte ein gültiges Bild innerhalb der angezeigten Dateigröße auswählen.');
    }
    $types = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif','image/avif'=>'avif'];
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!isset($types[$mime]) || !@getimagesize($file['tmp_name'])) throw new RuntimeException('Bitte JPG, PNG, WEBP, GIF oder AVIF verwenden.');
    $relative = 'assets/uploads/' . date('YmdHis') . '-' . bin2hex(random_bytes(8)) . '.' . $types[$mime];
    $destination = __DIR__ . '/../' . $relative;
    if (!is_dir(dirname($destination)) && !mkdir(dirname($destination), 0755, true)) throw new RuntimeException('Der Upload-Ordner ist nicht beschreibbar.');
    if (!move_uploaded_file($file['tmp_name'], $destination)) throw new RuntimeException('Das Bild konnte nicht gespeichert werden.');
    chmod($destination, 0644);
    echo json_encode(['ok'=>true,'path'=>$relative]);
} catch (Throwable $e) {
    http_response_code(400); echo json_encode(['error'=>$e->getMessage()]);
}
