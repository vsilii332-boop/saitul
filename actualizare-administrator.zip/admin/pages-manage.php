<?php
cms_require_owner();
$registry = cms_page_registry($site); $visiblePages = cms_visible_pages($site);
function page_manage_fields(string $action, string $key = ''): void {
    echo '<input type="hidden" name="csrf" value="'.cms_e(cms_csrf()).'"><input type="hidden" name="version" value="'.(int)(cms_site()['_meta']['version'] ?? 0).'"><input type="hidden" name="action" value="'.cms_e($action).'"><input type="hidden" name="page" value="'.cms_e($key).'">';
}
function page_nav_settings(string $key, array $items, array $registry): array {
    foreach ($items as $item) {
        if (cms_page_from_href((string)($item['href'] ?? ''), $registry) === $key) return $item;
        $child = page_nav_settings($key, (array)($item['children'] ?? []), $registry); if ($child) return $child;
    }
    return [];
}
?>
<div class="page-heading"><div><span class="eyebrow">VERWALTUNG</span><h1>Seiten und Menü</h1><p>Nur der Hauptadministrator kann Seiten anlegen, veröffentlichen und das Menü ändern. Veröffentlichte Seiten im öffentlichen Menü sind automatisch für Mitarbeiter bearbeitbar.</p></div></div>
<section class="panel form-panel" id="neue-seite"><h2>Neue Seite</h2>
<form action="pages-save.php" method="post"><?php page_manage_fields('create'); ?>
<div class="grid2"><label>Seitentitel<input name="title" required maxlength="300"></label><label>URL-Name<input name="slug" placeholder="z. B. ferienkurs" pattern="[a-z0-9-]+" maxlength="100"><small>Leer lassen: wird aus dem Titel erzeugt.</small></label></div>
<label>Erster Text<textarea name="text" rows="4">Weitere Informationen folgen.</textarea></label>
<div class="grid2"><label>Menüname<input name="menu_label" maxlength="200"></label><label>Reihenfolge<input type="number" name="order" min="-1000" max="1000" value="0"></label></div>
<label class="toggle-row"><span>Veröffentlichen (sonst Entwurf)</span><input type="checkbox" name="active"></label><label class="toggle-row"><span>Im öffentlichen Menü anzeigen</span><input type="checkbox" name="menu_visible"></label>
<button class="btn primary">Neue Seite erstellen</button></form></section>
<section class="panel form-panel"><h2>Bestehende Seiten und Menü</h2><p>Eine kleinere Reihenfolge steht weiter oben. Verborgene Seiten dürfen nur Sie bearbeiten. HTML-Seiten bleiben über ihre öffentliche URL erreichbar.</p>
<?php foreach ($registry as $key=>$p): $custom=$p['custom']??null; $nav=$custom??page_nav_settings($key,(array)($site['navigation']??[]),$registry); ?>
<details class="item"><summary><?=cms_e($p['title'])?> · <?=isset($visiblePages[$key])?'Im Menü':($p['active']?'Nicht im Menü':'Entwurf')?></summary>
<p><a class="btn ghost" href="?section=pages&amp;page=<?=rawurlencode($key)?>">Inhalte bearbeiten</a></p>
<form action="pages-save.php" method="post"><?php page_manage_fields('update',$key); ?>
<div class="grid2"><label>Menüname<input name="menu_label" maxlength="200" value="<?=cms_e((string)($nav['menu_label']??$nav['label']??$p['title']))?>"></label><label>Reihenfolge<input type="number" name="order" min="-1000" max="1000" value="<?=(int)($nav['order']??0)?>"></label></div>
<label class="toggle-row"><span>Im öffentlichen Menü anzeigen</span><input type="checkbox" name="menu_visible" <?=isset($visiblePages[$key])?'checked':''?>></label>
<?php if ($custom): ?><label class="toggle-row"><span>Veröffentlicht</span><input type="checkbox" name="active" <?=$p['active']?'checked':''?>></label><?php endif; ?>
<button class="btn primary">Seite und Menü speichern</button></form>
<?php if ($custom): ?><form action="pages-save.php" method="post" onsubmit="return confirm('Diese Seite und ihre Inhalte endgültig löschen?')"><?php page_manage_fields('delete',$key); ?><button class="btn danger">Seite löschen</button></form><?php endif; ?>
</details><?php endforeach; ?></section>
