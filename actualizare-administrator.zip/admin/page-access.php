<?php
declare(strict_types=1);

function cms_page_registry(?array $site = null): array {
    $site ??= cms_site();
    $pages = [];
    foreach (cms_static_pages() as $key => $title) $pages[$key] = ['title'=>$title, 'url'=>$key, 'active'=>true];
    foreach ((array)($site['customPages'] ?? []) as $p) {
        if (!is_array($p) || empty($p['id']) || empty($p['slug'])) continue;
        $pages['custom:' . $p['id']] = ['title'=>(string)($p['title'] ?? $p['slug']), 'url'=>'custom-page.php?slug='.rawurlencode((string)$p['slug']), 'active'=>!empty($p['active']), 'custom'=>$p];
    }
    return $pages;
}

function cms_page_from_href(string $href, array $pages): ?string {
    $parts = parse_url(trim($href));
    if ($parts === false) return null;
    if (isset($parts['host']) && !in_array(strtolower((string)$parts['host']), ['fahrschule-bv.com','www.fahrschule-bv.com'], true)) return null;
    if (isset($parts['scheme']) && !in_array(strtolower((string)$parts['scheme']), ['http','https'], true)) return null;
    if (str_starts_with(trim($href), '#') || trim($href) === '') return null;
    $path = rawurldecode((string)($parts['path'] ?? ''));
    if (str_contains($path, '..') || str_contains($path, '\\')) return null;
    $path = ltrim($path, '/');
    if ($path === '') $path = 'index.html';
    if (isset($pages[$path])) return $path;
    parse_str((string)($parts['query'] ?? ''), $query);
    foreach ($pages as $key => $page) if (isset($page['custom'])) {
        $slug = (string)$page['custom']['slug'];
        if (($path === 'custom-page.php' && ($query['slug'] ?? '') === $slug) || $path === 'seite/'.$slug) return $key;
    }
    return null;
}

function cms_visible_pages(?array $site = null): array {
    $site ??= cms_site(); $pages = cms_page_registry($site); $visible = [];
    $walk = function (array $items) use (&$walk, &$visible, $pages): void {
        foreach ($items as $item) {
            if (!is_array($item) || ($item['enabled'] ?? true) === false) continue;
            $key = cms_page_from_href((string)($item['href'] ?? ''), $pages);
            if ($key !== null && $pages[$key]['active']) $visible[$key] = (string)($item['label'] ?? $pages[$key]['title']);
            $walk((array)($item['children'] ?? []));
        }
    };
    $navigation = (array)($site['navigation'] ?? []);
    $custom = (array)($site['customPages'] ?? []);
    usort($custom, fn($a,$b) => (int)($a['order'] ?? 0) <=> (int)($b['order'] ?? 0));
    foreach ($custom as $p) if (!empty($p['active']) && ($p['menu_visible'] ?? true) !== false && !empty($p['menu_label'])) {
        $entry = ['href'=>'custom-page.php?slug='.rawurlencode((string)$p['slug']), 'label'=>$p['menu_label'], 'order'=>(int)($p['order'] ?? 0)];
        $at = count($navigation);
        foreach ($navigation as $i=>$item) if (!empty($item['button'])) { $at=$i; break; }
        array_splice($navigation, $at, 0, [$entry]);
    }
    usort($navigation, fn($a,$b) => (int)($a['order'] ?? 0) <=> (int)($b['order'] ?? 0));
    $walk($navigation);
    return $visible;
}

function cms_can_edit_page(string $key, ?array $site = null): bool {
    $site ??= cms_site();
    return isset(cms_page_registry($site)[$key]) && (cms_is_owner() || isset(cms_visible_pages($site)[$key]));
}

function cms_page_url(string $key, bool $preview = false): string {
    $page = cms_page_registry()[$key] ?? null;
    if (!$page) return '';
    $url = $page['url'];
    if ($preview && isset($page['custom']) && cms_is_owner()) $url .= '&preview=1';
    return $url;
}

function cms_find_message(string $id): ?array {
    foreach (cms_all_messages() as $r) if ($id === (string)($r['message_id'] ?? '') || $id === (string)$r['_file']) return $r;
    return null;
}

function cms_require_message(string $id): array {
    $r = cms_find_message($id);
    if (!$r || (!cms_is_owner() && cms_message_is_spam($r, cms_status()))) {
        http_response_code(403); exit('Keine Berechtigung für diese Nachricht.');
    }
    return $r;
}
