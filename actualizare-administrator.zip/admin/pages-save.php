<?php
declare(strict_types=1);
require __DIR__.'/lib.php';
cms_require_owner();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
cms_check_csrf();
$site = cms_site();
if ((string)($_POST['version'] ?? '') !== (string)($site['_meta']['version'] ?? 0)) {
    http_response_code(409); exit('Die Website wurde inzwischen geändert. Bitte neu laden.');
}
try {
    $action = (string)($_POST['action'] ?? '');
    $key = (string)($_POST['page'] ?? '');
    $registry = cms_page_registry($site);
    if ($action !== 'create' && !isset($registry[$key])) throw new InvalidArgumentException('Seite nicht gefunden.');
    $label = trim((string)($_POST['menu_label'] ?? ''));
    $order = max(-1000, min(1000, (int)($_POST['order'] ?? 0)));
    $visible = isset($_POST['menu_visible']);
    if (strlen($label) > 200) throw new InvalidArgumentException('Menüname ist zu lang.');
    if ($visible && $label === '') throw new InvalidArgumentException('Bitte einen Menünamen eingeben.');
    if ($action === 'create') {
        $title = trim((string)($_POST['title'] ?? ''));
        $slug = cms_slug((string)($_POST['slug'] ?? '') ?: $title);
        if ($title === '' || strlen($title) > 300 || $slug === '' || strlen($slug) > 100) throw new InvalidArgumentException('Bitte einen gültigen Titel und eine kurze URL eingeben.');
        foreach ($site['customPages'] ?? [] as $p) if (($p['slug'] ?? '') === $slug) throw new InvalidArgumentException('Diese URL ist bereits vergeben.');
        $id = bin2hex(random_bytes(8)); $key = 'custom:'.$id;
        $site['customPages'][] = ['id'=>$id,'slug'=>$slug,'title'=>$title,'active'=>isset($_POST['active']), 'menu_visible'=>$visible,'menu_label'=>$label,'order'=>$order,'seo_title'=>$title,'seo_desc'=>'',
            'blocks'=>[['id'=>bin2hex(random_bytes(6)),'type'=>'text_image','title'=>'Informationen','text'=>trim((string)($_POST['text'] ?? 'Weitere Informationen folgen.')),'image'=>'assets/images/hero-driving-student.webp','buttonText'=>'','buttonLink'=>'']]];
    } elseif ($action === 'update') {
        if (isset($registry[$key]['custom'])) {
            foreach ($site['customPages'] as &$p) if ('custom:'.$p['id'] === $key) {
                $p['active'] = isset($_POST['active']); $p['menu_visible'] = $visible; $p['menu_label'] = $label; $p['order'] = $order;

            }
            unset($p);
        }
    } elseif ($action === 'delete') {
        if (!isset($registry[$key]['custom'])) throw new InvalidArgumentException('Bestehende HTML-Seiten können Sie aus dem Menü ausblenden.');
        $site['customPages'] = array_values(array_filter($site['customPages'], fn($p) => 'custom:'.$p['id'] !== $key));
        foreach (['visualEditor','seo','content','blocks','pageEditor'] as $bucket) unset($site[$bucket][$key]);
    } else throw new InvalidArgumentException('Ungültige Aktion.');

    // A single authoritative navigation tree controls both the public menu and editor rights.
    $found = false;
    $walk = function (array $items) use (&$walk, &$found, $key, $registry, $action, $visible, $label, $order): array {
        $out = [];
        foreach ($items as $item) {
            if (cms_page_from_href((string)($item['href'] ?? ''), $registry) === $key) {
                $found = true;
                if ($action === 'delete' || isset($registry[$key]['custom'])) continue;
                $item['enabled'] = $visible; $item['label'] = $label; $item['order'] = $order;
            }
            if (isset($item['children'])) $item['children'] = $walk((array)$item['children']);
            $out[] = $item;
        }
        usort($out, fn($a,$b) => (int)($a['order'] ?? 0) <=> (int)($b['order'] ?? 0));
        return $out;
    };
    $site['navigation'] = $walk((array)($site['navigation'] ?? []));
    if ($action === 'update' && !$found && !isset($registry[$key]['custom'])) {
        $site['navigation'][] = ['href'=>$key,'label'=>$label,'enabled'=>$visible,'order'=>$order];
        usort($site['navigation'], fn($a,$b) => (int)($a['order'] ?? 0) <=> (int)($b['order'] ?? 0));
    }
    cms_save_site($site); cms_log_activity('Seiten und Menü verwaltet', $key.' · '.$action);
    if ($action === 'create') { header('Location: index.php?section=pages&page='.rawurlencode($key)); exit; }
    cms_redirect('manage-pages', $action === 'delete' ? 'Seite gelöscht' : 'Seite und Menü gespeichert');
} catch (Throwable $e) {
    http_response_code(400);
    echo cms_e($e instanceof InvalidArgumentException ? $e->getMessage() : 'Speichern fehlgeschlagen. Bitte Schreibrechte prüfen.');
}
