<?php
declare(strict_types=1);
require_once __DIR__ . '/lib.php';
cms_require_login();
if (!cms_section_allowed('analytics')) { http_response_code(403); exit; }
require_once __DIR__ . '/analytics-lib.php';

$month = (string)($_GET['month'] ?? bv_stats_month());
if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/D', $month)) $month = bv_stats_month();
$months = [bv_stats_month()];
foreach (glob(BV_STATS_DIR . '/*.json') ?: [] as $file) {
    $m = basename($file, '.json');
    if (preg_match('/^\d{4}-(0[1-9]|1[0-2])$/D', $m)) $months[] = $m;
}
$months = array_values(array_unique($months)); rsort($months);
$data = bv_stats_read($month);
$pageViews = $data['pages'] ?? []; arsort($pageViews);
$sources = $data['sources'] ?? []; arsort($sources);
$visitors = array_values($data['visitor_details'] ?? []);
usort($visitors, fn($a,$b) => strcmp((string)($b['last_seen']??''), (string)($a['last_seen']??'')));
$now = time();
$online = 0;
foreach ($visitors as $v) { if (($t = strtotime((string)($v['last_seen'] ?? ''))) && $now - $t <= 300) $online++; }
$writable = is_dir(BV_STATS_DIR) ? is_writable(BV_STATS_DIR) : is_writable(dirname(BV_STATS_DIR));
$lastUpdate = $data['updated_at'] ?? '';
function bv_ap_fmt(?string $iso): string { if (!$iso) return '—'; $t=strtotime($iso); return $t ? date('d.m.Y H:i', $t) : '—'; }
?>
<style>
.bv-a-wrap{display:grid;gap:16px}.bv-a-cards{display:grid;grid-template-columns:repeat(4,minmax(150px,1fr));gap:12px}.bv-a-card,.bv-a-panel{background:#11161b;border:1px solid #28313a;border-radius:16px;padding:16px}.bv-a-card b{display:block;font-size:28px;margin-top:5px}.bv-a-card small,.bv-muted{color:#8f9ba6}.bv-a-status{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.bv-dot{width:9px;height:9px;border-radius:99px;background:#2ed887;display:inline-block}.bv-dot.bad{background:#ff5964}.bv-a-grid{display:grid;grid-template-columns:minmax(0,1.4fr) minmax(300px,.8fr);gap:16px}.bv-table{width:100%;border-collapse:collapse}.bv-table th,.bv-table td{padding:11px 10px;border-bottom:1px solid #263039;text-align:left;vertical-align:top}.bv-table th{color:#93a1ae;font-size:12px;text-transform:uppercase}.bv-pill{display:inline-block;padding:4px 8px;border-radius:99px;background:#202a33;margin:2px 3px 2px 0;font-size:12px}.bv-online{color:#48e69b}.bv-source{color:#ff8a2b;font-weight:700}.bv-pages{max-width:420px}.bv-pages details summary{cursor:pointer}.bv-recent{margin:8px 0 0;padding-left:18px;color:#b9c2ca}.bv-actions{display:flex;gap:10px;align-items:end;flex-wrap:wrap}.bv-actions label{display:grid;gap:5px}.bv-actions select{min-width:150px}.bv-empty{padding:20px;color:#97a3ad}.bv-warning{border-color:#684624;background:#241a10}.bv-ok{color:#55db99}@media(max-width:1000px){.bv-a-cards{grid-template-columns:repeat(2,1fr)}.bv-a-grid{grid-template-columns:1fr}}@media(max-width:620px){.bv-a-cards{grid-template-columns:1fr}.bv-table{font-size:13px}.bv-table th:nth-child(5),.bv-table td:nth-child(5){display:none}}
</style>
<div class="page-heading"><div><span class="eyebrow">STATISTIK</span><h1>Besucher und Seiten</h1><p>Anonyme Besucher, Zugriffsquellen, Geräte und besuchte Seiten. Ohne Cookies und ohne Speicherung der vollständigen IP-Adresse.</p></div></div>
<div class="bv-a-wrap">
<section class="bv-a-panel <?= $writable ? '' : 'bv-warning' ?>">
  <div class="bv-a-status"><span class="bv-dot <?= $writable ? '' : 'bad' ?>"></span><strong>Erfassung: <?= $writable ? 'bereit' : 'Statistikordner ist nicht beschreibbar' ?></strong><span class="bv-muted">Letzte Erfassung: <?= cms_e(bv_ap_fmt($lastUpdate)) ?></span><a class="btn ghost" href="?section=analytics&month=<?=cms_e($month)?>">Aktualisieren</a></div>
</section>
<section class="bv-a-panel"><form class="bv-actions" method="get"><input type="hidden" name="section" value="analytics"><label>Monat<select name="month"><?php foreach($months as $m): ?><option value="<?=cms_e($m)?>" <?=$month===$m?'selected':''?>><?=cms_e($m)?></option><?php endforeach; ?></select></label><button class="btn primary">Anzeigen</button><a class="btn ghost" href="analytics-export.php?month=<?=cms_e($month)?>">CSV herunterladen</a></form></section>
<div class="bv-a-cards">
 <div class="bv-a-card"><span>Anonyme Besucher</span><b><?=count($data['visitors']??[])?></b><small>geschätzte Erkennung pro Monat</small></div>
 <div class="bv-a-card"><span>Sitzungen</span><b><?=(int)($data['sessions']??0)?></b><small>Pause &gt; 30 Min. = neue Sitzung</small></div>
 <div class="bv-a-card"><span>Seitenaufrufe</span><b><?=(int)($data['views']??0)?></b><small>alle erfassten Seiten</small></div>
 <div class="bv-a-card"><span>Jetzt auf der Website</span><b class="bv-online"><?=$online?></b><small>Aktivität in den letzten 5 Minuten</small></div>
</div>
<div class="bv-a-grid">
<section class="bv-a-panel"><h2>Besucher</h2>
<?php if(!$visitors): ?><div class="bv-empty">Noch keine Besuche erfasst. Öffnen Sie die öffentliche Website in einem privaten Browserfenster und aktualisieren Sie anschließend diese Übersicht.</div>
<?php else: ?><div style="overflow:auto"><table class="bv-table"><thead><tr><th>ID</th><th>Letzter Besuch</th><th>Quelle</th><th>Gerät</th><th>Land / Sprache</th><th>Seiten</th></tr></thead><tbody>
<?php foreach($visitors as $v): $last=strtotime((string)($v['last_seen']??'')); $isOnline=$last && $now-$last<=300; ?>
<tr><td><strong>#<?=cms_e((string)($v['id']??'—'))?></strong><br><small><?= $isOnline ? '<span class="bv-online">● online</span>' : cms_e((string)($v['views']??0)).' Aufrufe' ?></small></td>
<td><?=cms_e(bv_ap_fmt((string)($v['last_seen']??'')))?><br><small>zuerst: <?=cms_e(bv_ap_fmt((string)($v['first_seen']??'')))?></small></td>
<td><span class="bv-source"><?=cms_e((string)($v['source']??'Direct'))?></span><?php if(!empty($v['utm_campaign'])):?><br><small><?=cms_e((string)$v['utm_campaign'])?></small><?php endif;?></td>
<td><?=cms_e((string)($v['device']??'—'))?><br><small><?=cms_e((string)($v['browser']??'—'))?></small></td>
<td><?=cms_e((string)($v['country']??'—'))?><br><small><?=cms_e((string)($v['language']??'—'))?> · <?=cms_e((string)($v['timezone']??'—'))?></small></td>
<td class="bv-pages"><details><summary><?=count($v['pages']??[])?> Seiten · <?= (int)($v['views']??0) ?> Aufrufe</summary><div><?php foreach(($v['pages']??[]) as $p=>$n): ?><span class="bv-pill"><?=cms_e($p)?> × <?=(int)$n?></span><?php endforeach; ?></div><?php if(!empty($v['recent'])):?><ul class="bv-recent"><?php foreach(array_reverse(array_slice($v['recent'],-10)) as $r):?><li><?=cms_e((string)$r['time'])?> — <?=cms_e((string)$r['path'])?></li><?php endforeach;?></ul><?php endif;?></details></td></tr>
<?php endforeach; ?></tbody></table></div><?php endif; ?></section>
<section class="bv-a-panel"><h2>Zugriffsquellen</h2><?php if(!$sources):?><p class="bv-muted">Noch keine Daten vorhanden.</p><?php else: foreach($sources as $s=>$n):?><p><strong><?=cms_e($s)?></strong> <span class="bv-muted">— <?=(int)$n?> Sitzungen</span></p><?php endforeach; endif;?><hr style="border-color:#273039"><h2>Beliebte Seiten</h2><?php if(!$pageViews):?><p class="bv-muted">Noch keine Daten vorhanden.</p><?php else: foreach(array_slice($pageViews,0,15,true) as $p=>$n):?><p><strong><?=cms_e($p)?></strong><br><span class="bv-muted"><?=(int)$n?> Aufrufe</span></p><?php endforeach; endif;?></section>
</div>
<section class="bv-a-panel"><p class="bv-muted">ID-ul vizitatorului este o identificare anonimă lunară calculată din IP + browser prin HMAC. IP-ul și user-agent-ul brut nu sunt salvate în fișierele de statistici. Țara apare numai dacă hostingul transmite deja un cod de țară; altfel rămâne „—”. „Zugriffsquellen” înseamnă sursa/referrerul (Direct, Google, Facebook etc.), nu adresa fizică exactă.</p></section>
</div>
