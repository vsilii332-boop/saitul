<?php
declare(strict_types=1);
require __DIR__.'/lib.php';
require __DIR__.'/promotions-lib.php';
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
$kind = (string)($_GET['kind'] ?? '');
if (!in_array($kind,['popups','actions'],true)) { http_response_code(400);echo '{"error":"Ungültiger Bereich."}';exit; }
if (!cms_logged_in() || !cms_section_allowed($kind)) { http_response_code(403);echo '{"error":"Keine Berechtigung. Bitte anmelden."}';exit; }
$lock = null;
try {
    if ($_SERVER['REQUEST_METHOD']==='GET') {
        $store=bv_promo_read();
        echo json_encode(['version'=>$store['version'],'items'=>array_values($store[$kind]),'pages'=>bv_promo_pages(),'defaults'=>bv_promo_defaults($kind)],JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;
    }
    if ($_SERVER['REQUEST_METHOD']!=='POST') {http_response_code(405);echo '{}';exit;}
    $raw=(string)file_get_contents('php://input');
    if(strlen($raw)>1024*1024)throw new InvalidArgumentException('Die Anfrage ist zu groß.');
    $input=json_decode($raw,true,512,JSON_THROW_ON_ERROR);
    if(!is_array($input))throw new InvalidArgumentException('Ungültige Anfrage.');
    if(empty($_SESSION['cms_csrf']) || !is_string($input['csrf'] ?? null) || !hash_equals($_SESSION['cms_csrf'],$input['csrf'])) {http_response_code(403);echo '{"error":"Sicherheitsprüfung fehlgeschlagen. Bitte neu laden."}';exit;}
    if(!is_dir(dirname(BV_PROMO_FILE)) && !mkdir(dirname(BV_PROMO_FILE),0700,true))throw new RuntimeException('Der Speicher ist nicht beschreibbar.');
    $lock=fopen(dirname(BV_PROMO_FILE).'/promotions.lock','c');
    if(!$lock || !flock($lock,LOCK_EX))throw new RuntimeException('Der Speicher ist vorübergehend gesperrt.');
    $before=$store=bv_promo_read();
    if(!is_int($input['version'] ?? null) || $input['version']!==$store['version']) {http_response_code(409);echo '{"error":"Die Daten wurden inzwischen geändert. Ihre Eingaben bleiben erhalten. Bitte Liste neu laden und erneut speichern."}';exit;}
    if(!is_string($input['op'] ?? null) || !is_string($input['id'] ?? ''))throw new InvalidArgumentException('Ungültige Aktion.');
    $op=$input['op'];$id=$input['id'] ?? '';
    if($id!=='' && !isset($store[$kind][$id]))throw new InvalidArgumentException('Dieser Eintrag existiert nicht mehr.');
    $time=gmdate('c');
    if(in_array($op,['save','publish'],true)) {
        if(!is_array($input['data'] ?? null))throw new InvalidArgumentException('Ungültiger Inhalt.');
        $draft=bv_promo_validate($kind,$input['data'],$op==='publish');
        if($id==='')$id=($kind==='popups'?'pp_':'ak_').bin2hex(random_bytes(8));
        $record=$store[$kind][$id] ?? ['id'=>$id,'createdAt'=>$time,'published'=>null];
        $record['draft']=$draft;$record['updatedAt']=$time;
        if($op==='publish'){$record['published']=$draft;$record['publishedAt']=$time;}
        $store[$kind][$id]=$record;
    } elseif($op==='duplicate' && $id!=='') {
        $record=$store[$kind][$id];$id=($kind==='popups'?'pp_':'ak_').bin2hex(random_bytes(8));
        $record['id']=$id;$record['draft']['active']=false;$record['published']=null;$record['createdAt']=$record['updatedAt']=$time;unset($record['publishedAt']);
        if($kind==='actions')$record['draft']['title']=substr($record['draft']['title'],0,160).' (Kopie)';
        $store[$kind][$id]=$record;
    } elseif($op==='deactivate' && $id!=='') {
        $store[$kind][$id]['draft']['active']=false;
        if(is_array($store[$kind][$id]['published']))$store[$kind][$id]['published']['active']=false;
        $store[$kind][$id]['updatedAt']=$time;
    } elseif($op==='delete' && $id!=='') {
        unset($store[$kind][$id]);$id='';
    } else throw new InvalidArgumentException('Ungültige Aktion.');
    $store['version']++;
    bv_promo_write($store);
    bv_promo_cleanup($before,$store);
    cms_log_activity($kind==='popups'?'Pop-up geändert':'Aktion geändert',$op.' '.$id);
    echo json_encode(['ok'=>true,'version'=>$store['version'],'id'=>$id,'items'=>array_values($store[$kind])],JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
} catch(Throwable $e) {
    http_response_code($e instanceof InvalidArgumentException || $e instanceof JsonException ? 400:500);
    echo json_encode(['error'=>$e instanceof InvalidArgumentException ? $e->getMessage():'Die Daten konnten nicht gespeichert werden. Bitte Schreibrechte und Verbindung prüfen.'],JSON_UNESCAPED_UNICODE);
} finally {if(is_resource($lock)){flock($lock,LOCK_UN);fclose($lock);}}
