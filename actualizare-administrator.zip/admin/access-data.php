<?php
declare(strict_types=1);

// This file is also used by public endpoints; it must not start an admin session.
function cms_public_site(array $site): array {
    unset($site['settings'], $site['_meta']['updated_by']);
    $drafts = [];
    $site['customPages'] = array_values(array_filter((array)($site['customPages'] ?? []), function ($page) use (&$drafts) {
        if (!is_array($page)) return false;
        if (empty($page['active'])) { $drafts[] = 'custom:' . ($page['id'] ?? ''); return false; }
        return true;
    }));
    foreach (['visualEditor','seo','content','blocks','pageEditor'] as $bucket) {
        foreach ($drafts as $key) unset($site[$bucket][$key]);
    }
    return $site;
}

function cms_message_is_spam(array $message, array $state): bool {
    $id = (string)($message['message_id'] ?? $message['_file'] ?? '');
    $choice = $state['messages'][$id]['visibility'] ?? '';
    if ($choice === 'normal') return false;
    if ($choice === 'spam') return true;
    $text = (string)($message['subject'] ?? '') . ' ' . (string)($message['message'] ?? '');
    // Strong solicitation signals only. Ordinary requests for prices/offers stay in Kunden.
    return (bool)preg_match('~(?:seo[- ](?:services?|dienstleistungen?|agentur)|(?:offer|offering|provide|providing|biete|bieten|anbieten).{0,70}(?:backlinks?|link[ -]building|web[ -]?design|search engine optimi[sz]ation)|guest[ -]posts?|paid[ -]links?|increase your (?:google|website) ranking|improve your (?:google|website) ranking|wir (?:verkaufen|bieten).{0,50}(?:backlinks|suchmaschinenoptimierung))~isu', $text);
}
