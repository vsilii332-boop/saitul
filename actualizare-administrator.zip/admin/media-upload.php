<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
cms_require_owner();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
cms_check_csrf();
if (empty($_FILES['media']) || $_FILES['media']['error'] !== UPLOAD_ERR_OK) cms_redirect('media', 'Upload fehlgeschlagen');
$f = $_FILES['media'];
if ((int)$f['size'] > 8 * 1024 * 1024) cms_redirect('media', 'Datei ist zu groß');
$mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
$ok = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
if (!isset($ok[$mime])) cms_redirect('media', 'Nur JPG, PNG oder WEBP erlaubt');
$name = date('YmdHis') . '-' . bin2hex(random_bytes(4)) . '.' . $ok[$mime];
$dest = __DIR__ . '/../assets/uploads/' . $name;
if (!is_dir(dirname($dest))) @mkdir(dirname($dest), 0755, true);
if (!move_uploaded_file($f['tmp_name'], $dest)) cms_redirect('media', 'Upload fehlgeschlagen');
@chmod($dest, 0644);
cms_log_activity('Bild hochgeladen', $name);
cms_redirect('media', 'Bild hochgeladen');
