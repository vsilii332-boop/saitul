<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';

if (!cms_is_setup()) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        cms_check_csrf();
        $u = CMS_SUPERUSER;
        $p = (string)($_POST['password'] ?? '');
        $pc = (string)($_POST['password_confirm'] ?? '');
        if (strlen($p) < 10) $err = 'Das Passwort muss mindestens 10 Zeichen lang sein.';
        elseif ($p !== $pc) $err = 'Die Passwörter stimmen nicht überein.';
        else {
            $users = cms_users();
            foreach ($users as &$existing) $existing['role'] = 'staff';
            unset($existing);
            $users[] = [
                'username' => $u,
                'password_hash' => password_hash($p, PASSWORD_DEFAULT),
                'role' => 'owner',
                'active' => true,
            ];
            cms_json_write(CMS_USERS_FILE, $users);
            cms_login($u, $p);
            header('Location: index.php');
            exit;
        }
    }
    ?><!doctype html>
    <html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BV Admin einrichten</title><link rel="stylesheet" href="assets/admin.css?v=20261104-1"><style>
.password-field{position:relative;display:block;width:100%}.password-field input{width:100%;padding-right:48px}.password-eye{position:absolute;right:8px;top:50%;transform:translateY(-50%);width:34px;height:34px;border:1px solid #2b333d;border-radius:9px;background:#11171d;color:#c9d1d9;display:grid;place-items:center;cursor:pointer;font-size:16px;line-height:1}.password-eye:hover{border-color:#ff7a1a;color:#fff}.password-eye:focus-visible{outline:2px solid #ff7a1a;outline-offset:2px}
</style></head>
    <body class="auth">
      <form method="post" class="auth-card">
        <div class="brand"><span class="brand-mark">BV</span><span><b>Fahrschule BV</b><small>Admin Center</small></span></div>
        <div class="auth-copy"><span class="eyebrow">ERSTEINRICHTUNG</span><h1>Hauptadministrator einrichten</h1><p>Dieses Konto erhält vollständigen Zugriff auf alle Funktionen der Website.</p></div>
        <?php if (!empty($err)): ?><div class="alert error"><?=cms_e($err)?></div><?php endif; ?>
        <input type="hidden" name="csrf" value="<?=cms_e(cms_csrf())?>">
        <label>Administrator-E-Mail<input value="<?=cms_e(CMS_SUPERUSER)?>" readonly></label>
        <label>Passwort<div class="password-field"><input id="setup-password" type="password" name="password" minlength="10" required autocomplete="new-password"><button type="button" class="password-eye" data-password-toggle="setup-password" aria-label="Passwort anzeigen" title="Passwort anzeigen">👁</button></div></label>
        <label>Passwort wiederholen<div class="password-field"><input id="setup-password-confirm" type="password" name="password_confirm" minlength="10" required autocomplete="new-password"><button type="button" class="password-eye" data-password-toggle="setup-password-confirm" aria-label="Passwort anzeigen" title="Passwort anzeigen">👁</button></div></label>
        <button class="btn primary full">Admin Center aktivieren</button>
      </form>
      <script>
document.querySelectorAll('[data-password-toggle]').forEach(function(btn){
  btn.addEventListener('click', function(){
    var input=document.getElementById(btn.getAttribute('data-password-toggle'));
    if(!input) return;
    var show=input.type==='password';
    input.type=show?'text':'password';
    btn.textContent=show?'🙈':'👁';
    btn.setAttribute('aria-label', show?'Passwort ausblenden':'Passwort anzeigen');
    btn.setAttribute('title', show?'Passwort ausblenden':'Passwort anzeigen');
    input.focus({preventScroll:true});
  });
});
</script>
    </body></html><?php
    exit;
}

if (!cms_logged_in()) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        cms_check_csrf();
        $lock = (int)($_SESSION['cms_lock_until'] ?? 0);
        if ($lock > time()) {
            $err = 'Zu viele Versuche. Bitte später erneut versuchen.';
        } elseif (cms_login((string)($_POST['username'] ?? ''), (string)($_POST['password'] ?? ''))) {
            header('Location: index.php'); exit;
        } else {
            $_SESSION['cms_login_failures'] = (int)($_SESSION['cms_login_failures'] ?? 0) + 1;
            if ($_SESSION['cms_login_failures'] >= 5) {
                $_SESSION['cms_lock_until'] = time() + 900;
                $_SESSION['cms_login_failures'] = 0;
                $err = 'Zu viele Versuche. Anmeldung für 15 Minuten gesperrt.';
            } else $err = 'E-Mail oder Passwort ist falsch.';
        }
    }
    ?><!doctype html>
    <html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BV Admin Anmeldung</title><link rel="stylesheet" href="assets/admin.css?v=20261104-1"><style>
.password-field{position:relative;display:block;width:100%}.password-field input{width:100%;padding-right:48px}.password-eye{position:absolute;right:8px;top:50%;transform:translateY(-50%);width:34px;height:34px;border:1px solid #2b333d;border-radius:9px;background:#11171d;color:#c9d1d9;display:grid;place-items:center;cursor:pointer;font-size:16px;line-height:1}.password-eye:hover{border-color:#ff7a1a;color:#fff}.password-eye:focus-visible{outline:2px solid #ff7a1a;outline-offset:2px}
</style></head>
    <body class="auth">
      <form method="post" class="auth-card">
        <div class="brand"><span class="brand-mark">BV</span><span><b>Fahrschule BV</b><small>Admin Center</small></span></div>
        <div class="auth-copy"><span class="eyebrow">GESCHÜTZTER BEREICH</span><h1>Willkommen zurück</h1><p>Melden Sie sich an, um Website, Anmeldungen und Nachrichten zu verwalten.</p></div>
        <?php if (!empty($err)): ?><div class="alert error"><?=cms_e($err)?></div><?php endif; ?>
        <input type="hidden" name="csrf" value="<?=cms_e(cms_csrf())?>">
        <label>E-Mail-Adresse<input type="email" name="username" required autofocus autocomplete="username"></label>
        <label>Passwort<div class="password-field"><input id="login-password" type="password" name="password" required autocomplete="current-password"><button type="button" class="password-eye" data-password-toggle="login-password" aria-label="Passwort anzeigen" title="Passwort anzeigen">👁</button></div></label>
        <button class="btn primary full">Anmelden</button>
      </form>
      <script>
document.querySelectorAll('[data-password-toggle]').forEach(function(btn){
  btn.addEventListener('click', function(){
    var input=document.getElementById(btn.getAttribute('data-password-toggle'));
    if(!input) return;
    var show=input.type==='password';
    input.type=show?'text':'password';
    btn.textContent=show?'🙈':'👁';
    btn.setAttribute('aria-label', show?'Passwort ausblenden':'Passwort anzeigen');
    btn.setAttribute('title', show?'Passwort ausblenden':'Passwort anzeigen');
    input.focus({preventScroll:true});
  });
});
</script>
    </body></html><?php
    exit;
}

$section = (string)($_GET['section'] ?? 'dashboard');
// Old bookmarks now open the corresponding page instead of a separate editing module.
$legacyPages = ['homepage'=>'index.html','team'=>'fahrschule.html','gallery'=>'galerie.html','prices'=>'preisliste.html','summer'=>'index.html','banner'=>'index.html','media'=>'galerie.html','website'=>'kontakt.html','navigation'=>'index.html','seo'=>'index.html','design'=>'index.html'];
if (isset($legacyPages[$section]) && cms_section_allowed('pages')) {
    $target = $section === 'seo' ? basename((string)($_GET['page'] ?? 'index.html')) : $legacyPages[$section];
    header('Location: index.php?section=pages&page=' . rawurlencode($target)); exit;
}

if (!cms_section_allowed($section)) {
    $_SESSION['cms_error'] = 'Für diesen Bereich haben Sie keine Berechtigung.';
    header('Location: index.php?section=dashboard'); exit;
}

$site = cms_site();
$user = cms_user();
$isOwner = cms_is_owner();
$status = cms_status();
$regs = cms_section_allowed('registrations') ? cms_registrations() : [];
$msgs = cms_section_allowed('messages') ? cms_messages() : [];
$pages = cms_static_pages();
$error = $_SESSION['cms_error'] ?? '';
unset($_SESSION['cms_error']);
$activities = $isOwner ? cms_activity(8) : [];

$newRegs = 0;
foreach ($regs as $r) {
    $id = (string)($r['request_id'] ?? $r['_dir'] ?? '');
    if (($status['registrations'][$id]['status'] ?? 'Neu') === 'Neu') $newRegs++;
}
$newMsgs = 0;
foreach ($msgs as $r) {
    $id = (string)($r['message_id'] ?? $r['_file'] ?? '');
    if (($status['messages'][$id]['status'] ?? 'Neu') === 'Neu') $newMsgs++;
}
$activeBanners = count(array_filter($site['banners'] ?? [], fn($b) => !empty($b['active'])));
$websiteReady = is_file(__DIR__ . '/../index.html');
$formsReady = is_file(__DIR__ . '/../process-anmeldung.php') && is_file(__DIR__ . '/../process-contact.php');
$sslActive = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
$publicReady = is_file(CMS_PUBLIC_SITE_FILE);
$publicInSync = $publicReady && is_file(CMS_SITE_FILE) && hash_file('sha256', CMS_PUBLIC_SITE_FILE) === hash_file('sha256', CMS_SITE_FILE);
$lastPublished = (string)($site['_meta']['updated_at'] ?? '');
$siteVersion = (int)($site['_meta']['version'] ?? 0);

function form_start(string $action, string $return = ''): void {
    echo '<form method="post" action="save.php"><input type="hidden" name="csrf" value="' . cms_e(cms_csrf()) . '"><input type="hidden" name="action" value="' . cms_e($action) . '">';
    if ($return) echo '<input type="hidden" name="return_section" value="' . cms_e($return) . '">';
}
function block_fields(): void {
    echo '<div class="grid2"><label>Elementtyp<select name="type"><option value="text">Text</option><option value="text_image">Text + Bild</option><option value="image">Bild</option><option value="cta">Call-to-Action</option></select></label><label>Bild / URL<input name="image" placeholder="assets/uploads/... oder https://..."></label></div><label>Titel<input name="title"></label><label>Text<textarea name="text" rows="4"></textarea></label><div class="grid2"><label>Button-Text<input name="buttonText"></label><label>Button-Link<input name="buttonLink"></label></div>';
}
function icon(string $name): string {
    $icons = [
        'dashboard'=>'<path d="M4 13h6V4H4v9Zm0 7h6v-5H4v5Zm10 0h6v-9h-6v9Zm0-16v5h6V4h-6Z"/>',
        'users'=>'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
        'mail'=>'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
        'pages'=>'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M8 13h8M8 17h8"/>',
        'euro'=>'<path d="M18 7.5a6 6 0 1 0 0 9M5 10h9M5 14h8"/>',
        'calendar'=>'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18"/>',
        'banner'=>'<path d="M3 11h18M5 11V6h14v5M7 11v7h10v-7"/><path d="M9 15h6"/>',
        'image'=>'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
        'contact'=>'<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.12.9.33 1.78.62 2.63a2 2 0 0 1-.45 2.11L8 9.73a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.85.29 1.73.5 2.63.62A2 2 0 0 1 22 16.92Z"/>',
        'seo'=>'<circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>',
        'nav'=>'<path d="M4 6h16M4 12h16M4 18h16"/>',
        'design'=>'<path d="M12 22a10 10 0 1 0 0-20c-1 0-2 .2-2 1.5 0 1 .8 1.5 1.5 2.2.7.6.5 1.8-.5 2.2-1.3.5-3.5-.4-4.7 1.4C4.2 12.5 7 22 12 22Z"/><circle cx="7.5" cy="10.5" r="1"/><circle cx="10.5" cy="6.5" r="1"/><circle cx="15" cy="6.5" r="1"/><circle cx="17" cy="11" r="1"/>',
        'settings'=>'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.1V21a2 2 0 1 1-4 0v-.1A1.7 1.7 0 0 0 8 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.7 1.7 0 0 0 3.6 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.1-.4H2a2 2 0 1 1 0-4h.1A1.7 1.7 0 0 0 3.6 8a1.7 1.7 0 0 0-.34-1.88l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.7 1.7 0 0 0 8 3.6a1.7 1.7 0 0 0 1-.6 1.7 1.7 0 0 0 .4-1.1V2a2 2 0 1 1 4 0v.1A1.7 1.7 0 0 0 15 3.6a1.7 1.7 0 0 0 1.88-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.7 1.7 0 0 0 19.4 8c.14.37.35.7.6 1 .3.3.7.5 1.1.5H21a2 2 0 1 1 0 4h-.1c-.4 0-.8.2-1.1.5-.25.3-.46.63-.6 1Z"/>',
        'profile'=>'<circle cx="12" cy="8" r="4"/><path d="M4 22a8 8 0 0 1 16 0"/>',
        'home'=>'<path d="m3 11 9-8 9 8"/><path d="M5 10v10h14V10M9 20v-6h6v6"/>',
        'team'=>'<circle cx="9" cy="7" r="4"/><path d="M2 21v-2a7 7 0 0 1 14 0v2M19 8v6M22 11h-6"/>',
        'forms'=>'<path d="M9 11h6M9 15h6M5 11h.01M5 15h.01"/><rect x="3" y="3" width="18" height="18" rx="2"/>',
        'activity'=>'<path d="M3 12h4l2-7 4 14 2-7h6"/>',
        'help'=>'<circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 1 1 5.8 1c0 2-3 2-3 4M12 18h.01"/>',
    ];
    $body = $icons[$name] ?? $icons['dashboard'];
    return '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $body . '</svg>';
}

$selectedPage = (string)($_GET['page'] ?? 'index.html');
if (!isset($pages[$selectedPage])) $selectedPage = 'index.html';
$pageMenu = [];
foreach ((array)($site['navigation'] ?? []) as $item) {
    $file = basename((string)(parse_url((string)($item['href'] ?? ''), PHP_URL_PATH) ?? ''));
    if (isset($pages[$file])) $pageMenu['page:'.$file] = [(string)($item['label'] ?? $pages[$file]), $file === 'index.html' ? 'home' : 'pages', $file];
}
foreach ($pages as $file=>$title) {
    if (!isset($pageMenu['page:'.$file])) $pageMenu['page:'.$file] = [$title,'pages',$file];
}
$menuGroups = [
    'ÜBERSICHT' => ['dashboard'=>['Übersicht','dashboard'], 'analytics'=>['Website-Statistik','dashboard']],
    'KUNDEN' => ['registrations'=>['Online-Anmeldungen','users'], 'messages'=>['Nachrichten','mail']],
    'WEBSITE-SEITEN' => $pageMenu,
];
if ($isOwner) $menuGroups['VERWALTUNG'] = ['users'=>['Benutzer','users'], 'activity'=>['Änderungsverlauf','activity'], 'settings'=>['Einstellungen und Sicherung','settings'], 'help'=>['Hilfe','help']];
$menuGroups['MEIN KONTO'] = ['profile'=>['Konto und Passwort','profile']];
$sectionTitle = $section === 'pages' ? (string)($pageMenu['page:'.$selectedPage][0] ?? $pages[$selectedPage]) : 'Verwaltung';
foreach ($menuGroups as $items) {
    if (isset($items[$section])) { $sectionTitle = (string)$items[$section][0]; break; }
}
?>
<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color" content="#0b0d10">
  <title>BV Admin Center</title>
  <link rel="stylesheet" href="assets/admin.css?v=20261104-1">
  <link rel="stylesheet" href="assets/workspace.css?v=20261104-2">
</head>
<body class="admin-shell">
<a class="skip-link" href="#main-content">Zum Inhalt springen</a>
<div class="mobile-overlay" data-menu-close></div>
<aside class="sidebar" id="sidebar" aria-label="Administration">
  <button type="button" class="icon-btn sidebar-close" data-menu-close aria-label="Menü schließen">×</button>
  <div class="brand sidebar-brand"><span class="brand-mark">BV</span><span><b>Fahrschule BV</b><small>Admin Center</small></span></div>
  <div class="sidebar-role"><span class="status-dot online"></span><span><?= $isOwner ? 'Hauptadministrator · Vollzugriff' : 'Benutzer · Inhalte und Kunden' ?></span></div>
  <label class="nav-search" for="nav-search"><span class="sr-only">Bereich suchen</span><?=icon('seo')?><input id="nav-search" type="search" placeholder="Bereich suchen …" autocomplete="off" data-nav-search aria-controls="admin-navigation"><kbd>/</kbd></label>
  <p class="nav-search-empty" data-nav-empty role="status" hidden>Kein Bereich gefunden.</p>
  <nav class="sidebar-nav" id="admin-navigation" aria-label="Hauptnavigation">
    <?php foreach ($menuGroups as $group=>$items): ?>
      <div class="nav-group"><small><?=$group?></small>
      <?php foreach ($items as $key=>$meta):
        $isPage = isset($meta[2]);
        $active = $isPage ? $section === 'pages' && $selectedPage === $meta[2] : $section === $key;
        $href = $isPage ? '?section=pages&page='.rawurlencode($meta[2]) : '?section='.$key;
      ?>
        <a class="nav-link <?=$active?'active':''?>" href="<?=cms_e($href)?>" <?=$isPage?'data-page-link="'.cms_e($meta[2]).'"':''?> <?=$active?'aria-current="page"':''?>>
          <?=icon($meta[1])?><span><?=$meta[0]?></span>
          <?php if ($key==='registrations' && $newRegs>0): ?><em><?=$newRegs?></em><?php endif; ?>
          <?php if ($key==='messages' && $newMsgs>0): ?><em><?=$newMsgs?></em><?php endif; ?>
        </a>
      <?php endforeach; ?></div>
    <?php endforeach; ?>
  </nav>
  <div class="sidebar-footer">
    <a href="../index.html" target="_blank" class="site-link">Website öffnen <span>↗</span></a>
    <a href="logout.php" class="logout">Abmelden</a>
  </div>
</aside>

<main class="workspace">
  <header class="topbar">
    <button type="button" class="icon-btn menu-btn" data-menu-open aria-label="Menü öffnen" aria-controls="sidebar" aria-expanded="false">☰</button>
    <div class="top-title"><b><?=cms_e($sectionTitle)?></b><span>fahrschule-bv.com</span></div>
    <div class="top-actions">
      <a href="../index.html?admin-preview=<?=time()?>" target="_blank" class="btn ghost desktop-only">Website prüfen ↗</a>
      <a href="?section=profile" class="user-chip"><span class="avatar"><?=strtoupper(substr((string)($user['username']??'U'),0,1))?></span><span><b><?=cms_e((string)($user['username']??''))?></b><small><?= $isOwner ? 'Hauptadministrator' : 'Benutzer' ?></small></span></a>
    </div>
  </header>

  <div class="content" id="main-content" tabindex="-1">
    <?php if (!empty($_GET['msg'])): ?><div class="alert success" data-toast><b>✓ Erfolgreich:</b> <?=cms_e((string)$_GET['msg'])?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert error" data-toast><?=cms_e($error)?></div><?php endif; ?>

    <?php if ($isOwner && $section !== 'pages'): ?>
      <section class="publish-bar <?=$publicInSync?'is-ready':'has-error'?>">
        <div><span class="status-dot <?=$publicInSync?'online':'warn'?>"></span><span><b><?=$publicInSync?'Änderungen sind auf der Website veröffentlicht':'Öffentliche Daten sind nicht synchronisiert'?></b><small><?=$lastPublished?'Letzte Speicherung: '.cms_e(str_replace('T',' ',substr($lastPublished,0,16))).' · Version '.$siteVersion:'Erstkonfiguration ist vorbereitet'?></small></span></div>
        <?php form_start('sync_public','dashboard');?><button class="btn ghost smallbtn">Erneut veröffentlichen</button></form>
      </section>
    <?php endif; ?>

    <?php if ($section === 'dashboard'): ?>
      <div class="dashboard-date"><?=icon('calendar')?> <time datetime="<?=date('Y-m-d')?>"><?=(new DateTimeImmutable('now', new DateTimeZone('Europe/Berlin')))->format('d.m.Y')?></time><span>Ihr Arbeitstag im Überblick</span></div>
      <div class="page-heading dashboard-heading"><div><span class="eyebrow">FAHRSCHULE BV · ADMIN CENTER</span><h1>Alles im Blick.</h1><p><?=$isOwner?'Neue Anfragen im Blick behalten und die Website einfach aktuell halten.':'Hier bearbeiten Sie Website-Inhalte, Online-Anmeldungen und Kontaktanfragen.'?></p></div><div class="site-state"><span class="status-dot <?=$websiteReady&&$publicInSync?'online':'warn'?>"></span><div><b><?=$websiteReady&&$publicInSync?'Website-Daten synchron':'Veröffentlichung prüfen'?></b><small>fahrschule-bv.com</small></div></div></div>

      <section class="dashboard-shortcuts" aria-labelledby="shortcuts-title">
        <div class="section-label"><h2 id="shortcuts-title">Direkt zur Aufgabe</h2><span>Weniger suchen. Einfach loslegen.</span></div>
        <div class="task-grid">
          <?php foreach ([
            ['registrations','users','Anmeldungen prüfen',$newRegs > 0 ? $newRegs.' neue Anmeldungen' : 'Alle Anmeldungen ansehen'],
            ['messages','mail','Nachrichten öffnen',$newMsgs > 0 ? $newMsgs.' neue Nachrichten' : 'Kontaktanfragen verwalten'],
            ['analytics','dashboard','Statistik ansehen','Besucher und Seitenaufrufe'],
            ['pages','pages','Startseite bearbeiten','Alle Texte, Bilder und Links'],
          ] as [$target,$taskIcon,$taskTitle,$taskDescription]): if (!cms_section_allowed($target)) continue; ?>
          <a class="task-card" href="?section=<?=cms_e($target)?><?=$target==='pages'?'&amp;page=index.html':''?>"><span class="task-icon"><?=icon($taskIcon)?></span><span><b><?=cms_e($taskTitle)?></b><small><?=cms_e($taskDescription)?></small></span><span class="task-arrow" aria-hidden="true">↗</span></a>
          <?php endforeach; ?>
        </div>
      </section>

      <div class="stats pro-stats">
        <?php if (cms_section_allowed('registrations') && cms_section_allowed('messages')): ?>
        <a href="?section=registrations" class="stat-card accent"><div class="stat-icon"><?=icon('users')?></div><div><span>Neue Anmeldungen</span><b><?=$newRegs?></b><small><?=count($regs)?> insgesamt</small></div></a>
        <a href="?section=messages" class="stat-card"><div class="stat-icon"><?=icon('mail')?></div><div><span>Neue Nachrichten</span><b><?=$newMsgs?></b><small><?=count($msgs)?> insgesamt</small></div></a>
        <a href="?section=pages&amp;page=index.html" class="stat-card"><div class="stat-icon"><?=icon('banner')?></div><div><span>Aktive Hinweise</span><b><?=$activeBanners?></b><small>Auf der Website sichtbar</small></div></a>
        <a href="?section=pages&amp;page=index.html" class="stat-card"><div class="stat-icon"><?=icon('pages')?></div><div><span>Bearbeitbare Seiten</span><b><?=count($pages)+count($site['customPages']??[])?></b><small>Texte und Inhalte</small></div></a>
        <?php else: ?>
        <a href="?section=homepage" class="stat-card accent"><div class="stat-icon"><?=icon('home')?></div><div><span>Startseite</span><b class="role-stat">Bearbeiten</b><small>Text, Bilder und Schaltflächen</small></div></a>
        <a href="?section=pages&amp;page=index.html" class="stat-card"><div class="stat-icon"><?=icon('pages')?></div><div><span>Seiten</span><b class="role-stat">Texte</b><small>Inhalte mit Vorschau bearbeiten</small></div></a>
        <a href="?section=prices" class="stat-card"><div class="stat-icon"><?=icon('euro')?></div><div><span>Preise</span><b class="role-stat">Ändern</b><small>Preisliste verwalten</small></div></a>
        <a href="?section=summer" class="stat-card"><div class="stat-icon"><?=icon('calendar')?></div><div><span>Kurse</span><b class="role-stat">Termine</b><small>Kurse verwalten</small></div></a>
        <?php endif; ?>
      </div>

      <div class="dashboard-grid">
        <?php if (cms_section_allowed('registrations')): ?>
        <section class="panel span-2">
          <div class="panel-head"><div><span class="eyebrow">AKTUELL</span><h2>Neueste Anmeldungen</h2></div><a class="text-link" href="?section=registrations">Alle anzeigen →</a></div>
          <div class="compact-list">
            <?php foreach (array_slice($regs,0,5) as $r): $rid=(string)($r['request_id']??$r['_dir']??''); $rst=$status['registrations'][$rid]['status']??'Neu'; $phone=(string)($r['telefon']??''); $mail=(string)($r['email']??''); ?>
              <div class="compact-row"><div class="avatar soft"><?=strtoupper(substr((string)($r['vorname']??$r['name']??'K'),0,1))?></div><div class="compact-main"><b><?=cms_e(trim((string)($r['vorname']??'').' '.(string)($r['name']??'')))?></b><span><?=cms_e((string)($r['art_der_anmeldung']??'Online-Anmeldung'))?> · <?=cms_e((string)($r['received_at']??''))?></span></div><span class="badge status-<?=cms_status_key($rst)?>"><?=cms_e($rst)?></span><div class="row-actions"><?php if($phone):?><a href="tel:<?=cms_e($phone)?>" title="Anrufen">☎</a><?php endif;?><?php if($phone):?><a target="_blank" href="https://wa.me/<?=cms_digits($phone)?>" title="WhatsApp">WA</a><?php endif;?><?php if($mail):?><a href="mailto:<?=cms_e($mail)?>" title="E-Mail">✉</a><?php endif;?></div></div>
            <?php endforeach; ?>
            <?php if (!$regs): ?><div class="empty-state"><b>Noch keine Anmeldungen</b><span>Neue Online-Anmeldungen erscheinen automatisch hier.</span></div><?php endif; ?>
          </div>
        </section>
        <?php endif; ?>

        <section class="panel">
          <div class="panel-head"><div><span class="eyebrow">STATUS</span><h2>Website und Formulare</h2></div></div>
          <div class="health-list">
            <div><span class="status-dot <?=$websiteReady?'online':'warn'?>"></span><span><b>Website-Dateien</b><small><?=$websiteReady?'index.html vorhanden':'index.html fehlt'?></small></span></div>
            <div><span class="status-dot <?=$formsReady?'online':'warn'?>"></span><span><b>Formulare</b><small><?=$formsReady?'Anmeldung & Kontakt bereit':'Formular-Skripte prüfen'?></small></span></div>
            <div><span class="status-dot <?=$sslActive?'online':'neutral'?>"></span><span><b>HTTPS / SSL</b><small><?=$sslActive?'Aktive HTTPS-Sitzung':'Nach Domain-Transfer prüfen'?></small></span></div>
          </div>
        </section>

        <section class="panel">
          <div class="panel-head"><div><span class="eyebrow">SCHNELLZUGRIFF</span><h2>Was möchten Sie bearbeiten?</h2></div></div>
          <div class="quick-grid">
            <a href="?section=pages&amp;page=index.html"><?=icon('home')?><span><b>Startseite</b><small>Alle Inhalte bearbeiten</small></span></a>
            <a href="?section=pages&amp;page=motorradkurs.html"><?=icon('pages')?><span><b>Motorradkurs</b><small>Texte und Fotos bearbeiten</small></span></a>
            <a href="?section=pages&amp;page=preisliste.html"><?=icon('euro')?><span><b>Preise</b><small>Preisseite bearbeiten</small></span></a>
            <a href="?section=pages&amp;page=kontakt.html"><?=icon('contact')?><span><b>Kontakt</b><small>Kontaktseite bearbeiten</small></span></a>
          </div>
        </section>

        <?php if ($isOwner): ?><section class="panel">
          <div class="panel-head"><div><span class="eyebrow">PROTOKOLL</span><h2>Letzte Änderungen</h2></div></div>
          <div class="activity-list">
            <?php foreach($activities as $a): ?><div class="activity-row"><span class="activity-dot"></span><div><b><?=cms_e((string)($a['action']??''))?></b><small><?=cms_e((string)($a['detail']??''))?><?=!empty($a['detail'])?' · ':''?><?=cms_e((string)($a['user']??''))?></small></div><time><?=cms_e(substr((string)($a['time']??''),0,16))?></time></div><?php endforeach; ?>
            <?php if(!$activities):?><div class="empty-state small-empty"><b>Noch keine Änderungen</b><span>Alle Änderungen werden hier protokolliert.</span></div><?php endif; ?>
          </div>
        </section>
        <?php endif; ?>
      </div>

    <?php elseif ($section === 'analytics'): require __DIR__ . '/analytics-panel.php'; ?>
    <?php elseif ($section === 'forms'): $fo=$site['forms']??[];$st=$site['settings']??[];$mc=cms_mail_config(); ?>
      <div class="page-heading"><div><span class="eyebrow">KUNDEN UND E-MAIL</span><h1>Formulare und E-Mail</h1><p>Festlegen, welche Formulare aktiv sind und wohin Benachrichtigungen gesendet werden.</p></div></div>
      <section class="panel form-panel"><div class="info-strip"><b>Wichtig:</b> Auch wenn eine E-Mail nicht zugestellt wird, bleibt die Anfrage geschützt im Admin Center gespeichert.</div><?php form_start('forms','forms'); ?><div class="grid2"><label class="toggle-row"><span><b>Online-Anmeldung aktiv</b><small>Formular auf „Online anmelden“ annehmen.</small></span><input type="checkbox" name="registration_enabled" <?=!isset($fo['registration_enabled'])||!empty($fo['registration_enabled'])?'checked':''?>></label><label class="toggle-row"><span><b>Kontaktformular aktiv</b><small>Nachrichten über die Kontaktseite annehmen.</small></span><input type="checkbox" name="contact_enabled" <?=!isset($fo['contact_enabled'])||!empty($fo['contact_enabled'])?'checked':''?>></label></div><div class="grid2"><label>Benachrichtigungs-E-Mail<input type="email" name="notification_email" value="<?=cms_e((string)($st['notification_email']??''))?>"></label><label>Dokumente aufbewahren (Tage)<input type="number" min="1" max="365" name="retention_days" value="<?=cms_e((string)($st['retention_days']??30))?>"></label><label>Maximale Upload-Größe gesamt (MB)<input type="number" min="1" max="25" name="max_upload_mb" value="<?=cms_e((string)($fo['max_upload_mb']??8))?>"></label><label>Zeitzone<input name="timezone" value="<?=cms_e((string)($st['timezone']??'Europe/Berlin'))?>"></label></div><label>Hinweis bei ausgeschalteter Anmeldung<textarea name="registration_notice" rows="3"><?=cms_e((string)($fo['registration_notice']??''))?></textarea></label><label>Hinweis bei ausgeschaltetem Kontaktformular<textarea name="contact_notice" rows="3"><?=cms_e((string)($fo['contact_notice']??''))?></textarea></label><button class="btn primary">Formulareinstellungen speichern</button></form></section>

      <section class="panel form-panel"><div class="panel-head"><div><span class="eyebrow">GOOGLE WORKSPACE</span><h2>E-Mail-Versand ohne Spam</h2></div><span class="badge <?=!empty($mc['enabled'])&&!empty($mc['app_password'])?'status-erledigt':'status-neutral'?>"><?=!empty($mc['enabled'])&&!empty($mc['app_password'])?'Eingerichtet':'Nicht eingerichtet'?></span></div><div class="info-strip"><b>Sicher:</b> Das Google-App-Passwort wird getrennt in <code>private_admin/mail.json</code> gespeichert und niemals öffentlich ausgegeben.</div><?php form_start('smtp','forms');?><label class="toggle-row"><span><b>Google SMTP aktivieren</b><small>Nachrichten authentifiziert über Google Workspace senden.</small></span><input type="checkbox" name="enabled" <?=!empty($mc['enabled'])?'checked':''?>></label><div class="grid2"><label>SMTP-Server<input name="host" value="<?=cms_e((string)($mc['host']??'smtp.gmail.com'))?>"></label><label>Port<input type="number" name="port" value="<?=cms_e((string)($mc['port']??587))?>"></label><label>Google-Workspace-E-Mail<input type="email" name="username" value="<?=cms_e((string)($mc['username']??'info@fahrschule-bv.com'))?>"></label><label>Google App-Passwort<input type="password" name="app_password" autocomplete="new-password" placeholder="<?=!empty($mc['app_password'])?'Bereits gespeichert – leer lassen':'16-stelliges App-Passwort einfügen'?>"><small>Leer lassen, um ein bereits gespeichertes Passwort zu behalten.</small></label></div><div class="form-actions"><button class="btn primary">SMTP speichern</button><button class="btn ghost" name="send_test" value="1">Speichern & Test senden</button></div></form></section>

    <?php elseif ($section === 'registrations'): ?>
      <div class="page-heading"><div><span class="eyebrow">KUNDEN</span><h1>Online-Anmeldungen</h1><p>Kundendaten, Dokumente und Bearbeitungsstatus verwalten.</p></div><div class="heading-badge"><?=$newRegs?> neu</div></div>
      <section class="toolbar panel"><div class="searchbox"><span>⌕</span><input type="search" placeholder="Name, E-Mail, Telefon oder Klasse suchen…" data-list-search="registrations"></div><select data-list-filter="registrations"><option value="">Alle Status</option><option>Neu</option><option>Kontaktiert</option><option>In Bearbeitung</option><option>Erledigt</option></select></section>
      <div class="list" data-list="registrations">
      <?php foreach ($regs as $r): $id=$r['request_id']??$r['_dir']; $st=$status['registrations'][$id]??['status'=>'Neu','note'=>'']; $name=trim((string)($r['vorname']??'').' '.(string)($r['name']??'')); $phone=(string)($r['telefon']??''); $email=(string)($r['email']??''); $search=strtolower($name.' '.$phone.' '.$email.' '.($r['art_der_anmeldung']??'').' '.($r['adresse']??'')); ?>
        <article class="item customer-card" data-item data-search="<?=cms_e($search)?>" data-status="<?=cms_e((string)$st['status'])?>">
          <div class="customer-top"><div class="customer-id"><div class="avatar large"><?=strtoupper(substr($name?:'K',0,1))?></div><div><h2><?=cms_e($name?:'Ohne Namen')?></h2><span><?=cms_e((string)($r['art_der_anmeldung']??'Online-Anmeldung'))?> · <?=cms_e((string)($r['received_at']??''))?></span></div></div><span class="badge status-<?=cms_status_key((string)$st['status'])?>"><?=cms_e((string)$st['status'])?></span></div>
          <div class="contact-actions"><?php if($phone):?><a class="action-pill" href="tel:<?=cms_e($phone)?>">☎ Anrufen</a><a class="action-pill whatsapp" target="_blank" href="https://wa.me/<?=cms_digits($phone)?>">WhatsApp</a><?php endif;?><?php if($email):?><a class="action-pill" href="mailto:<?=cms_e($email)?>">✉ E-Mail</a><?php endif;?></div>
          <div class="detail-grid"><div><small>Telefon</small><b><?=cms_e($phone?:'—')?></b></div><div><small>E-Mail</small><b><?=cms_e($email?:'—')?></b></div><div><small>Geburtsdatum</small><b><?=cms_e((string)($r['geburtsdatum']??'—'))?></b></div><div><small>Adresse</small><b><?=cms_e((string)($r['adresse']??'—'))?></b></div></div>
          <?php if (!empty($r['documents'])): ?><div class="documents"><small>DOKUMENTE</small><div><?php foreach($r['documents'] as $label=>$file):?><a target="_blank" href="file.php?r=<?=rawurlencode((string)$r['_dir'])?>&f=<?=rawurlencode((string)$file)?>">📎 <?=cms_e((string)$label)?></a><?php endforeach;?></div></div><?php endif; ?>
          <div class="card-form"><?php form_start('status','registrations');?><input type="hidden" name="kind" value="registrations"><input type="hidden" name="id" value="<?=cms_e((string)$id)?>"><div class="grid2"><label>Status<select name="status"><?php foreach(['Neu','Kontaktiert','In Bearbeitung','Erledigt'] as $x):?><option <?=$st['status']===$x?'selected':''?>><?=$x?></option><?php endforeach;?></select></label><label>Interne Notiz<input name="note" value="<?=cms_e((string)($st['note']??''))?>" placeholder="z. B. Rückruf vereinbart…"></label></div><div class="form-actions"><button class="btn primary">Änderungen speichern</button></div></form><?php if($isOwner):?><?php form_start('delete_registration','registrations');?><input type="hidden" name="id" value="<?=cms_e((string)$id)?>"><button class="btn danger" onclick="return confirm('Diese Anmeldung wirklich löschen?')">Löschen</button></form><?php endif;?></div>
        </article>
      <?php endforeach; ?>
      <?php if(!$regs):?><div class="empty-state panel"><b>Noch keine Anmeldungen</b><span>Sobald sich jemand online anmeldet, erscheint die Anfrage hier.</span></div><?php endif; ?>
      </div>

    <?php elseif ($section === 'messages'): ?>
      <div class="page-heading"><div><span class="eyebrow">KUNDEN</span><h1>Nachrichten</h1><p>Nachrichten aus dem Kontaktformular ansehen und bearbeiten.</p></div><div class="heading-badge"><?=$newMsgs?> neu</div></div>
      <section class="toolbar panel"><div class="searchbox"><span>⌕</span><input type="search" placeholder="Name, E-Mail oder Nachricht suchen…" data-list-search="messages"></div><select data-list-filter="messages"><option value="">Alle Status</option><option>Neu</option><option>Kontaktiert</option><option>Erledigt</option></select></section>
      <div class="list" data-list="messages">
      <?php foreach($msgs as $r): $id=$r['message_id']??$r['_file']; $st=$status['messages'][$id]??['status'=>'Neu','note'=>'']; $name=trim((string)($r['first_name']??'').' '.(string)($r['last_name']??'')); $email=(string)($r['email']??''); $search=strtolower($name.' '.$email.' '.($r['message']??'')); ?>
        <article class="item customer-card" data-item data-search="<?=cms_e($search)?>" data-status="<?=cms_e((string)$st['status'])?>"><div class="customer-top"><div class="customer-id"><div class="avatar large"><?=strtoupper(substr($name?:'N',0,1))?></div><div><h2><?=cms_e($name?:'Kontaktanfrage')?></h2><span><?=cms_e($email)?> · <?=cms_e((string)($r['received_at']??''))?></span></div></div><span class="badge status-<?=cms_status_key((string)$st['status'])?>"><?=cms_e((string)$st['status'])?></span></div>
        <?php if($email):?><div class="contact-actions"><a class="action-pill" href="mailto:<?=cms_e($email)?>">✉ E-Mail schreiben</a></div><?php endif; ?>
        <div class="message-box"><?=nl2br(cms_e((string)($r['message']??'')))?></div>
        <div class="card-form"><?php form_start('status','messages');?><input type="hidden" name="kind" value="messages"><input type="hidden" name="id" value="<?=cms_e((string)$id)?>"><div class="grid2"><label>Status<select name="status"><?php foreach(['Neu','Kontaktiert','Erledigt'] as $x):?><option <?=$st['status']===$x?'selected':''?>><?=$x?></option><?php endforeach;?></select></label><label>Interne Notiz<input name="note" value="<?=cms_e((string)($st['note']??''))?>" placeholder="Nur intern sichtbar"></label></div><div class="form-actions"><button class="btn primary">Änderungen speichern</button></div></form><?php if($isOwner):?><?php form_start('delete_message','messages');?><input type="hidden" name="id" value="<?=cms_e((string)$r['_file'])?>"><button class="btn danger" onclick="return confirm('Diese Nachricht wirklich löschen?')">Löschen</button></form><?php endif;?></div></article>
      <?php endforeach; ?>
      <?php if(!$msgs):?><div class="empty-state panel"><b>Noch keine Nachrichten</b><span>Kontaktanfragen erscheinen automatisch hier.</span></div><?php endif; ?>
      </div>

    <?php elseif ($section === 'pages'): require __DIR__ . '/page-editor.php'; ?>

    <?php elseif ($section === 'users'): ?>
      <div class="page-heading"><div><span class="eyebrow">SYSTEM</span><h1>Benutzer</h1><p>Der Hauptadministrator hat Vollzugriff. Weitere Konten erhalten Zugriff auf Website-Inhalte, Online-Anmeldungen und Kontaktanfragen.</p></div></div>
      <section class="access-note panel"><div class="shield">✓</div><div><b>Hauptadministrator: <?=cms_e(CMS_SUPERUSER)?></b><p>Dieses Konto besitzt dauerhaft Zugriff auf alle Funktionen. Andere Benutzer können Website-Inhalte, Online-Anmeldungen, Kontaktanfragen und ihr eigenes Konto bearbeiten.</p></div></section>
      <div class="two-col users-layout"><section class="panel form-panel"><div class="panel-head"><div><span class="eyebrow">MITARBEITER</span><h2>Neuen Benutzer anlegen</h2></div></div><?php form_start('user_add','users');?><label>E-Mail-Adresse<input type="email" name="username" required placeholder="mitarbeiter@beispiel.de"></label><label>Startpasswort<input type="password" name="password" minlength="10" required></label><div class="permission-chip">Inhaltszugriff: Startseite · Seiten · Team · Galerie · Preise · Kurse · Hinweise · Medien · Kontaktdaten · Online-Anmeldungen · Nachrichten</div><button class="btn primary">Mitarbeiter hinzufügen</button></form></section><section class="list"><?php foreach(cms_users() as $u):$super=cms_is_superuser_name((string)$u['username'])?><article class="item user-card"><div class="user-card-head"><div class="avatar large"><?=strtoupper(substr((string)$u['username'],0,1))?></div><div><b><?=cms_e((string)$u['username'])?></b><span><?=$super?'Hauptadministrator · Vollzugriff':'Mitarbeiter · Inhalte und Kunden'?></span></div><span class="badge <?=$super?'status-erledigt':'status-neutral'?>"><?=$super?'Owner':'Inhalte'?></span></div><?php form_start('user_password','users');?><input type="hidden" name="username" value="<?=cms_e((string)$u['username'])?>"><div class="inline-password"><input type="password" name="password" minlength="10" required placeholder="Neues Passwort"><button class="btn ghost">Passwort ändern</button></div></form><?php if(!$super && $u['username']!==($user['username']??'')):?><?php form_start('user_delete','users');?><input type="hidden" name="username" value="<?=cms_e((string)$u['username'])?>"><button class="btn danger smallbtn" onclick="return confirm('Benutzer wirklich löschen?')">Benutzer löschen</button></form><?php endif;?></article><?php endforeach;?></section></div>

    <?php elseif ($section === 'activity'): $allActivities=cms_activity(100); ?>
      <div class="page-heading"><div><span class="eyebrow">VERWALTUNG</span><h1>Änderungsverlauf</h1><p>Prüfen, welcher Benutzer wann welche Änderung vorgenommen hat.</p></div></div>
      <section class="panel"><div class="activity-list activity-full"><?php foreach($allActivities as $a):?><div class="activity-row"><span class="activity-dot"></span><div><b><?=cms_e((string)($a['action']??''))?></b><small><?=cms_e((string)($a['detail']??''))?><?=!empty($a['detail'])?' · ':''?><?=cms_e((string)($a['user']??''))?></small></div><time><?=cms_e(str_replace('T',' ',substr((string)($a['time']??''),0,16)))?></time></div><?php endforeach;?><?php if(!$allActivities):?><div class="empty-state"><b>Noch keine Aktivitäten</b><span>Änderungen werden automatisch protokolliert.</span></div><?php endif;?></div></section>

    <?php elseif ($section === 'help'): ?>
      <div class="page-heading"><div><span class="eyebrow">HILFE</span><h1>Eine Seite wählen. Alles dort ändern.</h1><p>Jede Website-Seite hat einen eigenen Eintrag im linken Menü.</p></div></div>
      <section class="panel"><ol class="editor-help-list"><li>Links die gewünschte Seite öffnen.</li><li>Rechts erscheinen alle Texte, Bilder und Links dieser Seite, auch aus Kopf- und Fußzeile.</li><li>Beim gewünschten Inhalt auf „Text ändern“, „Bild ändern“ oder „Link ändern“ klicken.</li><li>Die Änderung in die Vorschau übernehmen und kontrollieren.</li><li>Mit „Speichern & veröffentlichen“ die Änderungen dieser Seite veröffentlichen.</li></ol><p class="muted-copy">Statistik, Anmeldungen, Nachrichten und Benutzerverwaltung bleiben eigene Verwaltungsbereiche.</p></section>

    <?php elseif ($section === 'settings'): $st=$site['settings']??[]; ?>
      <div class="page-heading"><div><span class="eyebrow">VERWALTUNG</span><h1>Einstellungen und Sicherung</h1><p>Technische Grundeinstellungen und Datensicherung des Admin Centers.</p></div></div>
      <div class="two-col"><section class="panel form-panel"><?php form_start('settings','settings');?><div class="grid2"><label>Dokumente aufbewahren (Tage)<input type="number" min="1" max="365" name="retention_days" value="<?=cms_e((string)($st['retention_days']??30))?>"><small>Empfohlen: nur so lange wie organisatorisch notwendig.</small></label><label>Benachrichtigungs-E-Mail<input type="email" name="notification_email" value="<?=cms_e((string)($st['notification_email']??''))?>"></label><label>Zeitzone<input name="timezone" value="<?=cms_e((string)($st['timezone']??'Europe/Berlin'))?>"></label></div><button class="btn primary">Einstellungen speichern</button></form></section><section class="panel form-panel"><span class="eyebrow">SICHERUNG</span><h2>Admin-Daten exportieren</h2><a class="btn ghost smallbtn" href="?section=forms">Formulare und E-Mail einrichten</a><p class="muted-copy">Lädt eine JSON-Sicherung von Website-Einstellungen, Status und Aktivitätsprotokoll herunter. Kundendokumente werden aus Datenschutzgründen nicht in diesen Export aufgenommen.</p><a class="btn ghost" href="export.php">Sicherung herunterladen</a></section></div>

    <?php elseif ($section === 'profile'): ?>
      <div class="page-heading"><div><span class="eyebrow">KONTO</span><h1>Mein Konto</h1><p>Anmeldedaten und Zugriffsrolle.</p></div></div>
      <div class="two-col profile-layout"><section class="panel profile-card"><div class="avatar xlarge"><?=strtoupper(substr((string)($user['username']??'U'),0,1))?></div><h2><?=cms_e((string)($user['username']??''))?></h2><span class="badge <?=$isOwner?'status-erledigt':'status-neutral'?>"><?=$isOwner?'Hauptadministrator · Vollzugriff':'Mitarbeiter · Inhalte und Kunden'?></span><div class="permission-list"><?php if($isOwner):?><span>✓ Alle Website-Funktionen</span><span>✓ Benutzerverwaltung</span><span>✓ Kundenverwaltung</span><span>✓ Systemeinstellungen</span><?php else:?><span>✓ Startseite, Seiten und Texte</span><span>✓ Team, Galerie, Preise und Kurse</span><span>✓ Hinweise, Medien und Kontaktdaten</span><span>✓ Online-Anmeldungen, Dokumente und Nachrichten</span><span>✓ Bearbeitungsstatus und interne Notizen</span><span>— Keine Benutzerverwaltung, E-Mail- oder Systemeinstellungen</span><?php endif;?></div></section><section class="panel form-panel"><div class="panel-head"><div><span class="eyebrow">SICHERHEIT</span><h2>Passwort ändern</h2></div></div><?php form_start('self_password','profile');?><label>Neues Passwort<div class="password-field"><input id="profile-password" type="password" name="password" minlength="10" required><button type="button" class="password-eye" data-password-toggle="profile-password" aria-label="Passwort anzeigen" title="Passwort anzeigen">👁</button></div></label><label>Passwort wiederholen<div class="password-field"><input id="profile-password-confirm" type="password" name="password_confirm" minlength="10" required><button type="button" class="password-eye" data-password-toggle="profile-password-confirm" aria-label="Passwort anzeigen" title="Passwort anzeigen">👁</button></div></label><button class="btn primary">Passwort aktualisieren</button></form></section></div>
    <?php endif; ?>
  </div>
</main>
<script src="assets/admin.js?v=20261104-2"></script>
<script>
document.querySelectorAll('[data-password-toggle]').forEach(function(btn){
  btn.addEventListener('click', function(){
    var input=document.getElementById(btn.getAttribute('data-password-toggle'));
    if(!input) return;
    var show=input.type==='password';
    input.type=show?'text':'password';
    btn.textContent=show?'🙈':'👁';
    btn.setAttribute('aria-label', show?'Passwort ausblenden':'Passwort anzeigen');
    btn.setAttribute('title', show?'Passwort ausblenden':'Passwort anzeigen');
    input.focus({preventScroll:true});
  });
});
</script>
</body>
</html>
