<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';

if (!cms_is_setup()) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        cms_check_csrf();
        $u = CMS_SUPERUSER;
        $p = (string)($_POST['password'] ?? '');
        $pc = (string)($_POST['password_confirm'] ?? '');
        if (strlen($p) < 10) $err = 'Das Passwort muss mindestens 10 Zeichen lang sein.';
        elseif ($p !== $pc) $err = 'Die Passwörter stimmen nicht überein.';
        else {
            $users = cms_users();
            foreach ($users as &$existing) $existing['role'] = 'staff';
            unset($existing);
            $users[] = [
                'username' => $u,
                'password_hash' => password_hash($p, PASSWORD_DEFAULT),
                'role' => 'owner',
                'active' => true,
            ];
            cms_json_write(CMS_USERS_FILE, $users);
            cms_login($u, $p);
            header('Location: index.php');
            exit;
        }
    }
    ?><!doctype html>
    <html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BV Admin einrichten</title><link rel="stylesheet" href="assets/admin.css?v=20261104-1"><style>
.password-field{position:relative;display:block;width:100%}.password-field input{width:100%;padding-right:48px}.password-eye{position:absolute;right:8px;top:50%;transform:translateY(-50%);width:34px;height:34px;border:1px solid #2b333d;border-radius:9px;background:#11171d;color:#c9d1d9;display:grid;place-items:center;cursor:pointer;font-size:16px;line-height:1}.password-eye:hover{border-color:#ff7a1a;color:#fff}.password-eye:focus-visible{outline:2px solid #ff7a1a;outline-offset:2px}
</style></head>
    <body class="auth">
      <form method="post" class="auth-card">
        <div class="brand"><span class="brand-mark">BV</span><span><b>Fahrschule BV</b><small>Admin Center</small></span></div>
        <div class="auth-copy"><span class="eyebrow">ERSTEINRICHTUNG</span><h1>Hauptadministrator einrichten</h1><p>Dieses Konto erhält vollständigen Zugriff auf alle Funktionen der Website.</p></div>
        <?php if (!empty($err)): ?><div class="alert error"><?=cms_e($err)?></div><?php endif; ?>
        <input type="hidden" name="csrf" value="<?=cms_e(cms_csrf())?>">
        <label>Administrator-E-Mail<input value="<?=cms_e(CMS_SUPERUSER)?>" readonly></label>
        <label>Passwort<div class="password-field"><input id="setup-password" type="password" name="password" minlength="10" required autocomplete="new-password"><button type="button" class="password-eye" data-password-toggle="setup-password" aria-label="Passwort anzeigen" title="Passwort anzeigen">👁</button></div></label>
        <label>Passwort wiederholen<div class="password-field"><input id="setup-password-confirm" type="password" name="password_confirm" minlength="10" required autocomplete="new-password"><button type="button" class="password-eye" data-password-toggle="setup-password-confirm" aria-label="Passwort anzeigen" title="Passwort anzeigen">👁</button></div></label>
        <button class="btn primary full">Admin Center aktivieren</button>
      </form>
      <script>
document.querySelectorAll('[data-password-toggle]').forEach(function(btn){
  btn.addEventListener('click', function(){
    var input=document.getElementById(btn.getAttribute('data-password-toggle'));
    if(!input) return;
    var show=input.type==='password';
    input.type=show?'text':'password';
    btn.textContent=show?'🙈':'👁';
    btn.setAttribute('aria-label', show?'Passwort ausblenden':'Passwort anzeigen');
    btn.setAttribute('title', show?'Passwort ausblenden':'Passwort anzeigen');
    input.focus({preventScroll:true});
  });
});
</script>
    </body></html><?php
    exit;
}

if (!cms_logged_in()) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        cms_check_csrf();
        $lock = (int)($_SESSION['cms_lock_until'] ?? 0);
        if ($lock > time()) {
            $err = 'Zu viele Versuche. Bitte später erneut versuchen.';
        } elseif (cms_login((string)($_POST['username'] ?? ''), (string)($_POST['password'] ?? ''))) {
            header('Location: index.php'); exit;
        } else {
            $_SESSION['cms_login_failures'] = (int)($_SESSION['cms_login_failures'] ?? 0) + 1;
            if ($_SESSION['cms_login_failures'] >= 5) {
                $_SESSION['cms_lock_until'] = time() + 900;
                $_SESSION['cms_login_failures'] = 0;
                $err = 'Zu viele Versuche. Anmeldung für 15 Minuten gesperrt.';
            } else $err = 'E-Mail oder Passwort ist falsch.';
        }
    }
    ?><!doctype html>
    <html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BV Admin Anmeldung</title><link rel="stylesheet" href="assets/admin.css?v=20261104-1"><style>
.password-field{position:relative;display:block;width:100%}.password-field input{width:100%;padding-right:48px}.password-eye{position:absolute;right:8px;top:50%;transform:translateY(-50%);width:34px;height:34px;border:1px solid #2b333d;border-radius:9px;background:#11171d;color:#c9d1d9;display:grid;place-items:center;cursor:pointer;font-size:16px;line-height:1}.password-eye:hover{border-color:#ff7a1a;color:#fff}.password-eye:focus-visible{outline:2px solid #ff7a1a;outline-offset:2px}
</style></head>
    <body class="auth">
      <form method="post" class="auth-card">
        <div class="brand"><span class="brand-mark">BV</span><span><b>Fahrschule BV</b><small>Admin Center</small></span></div>
        <div class="auth-copy"><span class="eyebrow">GESCHÜTZTER BEREICH</span><h1>Willkommen zurück</h1><p>Melden Sie sich an, um Website, Anmeldungen und Nachrichten zu verwalten.</p></div>
        <?php if (!empty($err)): ?><div class="alert error"><?=cms_e($err)?></div><?php endif; ?>
        <input type="hidden" name="csrf" value="<?=cms_e(cms_csrf())?>">
        <label>E-Mail-Adresse<input type="email" name="username" required autofocus autocomplete="username"></label>
        <label>Passwort<div class="password-field"><input id="login-password" type="password" name="password" required autocomplete="current-password"><button type="button" class="password-eye" data-password-toggle="login-password" aria-label="Passwort anzeigen" title="Passwort anzeigen">👁</button></div></label>
        <button class="btn primary full">Anmelden</button>
      </form>
      <script>
document.querySelectorAll('[data-password-toggle]').forEach(function(btn){
  btn.addEventListener('click', function(){
    var input=document.getElementById(btn.getAttribute('data-password-toggle'));
    if(!input) return;
    var show=input.type==='password';
    input.type=show?'text':'password';
    btn.textContent=show?'🙈':'👁';
    btn.setAttribute('aria-label', show?'Passwort ausblenden':'Passwort anzeigen');
    btn.setAttribute('title', show?'Passwort ausblenden':'Passwort anzeigen');
    input.focus({preventScroll:true});
  });
});
</script>
    </body></html><?php
    exit;
}

$section = (string)($_GET['section'] ?? 'dashboard');
if (!cms_section_allowed($section)) {
    $_SESSION['cms_error'] = 'Für diesen Bereich haben Sie keine Berechtigung.';
    header('Location: index.php?section=dashboard'); exit;
}

$site = cms_site();
$user = cms_user();
$isOwner = cms_is_owner();
$status = cms_status();
$regs = cms_section_allowed('registrations') ? cms_registrations() : [];
$msgs = cms_section_allowed('messages') ? cms_messages() : [];
$pages = cms_static_pages();
$error = $_SESSION['cms_error'] ?? '';
unset($_SESSION['cms_error']);
$activities = $isOwner ? cms_activity(8) : [];

$newRegs = 0;
foreach ($regs as $r) {
    $id = (string)($r['request_id'] ?? $r['_dir'] ?? '');
    if (($status['registrations'][$id]['status'] ?? 'Neu') === 'Neu') $newRegs++;
}
$newMsgs = 0;
foreach ($msgs as $r) {
    $id = (string)($r['message_id'] ?? $r['_file'] ?? '');
    if (($status['messages'][$id]['status'] ?? 'Neu') === 'Neu') $newMsgs++;
}
$activeBanners = count(array_filter($site['banners'] ?? [], fn($b) => !empty($b['active'])));
$websiteReady = is_file(__DIR__ . '/../index.html');
$formsReady = is_file(__DIR__ . '/../process-anmeldung.php') && is_file(__DIR__ . '/../process-contact.php');
$sslActive = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
$publicReady = is_file(CMS_PUBLIC_SITE_FILE);
$publicInSync = $publicReady && is_file(CMS_SITE_FILE) && hash_file('sha256', CMS_PUBLIC_SITE_FILE) === hash_file('sha256', CMS_SITE_FILE);
$lastPublished = (string)($site['_meta']['updated_at'] ?? '');
$siteVersion = (int)($site['_meta']['version'] ?? 0);

function form_start(string $action, string $return = ''): void {
    echo '<form method="post" action="save.php"><input type="hidden" name="csrf" value="' . cms_e(cms_csrf()) . '"><input type="hidden" name="action" value="' . cms_e($action) . '">';
    if ($return) echo '<input type="hidden" name="return_section" value="' . cms_e($return) . '">';
}
function block_fields(): void {
    echo '<div class="grid2"><label>Elementtyp<select name="type"><option value="text">Text</option><option value="text_image">Text + Bild</option><option value="image">Bild</option><option value="cta">Call-to-Action</option></select></label><label>Bild / URL<input name="image" placeholder="assets/uploads/... oder https://..."></label></div><label>Titel<input name="title"></label><label>Text<textarea name="text" rows="4"></textarea></label><div class="grid2"><label>Button-Text<input name="buttonText"></label><label>Button-Link<input name="buttonLink"></label></div>';
}
function icon(string $name): string {
    $icons = [
        'dashboard'=>'<path d="M4 13h6V4H4v9Zm0 7h6v-5H4v5Zm10 0h6v-9h-6v9Zm0-16v5h6V4h-6Z"/>',
        'users'=>'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
        'mail'=>'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
        'pages'=>'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M8 13h8M8 17h8"/>',
        'euro'=>'<path d="M18 7.5a6 6 0 1 0 0 9M5 10h9M5 14h8"/>',
        'calendar'=>'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18"/>',
        'banner'=>'<path d="M3 11h18M5 11V6h14v5M7 11v7h10v-7"/><path d="M9 15h6"/>',
        'image'=>'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
        'contact'=>'<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.12.9.33 1.78.62 2.63a2 2 0 0 1-.45 2.11L8 9.73a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.85.29 1.73.5 2.63.62A2 2 0 0 1 22 16.92Z"/>',
        'seo'=>'<circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>',
        'nav'=>'<path d="M4 6h16M4 12h16M4 18h16"/>',
        'design'=>'<path d="M12 22a10 10 0 1 0 0-20c-1 0-2 .2-2 1.5 0 1 .8 1.5 1.5 2.2.7.6.5 1.8-.5 2.2-1.3.5-3.5-.4-4.7 1.4C4.2 12.5 7 22 12 22Z"/><circle cx="7.5" cy="10.5" r="1"/><circle cx="10.5" cy="6.5" r="1"/><circle cx="15" cy="6.5" r="1"/><circle cx="17" cy="11" r="1"/>',
        'settings'=>'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.1V21a2 2 0 1 1-4 0v-.1A1.7 1.7 0 0 0 8 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.7 1.7 0 0 0 3.6 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.1-.4H2a2 2 0 1 1 0-4h.1A1.7 1.7 0 0 0 3.6 8a1.7 1.7 0 0 0-.34-1.88l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.7 1.7 0 0 0 8 3.6a1.7 1.7 0 0 0 1-.6 1.7 1.7 0 0 0 .4-1.1V2a2 2 0 1 1 4 0v.1A1.7 1.7 0 0 0 15 3.6a1.7 1.7 0 0 0 1.88-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.7 1.7 0 0 0 19.4 8c.14.37.35.7.6 1 .3.3.7.5 1.1.5H21a2 2 0 1 1 0 4h-.1c-.4 0-.8.2-1.1.5-.25.3-.46.63-.6 1Z"/>',
        'profile'=>'<circle cx="12" cy="8" r="4"/><path d="M4 22a8 8 0 0 1 16 0"/>',
        'home'=>'<path d="m3 11 9-8 9 8"/><path d="M5 10v10h14V10M9 20v-6h6v6"/>',
        'team'=>'<circle cx="9" cy="7" r="4"/><path d="M2 21v-2a7 7 0 0 1 14 0v2M19 8v6M22 11h-6"/>',
        'forms'=>'<path d="M9 11h6M9 15h6M5 11h.01M5 15h.01"/><rect x="3" y="3" width="18" height="18" rx="2"/>',
        'activity'=>'<path d="M3 12h4l2-7 4 14 2-7h6"/>',
        'help'=>'<circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 1 1 5.8 1c0 2-3 2-3 4M12 18h.01"/>',
    ];
    $body = $icons[$name] ?? $icons['dashboard'];
    return '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $body . '</svg>';
}

$menuGroups = $isOwner ? [
    'ÜBERSICHT' => ['dashboard'=>['Übersicht','dashboard'], 'analytics'=>['Website-Statistik','dashboard']],
    'WEBSITE-INHALTE' => ['homepage'=>['Startseite','home'], 'pages'=>['Seiten und Texte','pages'], 'team'=>['Team','team'], 'gallery'=>['Bildergalerie','image'], 'prices'=>['Preise','euro'], 'summer'=>['Kurse und Termine','calendar'], 'banner'=>['Website-Hinweise','banner'], 'media'=>['Medien','image'], 'website'=>['Kontaktdaten','contact']],
    'KUNDEN UND E-MAIL' => ['forms'=>['Formulare und E-Mail','forms'], 'registrations'=>['Online-Anmeldungen','users'], 'messages'=>['Nachrichten','mail']],
    'KONFIGURATION' => ['navigation'=>['Website-Menü','nav'], 'seo'=>['Google / SEO','seo'], 'design'=>['Farben und Design','design']],
    'VERWALTUNG' => ['users'=>['Benutzer','users'], 'activity'=>['Änderungsverlauf','activity'], 'settings'=>['Einstellungen und Sicherung','settings'], 'help'=>['Hilfe – Funktionen erklärt','help']],
    'MEIN KONTO' => ['profile'=>['Konto und Passwort','profile']],
] : [
    'ÜBERSICHT' => ['dashboard'=>['Übersicht','dashboard'], 'analytics'=>['Website-Statistik','dashboard']],
    'WEBSITE-INHALTE' => ['homepage'=>['Startseite','home'], 'pages'=>['Seiten und Texte','pages'], 'team'=>['Team','team'], 'gallery'=>['Bildergalerie','image'], 'prices'=>['Preise','euro'], 'summer'=>['Kurse und Termine','calendar'], 'banner'=>['Website-Hinweise','banner'], 'media'=>['Medien','image'], 'website'=>['Kontaktdaten','contact']],
    'KUNDEN' => ['registrations'=>['Online-Anmeldungen','users'], 'messages'=>['Nachrichten','mail']],
    'MEIN KONTO' => ['profile'=>['Konto und Passwort','profile']],
];
$sectionTitle = 'Verwaltung';
foreach ($menuGroups as $items) {
    if (isset($items[$section])) { $sectionTitle = (string)$items[$section][0]; break; }
}
?>
<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color" content="#0b0d10">
  <title>BV Admin Center</title>
  <link rel="stylesheet" href="assets/admin.css?v=20261104-1">
  <link rel="stylesheet" href="assets/workspace.css?v=20261104-1">
</head>
<body class="admin-shell">
<a class="skip-link" href="#main-content">Zum Inhalt springen</a>
<div class="mobile-overlay" data-menu-close></div>
<aside class="sidebar" id="sidebar" aria-label="Administration">
  <button type="button" class="icon-btn sidebar-close" data-menu-close aria-label="Menü schließen">×</button>
  <div class="brand sidebar-brand"><span class="brand-mark">BV</span><span><b>Fahrschule BV</b><small>Admin Center</small></span></div>
  <div class="sidebar-role"><span class="status-dot online"></span><span><?= $isOwner ? 'Hauptadministrator · Vollzugriff' : 'Benutzer · Inhalte und Kunden' ?></span></div>
  <label class="nav-search" for="nav-search"><span class="sr-only">Bereich suchen</span><?=icon('seo')?><input id="nav-search" type="search" placeholder="Bereich suchen …" autocomplete="off" data-nav-search aria-controls="admin-navigation"><kbd>/</kbd></label>
  <p class="nav-search-empty" data-nav-empty role="status" hidden>Kein Bereich gefunden.</p>
  <nav class="sidebar-nav" id="admin-navigation" aria-label="Hauptnavigation">
    <?php foreach ($menuGroups as $group=>$items): ?>
      <div class="nav-group"><small><?=$group?></small>
      <?php foreach ($items as $key=>$meta): ?>
        <a class="nav-link <?=$section===$key?'active':''?>" href="?section=<?=$key?>" <?=$section===$key?'aria-current="page"':''?>>
          <?=icon($meta[1])?><span><?=$meta[0]?></span>
          <?php if ($key==='registrations' && $newRegs>0): ?><em><?=$newRegs?></em><?php endif; ?>
          <?php if ($key==='messages' && $newMsgs>0): ?><em><?=$newMsgs?></em><?php endif; ?>
        </a>
      <?php endforeach; ?></div>
    <?php endforeach; ?>
  </nav>
  <div class="sidebar-footer">
    <a href="../index.html" target="_blank" class="site-link">Website öffnen <span>↗</span></a>
    <a href="logout.php" class="logout">Abmelden</a>
  </div>
</aside>

<main class="workspace">
  <header class="topbar">
    <button type="button" class="icon-btn menu-btn" data-menu-open aria-label="Menü öffnen" aria-controls="sidebar" aria-expanded="false">☰</button>
    <div class="top-title"><b><?=cms_e($sectionTitle)?></b><span>fahrschule-bv.com</span></div>
    <div class="top-actions">
      <a href="../index.html?admin-preview=<?=time()?>" target="_blank" class="btn ghost desktop-only">Website prüfen ↗</a>
      <a href="?section=profile" class="user-chip"><span class="avatar"><?=strtoupper(substr((string)($user['username']??'U'),0,1))?></span><span><b><?=cms_e((string)($user['username']??''))?></b><small><?= $isOwner ? 'Hauptadministrator' : 'Benutzer' ?></small></span></a>
    </div>
  </header>

  <div class="content" id="main-content" tabindex="-1">
    <?php if (!empty($_GET['msg'])): ?><div class="alert success" data-toast><b>✓ Erfolgreich:</b> <?=cms_e((string)$_GET['msg'])?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert error" data-toast><?=cms_e($error)?></div><?php endif; ?>

    <?php if ($isOwner): ?>
      <section class="publish-bar <?=$publicInSync?'is-ready':'has-error'?>">
        <div><span class="status-dot <?=$publicInSync?'online':'warn'?>"></span><span><b><?=$publicInSync?'Änderungen sind auf der Website veröffentlicht':'Öffentliche Daten sind nicht synchronisiert'?></b><small><?=$lastPublished?'Letzte Speicherung: '.cms_e(str_replace('T',' ',substr($lastPublished,0,16))).' · Version '.$siteVersion:'Erstkonfiguration ist vorbereitet'?></small></span></div>
        <?php form_start('sync_public','dashboard');?><button class="btn ghost smallbtn">Erneut veröffentlichen</button></form>
      </section>
    <?php endif; ?>

    <?php if ($section === 'dashboard'): ?>
      <div class="dashboard-date"><?=icon('calendar')?> <time datetime="<?=date('Y-m-d')?>"><?=(new DateTimeImmutable('now', new DateTimeZone('Europe/Berlin')))->format('d.m.Y')?></time><span>Ihr Arbeitstag im Überblick</span></div>
      <div class="page-heading dashboard-heading"><div><span class="eyebrow">FAHRSCHULE BV · ADMIN CENTER</span><h1>Alles im Blick.</h1><p><?=$isOwner?'Neue Anfragen im Blick behalten und die Website einfach aktuell halten.':'Hier bearbeiten Sie Website-Inhalte, Online-Anmeldungen und Kontaktanfragen.'?></p></div><div class="site-state"><span class="status-dot <?=$websiteReady&&$publicInSync?'online':'warn'?>"></span><div><b><?=$websiteReady&&$publicInSync?'Website-Daten synchron':'Veröffentlichung prüfen'?></b><small>fahrschule-bv.com</small></div></div></div>

      <section class="dashboard-shortcuts" aria-labelledby="shortcuts-title">
        <div class="section-label"><h2 id="shortcuts-title">Direkt zur Aufgabe</h2><span>Weniger suchen. Einfach loslegen.</span></div>
        <div class="task-grid">
          <?php foreach ([
            ['registrations','users','Anmeldungen prüfen',$newRegs > 0 ? $newRegs.' neue Anmeldungen' : 'Alle Anmeldungen ansehen'],
            ['messages','mail','Nachrichten öffnen',$newMsgs > 0 ? $newMsgs.' neue Nachrichten' : 'Kontaktanfragen verwalten'],
            ['summer','calendar','Kurse planen','Termine und Sichtbarkeit bearbeiten'],
            ['pages','pages','Website bearbeiten','Texte und Inhalte mit Vorschau'],
          ] as [$target,$taskIcon,$taskTitle,$taskDescription]): if (!cms_section_allowed($target)) continue; ?>
          <a class="task-card" href="?section=<?=cms_e($target)?>"><span class="task-icon"><?=icon($taskIcon)?></span><span><b><?=cms_e($taskTitle)?></b><small><?=cms_e($taskDescription)?></small></span><span class="task-arrow" aria-hidden="true">↗</span></a>
          <?php endforeach; ?>
        </div>
      </section>

      <div class="stats pro-stats">
        <?php if (cms_section_allowed('registrations') && cms_section_allowed('messages')): ?>
        <a href="?section=registrations" class="stat-card accent"><div class="stat-icon"><?=icon('users')?></div><div><span>Neue Anmeldungen</span><b><?=$newRegs?></b><small><?=count($regs)?> insgesamt</small></div></a>
        <a href="?section=messages" class="stat-card"><div class="stat-icon"><?=icon('mail')?></div><div><span>Neue Nachrichten</span><b><?=$newMsgs?></b><small><?=count($msgs)?> insgesamt</small></div></a>
        <a href="?section=banner" class="stat-card"><div class="stat-icon"><?=icon('banner')?></div><div><span>Aktive Hinweise</span><b><?=$activeBanners?></b><small>Auf der Website sichtbar</small></div></a>
        <a href="?section=pages" class="stat-card"><div class="stat-icon"><?=icon('pages')?></div><div><span>Bearbeitbare Seiten</span><b><?=count($pages)+count($site['customPages']??[])?></b><small>Texte und Inhalte</small></div></a>
        <?php else: ?>
        <a href="?section=homepage" class="stat-card accent"><div class="stat-icon"><?=icon('home')?></div><div><span>Startseite</span><b class="role-stat">Bearbeiten</b><small>Text, Bilder und Schaltflächen</small></div></a>
        <a href="?section=pages" class="stat-card"><div class="stat-icon"><?=icon('pages')?></div><div><span>Seiten</span><b class="role-stat">Texte</b><small>Inhalte mit Vorschau bearbeiten</small></div></a>
        <a href="?section=prices" class="stat-card"><div class="stat-icon"><?=icon('euro')?></div><div><span>Preise</span><b class="role-stat">Ändern</b><small>Preisliste verwalten</small></div></a>
        <a href="?section=summer" class="stat-card"><div class="stat-icon"><?=icon('calendar')?></div><div><span>Kurse</span><b class="role-stat">Termine</b><small>Kurse verwalten</small></div></a>
        <?php endif; ?>
      </div>

      <div class="dashboard-grid">
        <?php if (cms_section_allowed('registrations')): ?>
        <section class="panel span-2">
          <div class="panel-head"><div><span class="eyebrow">AKTUELL</span><h2>Neueste Anmeldungen</h2></div><a class="text-link" href="?section=registrations">Alle anzeigen →</a></div>
          <div class="compact-list">
            <?php foreach (array_slice($regs,0,5) as $r): $rid=(string)($r['request_id']??$r['_dir']??''); $rst=$status['registrations'][$rid]['status']??'Neu'; $phone=(string)($r['telefon']??''); $mail=(string)($r['email']??''); ?>
              <div class="compact-row"><div class="avatar soft"><?=strtoupper(substr((string)($r['vorname']??$r['name']??'K'),0,1))?></div><div class="compact-main"><b><?=cms_e(trim((string)($r['vorname']??'').' '.(string)($r['name']??'')))?></b><span><?=cms_e((string)($r['art_der_anmeldung']??'Online-Anmeldung'))?> · <?=cms_e((string)($r['received_at']??''))?></span></div><span class="badge status-<?=cms_status_key($rst)?>"><?=cms_e($rst)?></span><div class="row-actions"><?php if($phone):?><a href="tel:<?=cms_e($phone)?>" title="Anrufen">☎</a><?php endif;?><?php if($phone):?><a target="_blank" href="https://wa.me/<?=cms_digits($phone)?>" title="WhatsApp">WA</a><?php endif;?><?php if($mail):?><a href="mailto:<?=cms_e($mail)?>" title="E-Mail">✉</a><?php endif;?></div></div>
            <?php endforeach; ?>
            <?php if (!$regs): ?><div class="empty-state"><b>Noch keine Anmeldungen</b><span>Neue Online-Anmeldungen erscheinen automatisch hier.</span></div><?php endif; ?>
          </div>
        </section>
        <?php endif; ?>

        <section class="panel">
          <div class="panel-head"><div><span class="eyebrow">STATUS</span><h2>Website und Formulare</h2></div></div>
          <div class="health-list">
            <div><span class="status-dot <?=$websiteReady?'online':'warn'?>"></span><span><b>Website-Dateien</b><small><?=$websiteReady?'index.html vorhanden':'index.html fehlt'?></small></span></div>
            <div><span class="status-dot <?=$formsReady?'online':'warn'?>"></span><span><b>Formulare</b><small><?=$formsReady?'Anmeldung & Kontakt bereit':'Formular-Skripte prüfen'?></small></span></div>
            <div><span class="status-dot <?=$sslActive?'online':'neutral'?>"></span><span><b>HTTPS / SSL</b><small><?=$sslActive?'Aktive HTTPS-Sitzung':'Nach Domain-Transfer prüfen'?></small></span></div>
          </div>
        </section>

        <section class="panel">
          <div class="panel-head"><div><span class="eyebrow">SCHNELLZUGRIFF</span><h2>Was möchten Sie bearbeiten?</h2></div></div>
          <div class="quick-grid">
            <a href="?section=prices"><?=icon('euro')?><span><b>Preise</b><small>Preisliste bearbeiten</small></span></a>
            <a href="?section=summer"><?=icon('calendar')?><span><b>Kurse</b><small>Termine und Sichtbarkeit</small></span></a>
            <a href="?section=banner"><?=icon('banner')?><span><b>Hinweis</b><small>Mitteilung veröffentlichen</small></span></a>
            <a href="?section=pages"><?=icon('pages')?><span><b>Seiten und Texte</b><small>Inhalte bearbeiten</small></span></a>
          </div>
        </section>

        <?php if ($isOwner): ?><section class="panel">
          <div class="panel-head"><div><span class="eyebrow">PROTOKOLL</span><h2>Letzte Änderungen</h2></div></div>
          <div class="activity-list">
            <?php foreach($activities as $a): ?><div class="activity-row"><span class="activity-dot"></span><div><b><?=cms_e((string)($a['action']??''))?></b><small><?=cms_e((string)($a['detail']??''))?><?=!empty($a['detail'])?' · ':''?><?=cms_e((string)($a['user']??''))?></small></div><time><?=cms_e(substr((string)($a['time']??''),0,16))?></time></div><?php endforeach; ?>
            <?php if(!$activities):?><div class="empty-state small-empty"><b>Noch keine Änderungen</b><span>Alle Änderungen werden hier protokolliert.</span></div><?php endif; ?>
          </div>
        </section>
        <?php endif; ?>
      </div>

    <?php elseif ($section === 'analytics'): require __DIR__ . '/analytics-panel.php'; ?>
    <?php elseif ($section === 'homepage'): $h=$site['homepage']??[]; ?>
      <div class="page-heading"><div><span class="eyebrow">WEBSITE</span><h1>Startseite</h1><p>Hauptüberschrift, Bilder und die wichtigsten Schaltflächen bearbeiten.</p></div><a class="btn ghost" target="_blank" href="../index.html?preview=<?=time()?>">Startseite prüfen ↗</a></div>
      <section class="panel form-panel">
        <div class="info-strip"><b>Einfach erklärt:</b> Hier bearbeiten Sie den ersten Bereich, den Besucher sehen.</div>
        <?php form_start('homepage','homepage'); ?>
        <div class="grid2"><label>Kleine Überschrift<input name="eyebrow" value="<?=cms_e((string)($h['eyebrow']??''))?>"></label><label>Hauptüberschrift<input name="title" value="<?=cms_e((string)($h['title']??''))?>"></label></div>
        <label>Orange Überschrift<input name="accent" value="<?=cms_e((string)($h['accent']??''))?>"></label>
        <div class="grid2"><label>Hauptbutton – Text<input name="primary_text" value="<?=cms_e((string)($h['primary_text']??''))?>"></label><label>Hauptbutton – Link<input name="primary_link" value="<?=cms_e((string)($h['primary_link']??''))?>"></label><label>Zweiter Button – Text<input name="secondary_text" value="<?=cms_e((string)($h['secondary_text']??''))?>"></label><label>Zweiter Button – Link<input name="secondary_link" value="<?=cms_e((string)($h['secondary_link']??''))?>"></label></div>
        <div class="grid2"><label>Hero-Bild Desktop<input name="desktop_image" value="<?=cms_e((string)($h['desktop_image']??''))?>"><small>Bildpfad aus „Medien“ einfügen.</small></label><label>Hero-Bild Mobil<input name="mobile_image" value="<?=cms_e((string)($h['mobile_image']??''))?>"><small>Optional eigenes Hochformat für Smartphones.</small></label></div>
        <div class="sticky-save"><button class="btn primary">Startseite speichern und veröffentlichen</button></div></form>
      </section>

    <?php elseif ($section === 'team'): $team=$site['team']??[]; ?>
      <div class="page-heading"><div><span class="eyebrow">WEBSITE</span><h1>Team</h1><p>Fahrlehrer, Beschreibungen und Fotos verwalten.</p></div><a class="btn ghost" target="_blank" href="../fahrschule.html?preview=<?=time()?>">Team prüfen ↗</a></div>
      <section class="panel form-panel"><div class="info-strip"><b>Einfach erklärt:</b> Jede Karte entspricht einem Fahrlehrer auf der Seite „Fahrschule“.</div><?php form_start('team','team'); ?><div class="admin-card-list">
      <?php foreach($team as $i=>$member): ?><fieldset class="admin-edit-card"><legend>Fahrlehrer <?=$i+1?></legend><label class="toggle-row"><span><b>Auf der Website anzeigen</b></span><input type="checkbox" name="team[<?=$i?>][active]" <?=!empty($member['active'])?'checked':''?>></label><div class="grid2"><label>Name<input name="team[<?=$i?>][name]" value="<?=cms_e((string)($member['name']??''))?>"></label><label>Rolle<input name="team[<?=$i?>][role]" value="<?=cms_e((string)($member['role']??''))?>"></label><label>Führerscheinklassen<input name="team[<?=$i?>][classes]" value="<?=cms_e((string)($member['classes']??''))?>"></label><label>Kurzsatz<input name="team[<?=$i?>][tagline]" value="<?=cms_e((string)($member['tagline']??''))?>"></label></div><label>Beschreibung 1<textarea name="team[<?=$i?>][description_1]" rows="5"><?=cms_e((string)($member['description_1']??''))?></textarea></label><label>Beschreibung 2<textarea name="team[<?=$i?>][description_2]" rows="5"><?=cms_e((string)($member['description_2']??''))?></textarea></label><label>Foto<input name="team[<?=$i?>][image]" value="<?=cms_e((string)($member['image']??''))?>"><small>Bildpfad aus „Medien“ einfügen.</small></label></fieldset><?php endforeach; $newTeamIndex=count($team); ?>
      <fieldset class="admin-edit-card"><legend>Neuen Fahrlehrer hinzufügen</legend><label class="toggle-row"><span><b>Nach dem Speichern anzeigen</b></span><input type="checkbox" name="team[<?=$newTeamIndex?>][active]" checked></label><div class="grid2"><label>Name<input name="team[<?=$newTeamIndex?>][name]" placeholder="Name eingeben"></label><label>Rolle<input name="team[<?=$newTeamIndex?>][role]" placeholder="z. B. Fahrlehrer"></label><label>Führerscheinklassen<input name="team[<?=$newTeamIndex?>][classes]"></label><label>Kurzsatz<input name="team[<?=$newTeamIndex?>][tagline]"></label></div><label>Beschreibung 1<textarea name="team[<?=$newTeamIndex?>][description_1]" rows="4"></textarea></label><label>Beschreibung 2<textarea name="team[<?=$newTeamIndex?>][description_2]" rows="4"></textarea></label><label>Foto<input name="team[<?=$newTeamIndex?>][image]" placeholder="assets/uploads/..."></label></fieldset>
      </div><div class="sticky-save"><button class="btn primary">Team speichern und veröffentlichen</button></div></form></section>

    <?php elseif ($section === 'gallery'): require __DIR__ . '/page-editor.php'; ?>

    <?php elseif ($section === 'forms'): $fo=$site['forms']??[];$st=$site['settings']??[];$mc=cms_mail_config(); ?>
      <div class="page-heading"><div><span class="eyebrow">KUNDEN UND E-MAIL</span><h1>Formulare und E-Mail</h1><p>Festlegen, welche Formulare aktiv sind und wohin Benachrichtigungen gesendet werden.</p></div></div>
      <section class="panel form-panel"><div class="info-strip"><b>Wichtig:</b> Auch wenn eine E-Mail nicht zugestellt wird, bleibt die Anfrage geschützt im Admin Center gespeichert.</div><?php form_start('forms','forms'); ?><div class="grid2"><label class="toggle-row"><span><b>Online-Anmeldung aktiv</b><small>Formular auf „Online anmelden“ annehmen.</small></span><input type="checkbox" name="registration_enabled" <?=!isset($fo['registration_enabled'])||!empty($fo['registration_enabled'])?'checked':''?>></label><label class="toggle-row"><span><b>Kontaktformular aktiv</b><small>Nachrichten über die Kontaktseite annehmen.</small></span><input type="checkbox" name="contact_enabled" <?=!isset($fo['contact_enabled'])||!empty($fo['contact_enabled'])?'checked':''?>></label></div><div class="grid2"><label>Benachrichtigungs-E-Mail<input type="email" name="notification_email" value="<?=cms_e((string)($st['notification_email']??''))?>"></label><label>Dokumente aufbewahren (Tage)<input type="number" min="1" max="365" name="retention_days" value="<?=cms_e((string)($st['retention_days']??30))?>"></label><label>Maximale Upload-Größe gesamt (MB)<input type="number" min="1" max="25" name="max_upload_mb" value="<?=cms_e((string)($fo['max_upload_mb']??8))?>"></label><label>Zeitzone<input name="timezone" value="<?=cms_e((string)($st['timezone']??'Europe/Berlin'))?>"></label></div><label>Hinweis bei ausgeschalteter Anmeldung<textarea name="registration_notice" rows="3"><?=cms_e((string)($fo['registration_notice']??''))?></textarea></label><label>Hinweis bei ausgeschaltetem Kontaktformular<textarea name="contact_notice" rows="3"><?=cms_e((string)($fo['contact_notice']??''))?></textarea></label><button class="btn primary">Formulareinstellungen speichern</button></form></section>

      <section class="panel form-panel"><div class="panel-head"><div><span class="eyebrow">GOOGLE WORKSPACE</span><h2>E-Mail-Versand ohne Spam</h2></div><span class="badge <?=!empty($mc['enabled'])&&!empty($mc['app_password'])?'status-erledigt':'status-neutral'?>"><?=!empty($mc['enabled'])&&!empty($mc['app_password'])?'Eingerichtet':'Nicht eingerichtet'?></span></div><div class="info-strip"><b>Sicher:</b> Das Google-App-Passwort wird getrennt in <code>private_admin/mail.json</code> gespeichert und niemals öffentlich ausgegeben.</div><?php form_start('smtp','forms');?><label class="toggle-row"><span><b>Google SMTP aktivieren</b><small>Nachrichten authentifiziert über Google Workspace senden.</small></span><input type="checkbox" name="enabled" <?=!empty($mc['enabled'])?'checked':''?>></label><div class="grid2"><label>SMTP-Server<input name="host" value="<?=cms_e((string)($mc['host']??'smtp.gmail.com'))?>"></label><label>Port<input type="number" name="port" value="<?=cms_e((string)($mc['port']??587))?>"></label><label>Google-Workspace-E-Mail<input type="email" name="username" value="<?=cms_e((string)($mc['username']??'info@fahrschule-bv.com'))?>"></label><label>Google App-Passwort<input type="password" name="app_password" autocomplete="new-password" placeholder="<?=!empty($mc['app_password'])?'Bereits gespeichert – leer lassen':'16-stelliges App-Passwort einfügen'?>"><small>Leer lassen, um ein bereits gespeichertes Passwort zu behalten.</small></label></div><div class="form-actions"><button class="btn primary">SMTP speichern</button><button class="btn ghost" name="send_test" value="1">Speichern & Test senden</button></div></form></section>

    <?php elseif ($section === 'registrations'): ?>
      <div class="page-heading"><div><span class="eyebrow">KUNDEN</span><h1>Online-Anmeldungen</h1><p>Kundendaten, Dokumente und Bearbeitungsstatus verwalten.</p></div><div class="heading-badge"><?=$newRegs?> neu</div></div>
      <section class="toolbar panel"><div class="searchbox"><span>⌕</span><input type="search" placeholder="Name, E-Mail, Telefon oder Klasse suchen…" data-list-search="registrations"></div><select data-list-filter="registrations"><option value="">Alle Status</option><option>Neu</option><option>Kontaktiert</option><option>In Bearbeitung</option><option>Erledigt</option></select></section>
      <div class="list" data-list="registrations">
      <?php foreach ($regs as $r): $id=$r['request_id']??$r['_dir']; $st=$status['registrations'][$id]??['status'=>'Neu','note'=>'']; $name=trim((string)($r['vorname']??'').' '.(string)($r['name']??'')); $phone=(string)($r['telefon']??''); $email=(string)($r['email']??''); $search=strtolower($name.' '.$phone.' '.$email.' '.($r['art_der_anmeldung']??'').' '.($r['adresse']??'')); ?>
        <article class="item customer-card" data-item data-search="<?=cms_e($search)?>" data-status="<?=cms_e((string)$st['status'])?>">
          <div class="customer-top"><div class="customer-id"><div class="avatar large"><?=strtoupper(substr($name?:'K',0,1))?></div><div><h2><?=cms_e($name?:'Ohne Namen')?></h2><span><?=cms_e((string)($r['art_der_anmeldung']??'Online-Anmeldung'))?> · <?=cms_e((string)($r['received_at']??''))?></span></div></div><span class="badge status-<?=cms_status_key((string)$st['status'])?>"><?=cms_e((string)$st['status'])?></span></div>
          <div class="contact-actions"><?php if($phone):?><a class="action-pill" href="tel:<?=cms_e($phone)?>">☎ Anrufen</a><a class="action-pill whatsapp" target="_blank" href="https://wa.me/<?=cms_digits($phone)?>">WhatsApp</a><?php endif;?><?php if($email):?><a class="action-pill" href="mailto:<?=cms_e($email)?>">✉ E-Mail</a><?php endif;?></div>
          <div class="detail-grid"><div><small>Telefon</small><b><?=cms_e($phone?:'—')?></b></div><div><small>E-Mail</small><b><?=cms_e($email?:'—')?></b></div><div><small>Geburtsdatum</small><b><?=cms_e((string)($r['geburtsdatum']??'—'))?></b></div><div><small>Adresse</small><b><?=cms_e((string)($r['adresse']??'—'))?></b></div></div>
          <?php if (!empty($r['documents'])): ?><div class="documents"><small>DOKUMENTE</small><div><?php foreach($r['documents'] as $label=>$file):?><a target="_blank" href="file.php?r=<?=rawurlencode((string)$r['_dir'])?>&f=<?=rawurlencode((string)$file)?>">📎 <?=cms_e((string)$label)?></a><?php endforeach;?></div></div><?php endif; ?>
          <div class="card-form"><?php form_start('status','registrations');?><input type="hidden" name="kind" value="registrations"><input type="hidden" name="id" value="<?=cms_e((string)$id)?>"><div class="grid2"><label>Status<select name="status"><?php foreach(['Neu','Kontaktiert','In Bearbeitung','Erledigt'] as $x):?><option <?=$st['status']===$x?'selected':''?>><?=$x?></option><?php endforeach;?></select></label><label>Interne Notiz<input name="note" value="<?=cms_e((string)($st['note']??''))?>" placeholder="z. B. Rückruf vereinbart…"></label></div><div class="form-actions"><button class="btn primary">Änderungen speichern</button></div></form><?php if($isOwner):?><?php form_start('delete_registration','registrations');?><input type="hidden" name="id" value="<?=cms_e((string)$id)?>"><button class="btn danger" onclick="return confirm('Diese Anmeldung wirklich löschen?')">Löschen</button></form><?php endif;?></div>
        </article>
      <?php endforeach; ?>
      <?php if(!$regs):?><div class="empty-state panel"><b>Noch keine Anmeldungen</b><span>Sobald sich jemand online anmeldet, erscheint die Anfrage hier.</span></div><?php endif; ?>
      </div>

    <?php elseif ($section === 'messages'): ?>
      <div class="page-heading"><div><span class="eyebrow">KUNDEN</span><h1>Nachrichten</h1><p>Nachrichten aus dem Kontaktformular ansehen und bearbeiten.</p></div><div class="heading-badge"><?=$newMsgs?> neu</div></div>
      <section class="toolbar panel"><div class="searchbox"><span>⌕</span><input type="search" placeholder="Name, E-Mail oder Nachricht suchen…" data-list-search="messages"></div><select data-list-filter="messages"><option value="">Alle Status</option><option>Neu</option><option>Kontaktiert</option><option>Erledigt</option></select></section>
      <div class="list" data-list="messages">
      <?php foreach($msgs as $r): $id=$r['message_id']??$r['_file']; $st=$status['messages'][$id]??['status'=>'Neu','note'=>'']; $name=trim((string)($r['first_name']??'').' '.(string)($r['last_name']??'')); $email=(string)($r['email']??''); $search=strtolower($name.' '.$email.' '.($r['message']??'')); ?>
        <article class="item customer-card" data-item data-search="<?=cms_e($search)?>" data-status="<?=cms_e((string)$st['status'])?>"><div class="customer-top"><div class="customer-id"><div class="avatar large"><?=strtoupper(substr($name?:'N',0,1))?></div><div><h2><?=cms_e($name?:'Kontaktanfrage')?></h2><span><?=cms_e($email)?> · <?=cms_e((string)($r['received_at']??''))?></span></div></div><span class="badge status-<?=cms_status_key((string)$st['status'])?>"><?=cms_e((string)$st['status'])?></span></div>
        <?php if($email):?><div class="contact-actions"><a class="action-pill" href="mailto:<?=cms_e($email)?>">✉ E-Mail schreiben</a></div><?php endif; ?>
        <div class="message-box"><?=nl2br(cms_e((string)($r['message']??'')))?></div>
        <div class="card-form"><?php form_start('status','messages');?><input type="hidden" name="kind" value="messages"><input type="hidden" name="id" value="<?=cms_e((string)$id)?>"><div class="grid2"><label>Status<select name="status"><?php foreach(['Neu','Kontaktiert','Erledigt'] as $x):?><option <?=$st['status']===$x?'selected':''?>><?=$x?></option><?php endforeach;?></select></label><label>Interne Notiz<input name="note" value="<?=cms_e((string)($st['note']??''))?>" placeholder="Nur intern sichtbar"></label></div><div class="form-actions"><button class="btn primary">Änderungen speichern</button></div></form><?php if($isOwner):?><?php form_start('delete_message','messages');?><input type="hidden" name="id" value="<?=cms_e((string)$r['_file'])?>"><button class="btn danger" onclick="return confirm('Diese Nachricht wirklich löschen?')">Löschen</button></form><?php endif;?></div></article>
      <?php endforeach; ?>
      <?php if(!$msgs):?><div class="empty-state panel"><b>Noch keine Nachrichten</b><span>Kontaktanfragen erscheinen automatisch hier.</span></div><?php endif; ?>
      </div>

    <?php elseif ($section === 'pages'): require __DIR__ . '/page-editor.php'; ?>
<details class="panel advanced-box"><summary>Erweitert: eigene Seiten verwalten</summary><div><details class="panel advanced-box create-page"><summary>Neue eigene Seite erstellen</summary><div><?php form_start('custom_page_add','pages');?><div class="grid2"><label>Titel<input name="title" required></label><label>URL / Slug<input name="slug" placeholder="z. B. erste-hilfe"></label><label>Menüname<input name="menu_label"></label><label class="check"><input type="checkbox" name="active" checked> Aktiv</label><label>SEO Titel<input name="seo_title"></label><label>SEO Beschreibung<input name="seo_desc"></label></div><button class="btn primary">Seite erstellen</button></form></div></details>
      <?php foreach($site['customPages']??[] as $p):?><details class="panel advanced-box custom-page-manager"><summary><?=cms_e((string)$p['title'])?> · /seite/<?=cms_e((string)$p['slug'])?></summary><div><div class="inline-actions"><a class="btn ghost smallbtn" target="_blank" href="../seite/<?=rawurlencode((string)$p['slug'])?>">Seite ansehen ↗</a></div><?php form_start('custom_page_update','pages');?><input type="hidden" name="id" value="<?=cms_e((string)$p['id'])?>"><div class="grid2"><label>Titel<input name="title" value="<?=cms_e((string)$p['title'])?>"></label><label>Menüname<input name="menu_label" value="<?=cms_e((string)($p['menu_label']??''))?>"></label><label>SEO Titel<input name="seo_title" value="<?=cms_e((string)($p['seo_title']??''))?>"></label><label>SEO Beschreibung<input name="seo_desc" value="<?=cms_e((string)($p['seo_desc']??''))?>"></label><label class="check"><input type="checkbox" name="active" <?=!empty($p['active'])?'checked':''?>> Aktiv</label></div><button class="btn primary smallbtn">Seitendaten speichern</button></form><hr><h3>Inhalt hinzufügen</h3><?php form_start('custom_block_add','pages');?><input type="hidden" name="page_id" value="<?=cms_e((string)$p['id'])?>"><?php block_fields();?><button class="btn primary smallbtn">Element hinzufügen</button></form><div class="simple-list"><?php foreach($p['blocks']??[] as $b):?><div class="mini"><div><b><?=cms_e((string)((($b['title']??'')!=='')?$b['title']:($b['type']??'Element'))) ?></b><span><?=cms_e((string)($b['type']??''))?></span></div><?php form_start('custom_block_delete','pages');?><input type="hidden" name="page_id" value="<?=cms_e((string)$p['id'])?>"><input type="hidden" name="block_id" value="<?=cms_e((string)$b['id'])?>"><button class="btn danger smallbtn">Element löschen</button></form></div><?php endforeach;?></div><?php form_start('custom_page_delete','pages');?><input type="hidden" name="id" value="<?=cms_e((string)$p['id'])?>"><button class="btn danger smallbtn" onclick="return confirm('Eigene Seite wirklich löschen?')">Gesamte Seite löschen</button></form></div></details><?php endforeach;?>

    </div></details>

    <?php elseif ($section === 'prices'): ?>
      <div class="page-heading"><div><span class="eyebrow">WEBSITE</span><h1>Preise</h1><p>Alle Fahrschulpreise an einer zentralen Stelle bearbeiten.</p></div><a class="btn ghost" target="_blank" href="../preisliste.html?preview=<?=time()?>">Preise prüfen ↗</a></div>
      <section class="panel"><div class="info-strip"><b>Wichtig:</b> Derselbe Wert erscheint automatisch in der Desktop-Tabelle und in den mobilen Preiskarten.</div><?php form_start('prices','prices');?><div class="price-admin"><?php foreach($site['prices'] as $cl=>$vals):?><fieldset><legend>Klasse <?=cms_e((string)$cl)?></legend><?php foreach($vals as $k=>$v):?><label><?=cms_e((string)$k)?><input name="price[<?=cms_e((string)$cl)?>][<?=cms_e((string)$k)?>]" value="<?=cms_e((string)$v)?>"></label><?php endforeach;?></fieldset><?php endforeach;?></div><div class="sticky-save"><button class="btn primary">Alle Preise speichern und veröffentlichen</button></div></form></section>

    <?php elseif ($section === 'summer'): $s=$site['summerCourse']??[]; $courses=$s['courses']??[]; ?>
      <div class="page-heading"><div><span class="eyebrow">STARTSEITE</span><h1>Kurse und Termine</h1><p>Steuern Sie, ob der Bereich auf der Website erscheint und welche Kurse angezeigt werden.</p></div><a class="btn ghost" target="_blank" href="../index.html?preview=<?=time()?>#summer-course-block">Auf der Website prüfen ↗</a></div>
      <section class="panel visibility-panel <?=!empty($s['enabled'])?'is-visible':'is-hidden'?>">
        <div class="visibility-copy"><span class="status-dot <?=!empty($s['enabled'])?'online':'neutral'?>"></span><div><b>Der Bereich ist auf der Website <?=!empty($s['enabled'])?'sichtbar':'ausgeblendet'?></b><small><?=!empty($s['enabled'])?'Besucher können die unten aufgeführten Kurse sehen.':'Der Kursbereich erscheint nicht auf der Startseite.'?></small></div></div>
        <?php if(!empty($s['enabled'])):?><?php form_start('summer_hide','summer');?><button class="btn danger" onclick="return confirm('Den gesamten Kursbereich ausblenden? Die Kursdaten bleiben gespeichert.')">Bereich ausblenden</button></form><?php endif;?>
      </section>
      <section class="panel form-panel">
        <div class="info-strip"><b>So funktioniert es:</b> Schalter aktivieren, mindestens einen Kurs ausfüllen und „Speichern und veröffentlichen“ wählen. Wenn alle Kurse gelöscht werden, wird der Bereich automatisch ausgeblendet.</div>
        <?php form_start('summer','summer');?>
        <label class="toggle-row"><span><b>Bereich auf der Startseite anzeigen</b><small>Kann ausgeschaltet werden, ohne Kursdaten zu verlieren.</small></span><input type="checkbox" name="enabled" <?=!empty($s['enabled'])?'checked':''?>></label>
        <div class="grid2"><label>Kleine Überschrift<input name="label" value="<?=cms_e((string)($s['label']??'Theorieunterricht'))?>" placeholder="Theorieunterricht"></label><label>Bereichsüberschrift<input name="title" value="<?=cms_e((string)($s['title']??''))?>" placeholder="z. B. Sommerferien 2026"></label></div>
        <div class="course-editor-head"><div><span class="eyebrow">ANGEZEIGTE KURSE</span><h2>Kursliste</h2></div><button class="btn ghost smallbtn" type="button" data-add-course>＋ Kurs hinzufügen</button></div>
        <div class="course-grid course-editor" data-course-list data-next-index="<?=count($courses)?>">
          <?php foreach($courses as $i=>$c):?>
          <article class="course-card" data-course-card><div class="course-card-title"><span>KURS <?=$i+1?></span><button type="button" class="remove-course" data-remove-course>Entfernen</button></div>
            <label class="check"><input type="checkbox" name="courses[<?=$i?>][active]" <?=!isset($c['active'])||!empty($c['active'])?'checked':''?>> Kurs sichtbar</label>
            <label>Bezeichnung<input name="courses[<?=$i?>][label]" value="<?=cms_e((string)($c['label']??''))?>" placeholder="z. B. 1. Kurs"></label>
            <label>Datum<input name="courses[<?=$i?>][date]" value="<?=cms_e((string)($c['date']??''))?>" placeholder="z. B. 03.08.–11.08.2026"></label>
            <label>Uhrzeit<input name="courses[<?=$i?>][time]" value="<?=cms_e((string)($c['time']??''))?>" placeholder="täglich · 9:00–12:00 Uhr"></label>
            <input type="hidden" name="courses[<?=$i?>][remove]" value="0" data-remove-value>
          </article>
          <?php endforeach;?>
        </div>
        <div class="empty-course-note" data-course-empty <?=!empty($courses)?'hidden':''?>>Keine Kurse vorhanden. Fügen Sie einen Kurs hinzu oder lassen Sie den Bereich ausgeblendet.</div>
        <div class="grid2"><label>Schaltflächentext<input name="buttonText" value="<?=cms_e((string)($s['buttonText']??'Jetzt online anmelden'))?>"></label><label>Ziel der Schaltfläche<input name="buttonLink" value="<?=cms_e((string)($s['buttonLink']??'anmeldung.html'))?>"></label></div>
        <div class="form-actions split-actions"><button class="btn primary">Speichern und veröffentlichen</button></div></form>
      </section>
      <section class="panel danger-zone"><div><b>Vollständig löschen</b><p>Alle Kurse löschen und den Bereich auf der Website ausblenden. Diese Aktion kann im Admin Center nicht rückgängig gemacht werden.</p></div><?php form_start('summer_clear','summer');?><button class="btn danger" onclick="return confirm('Wirklich alle Kurse löschen und den Bereich ausblenden?')">Alle Kurse löschen</button></form></section>

    <?php elseif ($section === 'banner'): ?>
      <div class="page-heading"><div><span class="eyebrow">WEBSITE</span><h1>Banner</h1><p>Wichtige Hinweise zeitgesteuert auf der Website anzeigen.</p></div><div class="heading-badge"><?=$activeBanners?> aktiv</div></div>
      <div class="two-col"><section class="panel form-panel"><div class="panel-head"><div><span class="eyebrow">NEU</span><h2>Banner erstellen</h2></div></div><?php form_start('banner_add','banner');?><div class="grid2"><label class="check"><input type="checkbox" name="active" checked> Sofort aktiv</label><label>Position<select name="position"><option value="after-hero">Nach dem Hero</option><option value="before-hero">Vor dem Hero</option></select></label></div><label>Titel<input name="title" required placeholder="z. B. Kein Theorieunterricht am Dienstag"></label><label>Text<textarea name="text" rows="4"></textarea></label><div class="grid2"><label>Bild-URL<input name="image" placeholder="assets/uploads/..."></label><label>Button-Text<input name="buttonText"></label><label>Button-Link<input name="buttonLink"></label><span></span><label>Startdatum<input type="date" name="start"></label><label>Enddatum<input type="date" name="end"></label></div><button class="btn primary">Banner veröffentlichen</button></form></section><section><div class="list"><?php foreach($site['banners']??[] as $b):?><article class="item banner-item banner-editor"><div class="panel-head"><div><span class="badge <?=$b['active']?'status-erledigt':'status-neutral'?>"><?=$b['active']?'Aktiv':'Inaktiv'?></span><h3><?=cms_e((string)($b['title']??''))?></h3></div></div><?php form_start('banner_update','banner');?><input type="hidden" name="id" value="<?=cms_e((string)$b['id'])?>"><label class="check"><input type="checkbox" name="active" <?=!empty($b['active'])?'checked':''?>> Aktiv</label><label>Titel<input name="title" value="<?=cms_e((string)($b['title']??''))?>"></label><label>Text<textarea name="text" rows="3"><?=cms_e((string)($b['text']??''))?></textarea></label><div class="grid2"><label>Bild<input name="image" value="<?=cms_e((string)($b['image']??''))?>"></label><label>Position<select name="position"><option value="after-hero" <?=($b['position']??'')==='after-hero'?'selected':''?>>Nach dem Hero</option><option value="before-hero" <?=($b['position']??'')==='before-hero'?'selected':''?>>Vor dem Hero</option></select></label><label>Button-Text<input name="buttonText" value="<?=cms_e((string)($b['buttonText']??''))?>"></label><label>Button-Link<input name="buttonLink" value="<?=cms_e((string)($b['buttonLink']??''))?>"></label><label>Startdatum<input type="date" name="start" value="<?=cms_e((string)($b['start']??''))?>"></label><label>Enddatum<input type="date" name="end" value="<?=cms_e((string)($b['end']??''))?>"></label></div><button class="btn primary smallbtn">Änderungen speichern</button></form><?php form_start('banner_delete','banner');?><input type="hidden" name="id" value="<?=cms_e((string)$b['id'])?>"><button class="btn danger smallbtn" onclick="return confirm('Banner wirklich löschen?')">Banner löschen</button></form></article><?php endforeach;?><?php if(empty($site['banners'])):?><div class="empty-state panel"><b>Keine Banner vorhanden</b><span>Erstellen Sie links einen neuen Website-Hinweis.</span></div><?php endif;?></div></section></div>

    <?php elseif ($section === 'media'): ?>
      <div class="page-heading"><div><span class="eyebrow">WEBSITE</span><h1>Medien</h1><p>Bilder hochladen und Pfade mit einem Klick kopieren.</p></div></div>
      <section class="panel upload-panel"><form method="post" action="media-upload.php" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=cms_e(cms_csrf())?>"><label class="dropzone"><span class="upload-icon">↑</span><b>Bild hochladen</b><small>JPG, PNG oder WEBP · maximal 8 MB</small><input type="file" name="media" accept="image/jpeg,image/png,image/webp" required></label><button class="btn primary">Hochladen</button></form></section>
      <div class="media-grid"><?php foreach(array_reverse(glob(__DIR__.'/../assets/uploads/*')?:[]) as $f):$path='assets/uploads/'.basename($f);?><figure><img src="../assets/uploads/<?=rawurlencode(basename($f))?>"><figcaption><span><?=cms_e(basename($f))?></span><div class="inline-actions"><button class="btn ghost smallbtn" type="button" data-copy="<?=cms_e($path)?>">Pfad kopieren</button><?php form_start('media_delete','media');?><input type="hidden" name="name" value="<?=cms_e(basename($f))?>"><button class="btn danger smallbtn" onclick="return confirm('Bild wirklich löschen? Es darf nicht mehr auf einer Seite verwendet werden.')">Löschen</button></form></div></figcaption></figure><?php endforeach;?></div>

    <?php elseif ($section === 'website'): $g=$site['general']??[]; ?>
      <div class="page-heading"><div><span class="eyebrow">WEBSITE</span><h1>Kontaktdaten & globale Texte</h1><p>Alles, was auf mehreren Seiten wiederholt wird: Kontakt, Footer, Schnellkontakt und globale Beschriftungen.</p></div></div>
      <section class="panel form-panel"><?php form_start('general','website');?>
        <div class="panel-head"><div><span class="eyebrow">KONTAKT</span><h2>Kontaktdaten</h2></div></div>
        <div class="grid2"><?php foreach(['school_name'=>'Name der Fahrschule','owner'=>'Inhaber','address'=>'Straße','postal_city'=>'PLZ / Ort','phone'=>'Telefon – Anzeige','phone_href'=>'Telefon – technisch (+49...)','mobile'=>'Mobil – Anzeige','mobile_href'=>'Mobil – technisch (+49...)','email'=>'E-Mail','whatsapp'=>'WhatsApp Nummer','office_hours'=>'Bürozeiten','theory_hours'=>'Theoriezeiten'] as $k=>$lab):?><label><?=$lab?><input name="<?=$k?>" value="<?=cms_e((string)($g[$k]??''))?>"></label><?php endforeach;?></div>
        <hr>
        <div class="panel-head"><div><span class="eyebrow">FOOTER</span><h2>Fußzeile auf allen Seiten</h2></div></div>
        <div class="grid2">
          <label>Footer-Slogan<input name="footer_tagline" value="<?=cms_e((string)($g['footer_tagline']??'Deine Fahrschule in Lahr – persönlich, modern und transparent.'))?>"></label>
          <label>Jahr<input name="footer_year" value="<?=cms_e((string)($g['footer_year']??'2026'))?>"></label>
          <label>Bezeichnung Inhaber<input name="footer_owner_label" value="<?=cms_e((string)($g['footer_owner_label']??'Inhaber'))?>"></label>
          <label>Bezeichnung Website-Ersteller<input name="footer_creator_label" value="<?=cms_e((string)($g['footer_creator_label']??'Webdesign & Entwicklung'))?>"></label>
          <label>Name Website-Ersteller<input name="footer_creator_name" value="<?=cms_e((string)($g['footer_creator_name']??'Vladimir Sili'))?>"></label>
          <span></span>
          <label>Überschrift Kontakt<input name="footer_contact_title" value="<?=cms_e((string)($g['footer_contact_title']??'Kontakt'))?>"></label>
          <label>Überschrift Fahrschule<input name="footer_school_title" value="<?=cms_e((string)($g['footer_school_title']??'Fahrschule'))?>"></label>
          <label>Überschrift Formulare<input name="footer_forms_title" value="<?=cms_e((string)($g['footer_forms_title']??'Wichtige Formulare'))?>"></label>
          <label>Überschrift Rechtliches<input name="footer_legal_title" value="<?=cms_e((string)($g['footer_legal_title']??'Rechtliches'))?>"></label>
        </div>
        <details class="advanced-box" open><summary>Footer-Links bearbeiten</summary><div class="footer-link-editor">
          <?php $footerRows=[
            ['footer_licenses','Führerscheinklassen','angebote.html'],['footer_motorcycle','Motorradkurs','motorradkurs.html'],['footer_prices','Preisliste','preisliste.html'],['footer_calendar','Unterrichtskalender','calendar.html'],['footer_registration','Online Anmeldung','anmeldung.html'],
            ['footer_form1','Anmeldeformular.pdf','Anmeldeformular.pdf'],['footer_form2','Führerscheinantrag (Ersterteilung / Erweiterung)','Fuehrerscheinantrag_Ersterteilung_Erweiterung.pdf'],
            ['footer_privacy','Datenschutz','datenschutz.html'],['footer_imprint','Impressum','impressum.html'],['footer_agb','AGB','agb.html'],['footer_cookie','Cookie-Richtlinie','cookie-richtlinie.html']
          ]; foreach($footerRows as [$key,$label,$href]): ?>
            <div class="footer-link-row"><input name="<?=$key?>_label" value="<?=cms_e((string)($g[$key.'_label']??$label))?>"><input name="<?=$key?>_href" value="<?=cms_e((string)($g[$key.'_href']??$href))?>"></div>
          <?php endforeach; ?>
        </div></details>
        <hr>
        <div class="panel-head"><div><span class="eyebrow">SCHNELLKONTAKT</span><h2>Feste Buttons unten</h2></div></div>
        <div class="grid3"><label>WhatsApp Text<input name="dock_whatsapp_label" value="<?=cms_e((string)($g['dock_whatsapp_label']??'WhatsApp'))?>"></label><label>E-Mail Text<input name="dock_email_label" value="<?=cms_e((string)($g['dock_email_label']??'E-Mail'))?>"></label><label>Telefon Text<input name="dock_phone_label" value="<?=cms_e((string)($g['dock_phone_label']??'Telefon'))?>"></label></div>
        <div class="sticky-save"><button class="btn primary">Globale Website-Daten speichern</button></div>
      </form></section>

    <?php elseif ($section === 'seo'): $sp=basename((string)($_GET['page']??'index.html')); $x=$site['seo'][$sp]??['title'=>'','description'=>'','index'=>true]; ?>
      <div class="page-heading"><div><span class="eyebrow">MARKETING</span><h1>SEO</h1><p>Seitentitel und Google-Beschreibungen kontrollieren.</p></div></div>
      <div class="two-col seo-layout"><section class="panel"><form method="get"><input type="hidden" name="section" value="seo"><label>Seite<select name="page" onchange="this.form.submit()"><?php foreach($pages as $f=>$title):?><option value="<?=cms_e($f)?>" <?=$sp===$f?'selected':''?>><?=cms_e($title)?></option><?php endforeach;?></select></label></form><?php form_start('seo','seo');?><input type="hidden" name="page" value="<?=cms_e($sp)?>"><label>SEO-Titel<input name="title" value="<?=cms_e((string)$x['title'])?>" maxlength="70"></label><label>Meta Description<textarea name="description" rows="5" maxlength="180"><?=cms_e((string)$x['description'])?></textarea></label><label class="check"><input type="checkbox" name="index" <?=!empty($x['index'])?'checked':''?>> Suchmaschinen dürfen diese Seite indexieren</label><button class="btn primary">SEO speichern</button></form></section><section class="panel search-preview"><span class="eyebrow">GOOGLE-VORSCHAU</span><div class="google-card"><small>fahrschule-bv.com › <?=cms_e(pathinfo($sp,PATHINFO_FILENAME))?></small><h3><?=cms_e((string)($x['title']?:($pages[$sp]??'Fahrschule BV')))?></h3><p><?=cms_e((string)($x['description']?:'Beschreibung für diese Seite festlegen.'))?></p></div></section></div>

    <?php elseif ($section === 'navigation'): ?>
      <div class="page-heading"><div><span class="eyebrow">SYSTEM</span><h1>Navigation</h1><p>Menünamen, Links und sichtbare Einträge verwalten.</p></div></div>
      <section class="panel"><div class="info-strip"><b>Reihenfolge:</b> Die Menüeinträge erscheinen in derselben Reihenfolge wie hier. Leere neue Zeile wird ignoriert.</div><div class="nav-table-head"><span>Bezeichnung</span><span>Link</span><span>Sichtbar / Button / Löschen</span></div><?php form_start('navigation','navigation');?><div id="navRows"><?php foreach($site['navigation']??[] as $i=>$n):?><div class="navrow"><input name="label[<?=$i?>]" value="<?=cms_e((string)$n['label'])?>"><input name="href[<?=$i?>]" value="<?=cms_e((string)$n['href'])?>"><div class="inline-checks"><label class="check compact-check"><input type="checkbox" name="enabled[<?=$i?>]" <?=!empty($n['enabled'])?'checked':''?>> Aktiv</label><label class="check compact-check"><input type="checkbox" name="button[<?=$i?>]" <?=!empty($n['button'])?'checked':''?>> CTA</label><label class="check compact-check danger-check"><input type="checkbox" name="remove[<?=$i?>]"> Löschen</label></div></div><?php endforeach;$newNavIndex=count($site['navigation']??[]);?><div class="navrow navrow-new"><input name="label[<?=$newNavIndex?>]" placeholder="Neuer Menüname"><input name="href[<?=$newNavIndex?>]" placeholder="seite.html oder https://..."><div class="inline-checks"><label class="check compact-check"><input type="checkbox" name="enabled[<?=$newNavIndex?>]" checked> Aktiv</label><label class="check compact-check"><input type="checkbox" name="button[<?=$newNavIndex?>]"> CTA</label></div></div></div><button class="btn primary">Navigation speichern</button></form></section>

    <?php elseif ($section === 'design'): $t=$site['theme']??[]; ?>
      <div class="page-heading"><div><span class="eyebrow">SYSTEM</span><h1>Design</h1><p>Globale Farben und Typografie der Website einstellen.</p></div></div>
      <section class="panel form-panel"><?php form_start('theme','design');?><div class="theme-grid"><label class="color-field">Hauptfarbe<div><input type="color" name="orange" value="<?=cms_e((string)($t['orange']??'#f47a20'))?>"><span><?=cms_e((string)($t['orange']??'#f47a20'))?></span></div></label><label class="color-field">Akzent<div><input type="color" name="orange2" value="<?=cms_e((string)($t['orange2']??'#ff9a45'))?>"><span><?=cms_e((string)($t['orange2']??'#ff9a45'))?></span></div></label><label class="color-field">Hintergrund<div><input type="color" name="black" value="<?=cms_e((string)($t['black']??'#09090a'))?>"><span><?=cms_e((string)($t['black']??'#09090a'))?></span></div></label><label class="color-field">Text<div><input type="color" name="text" value="<?=cms_e((string)($t['text']??'#f7f7f8'))?>"><span><?=cms_e((string)($t['text']??'#f7f7f8'))?></span></div></label></div><div class="grid2"><label>Schrift<select name="font"><?php foreach(['Inter, ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'=>'Inter / System','Arial, sans-serif'=>'Arial','Verdana, sans-serif'=>'Verdana','Trebuchet MS, sans-serif'=>'Trebuchet','Georgia, serif'=>'Georgia'] as $v=>$n):?><option value="<?=cms_e($v)?>" <?=($t['font']??'')===$v?'selected':''?>><?=$n?></option><?php endforeach;?></select></label><label>Basisgröße<input type="number" min="14" max="20" name="base_size" value="<?=cms_e((string)($t['base_size']??'16'))?>"></label></div><button class="btn primary">Design speichern</button></form></section>

    <?php elseif ($section === 'users'): ?>
      <div class="page-heading"><div><span class="eyebrow">SYSTEM</span><h1>Benutzer</h1><p>Der Hauptadministrator hat Vollzugriff. Weitere Konten erhalten Zugriff auf Website-Inhalte, Online-Anmeldungen und Kontaktanfragen.</p></div></div>
      <section class="access-note panel"><div class="shield">✓</div><div><b>Hauptadministrator: <?=cms_e(CMS_SUPERUSER)?></b><p>Dieses Konto besitzt dauerhaft Zugriff auf alle Funktionen. Andere Benutzer können Website-Inhalte, Online-Anmeldungen, Kontaktanfragen und ihr eigenes Konto bearbeiten.</p></div></section>
      <div class="two-col users-layout"><section class="panel form-panel"><div class="panel-head"><div><span class="eyebrow">MITARBEITER</span><h2>Neuen Benutzer anlegen</h2></div></div><?php form_start('user_add','users');?><label>E-Mail-Adresse<input type="email" name="username" required placeholder="mitarbeiter@beispiel.de"></label><label>Startpasswort<input type="password" name="password" minlength="10" required></label><div class="permission-chip">Inhaltszugriff: Startseite · Seiten · Team · Galerie · Preise · Kurse · Hinweise · Medien · Kontaktdaten · Online-Anmeldungen · Nachrichten</div><button class="btn primary">Mitarbeiter hinzufügen</button></form></section><section class="list"><?php foreach(cms_users() as $u):$super=cms_is_superuser_name((string)$u['username'])?><article class="item user-card"><div class="user-card-head"><div class="avatar large"><?=strtoupper(substr((string)$u['username'],0,1))?></div><div><b><?=cms_e((string)$u['username'])?></b><span><?=$super?'Hauptadministrator · Vollzugriff':'Mitarbeiter · Inhalte und Kunden'?></span></div><span class="badge <?=$super?'status-erledigt':'status-neutral'?>"><?=$super?'Owner':'Inhalte'?></span></div><?php form_start('user_password','users');?><input type="hidden" name="username" value="<?=cms_e((string)$u['username'])?>"><div class="inline-password"><input type="password" name="password" minlength="10" required placeholder="Neues Passwort"><button class="btn ghost">Passwort ändern</button></div></form><?php if(!$super && $u['username']!==($user['username']??'')):?><?php form_start('user_delete','users');?><input type="hidden" name="username" value="<?=cms_e((string)$u['username'])?>"><button class="btn danger smallbtn" onclick="return confirm('Benutzer wirklich löschen?')">Benutzer löschen</button></form><?php endif;?></article><?php endforeach;?></section></div>

    <?php elseif ($section === 'activity'): $allActivities=cms_activity(100); ?>
      <div class="page-heading"><div><span class="eyebrow">VERWALTUNG</span><h1>Änderungsverlauf</h1><p>Prüfen, welcher Benutzer wann welche Änderung vorgenommen hat.</p></div></div>
      <section class="panel"><div class="activity-list activity-full"><?php foreach($allActivities as $a):?><div class="activity-row"><span class="activity-dot"></span><div><b><?=cms_e((string)($a['action']??''))?></b><small><?=cms_e((string)($a['detail']??''))?><?=!empty($a['detail'])?' · ':''?><?=cms_e((string)($a['user']??''))?></small></div><time><?=cms_e(str_replace('T',' ',substr((string)($a['time']??''),0,16)))?></time></div><?php endforeach;?><?php if(!$allActivities):?><div class="empty-state"><b>Noch keine Aktivitäten</b><span>Änderungen werden automatisch protokolliert.</span></div><?php endif;?></div></section>

    <?php elseif ($section === 'help'): ?>
      <div class="page-heading"><div><span class="eyebrow">HILFE</span><h1>Was macht jede Funktion?</h1><p>Einfache Erklärungen zu allen Bereichen des Admin Centers.</p></div></div>
      <div class="module-grid">
        <?php foreach([
          ['Startseite','Großes Bild, Hauptüberschrift und die zwei wichtigsten Schaltflächen ändern.','homepage'],
          ['Seiten und Texte','Vorhandene Texte bearbeiten sowie neue Blöcke oder Seiten hinzufügen.','pages'],
          ['Team','Fahrlehrer, Klassen, Beschreibungen und Fotos verwalten.','team'],
          ['Bildergalerie','Bilder anzeigen, ausblenden, beschreiben oder entfernen.','gallery'],
          ['Preise','Alle Preise für jede Führerscheinklasse zentral bearbeiten.','prices'],
          ['Kurse und Termine','Kurse hinzufügen oder löschen und den gesamten Bereich ausblenden.','summer'],
          ['Website-Hinweise','Zeitlich begrenzte Mitteilungen mit Start- und Enddatum veröffentlichen.','banner'],
          ['Medien','Neue Bilder hochladen und nicht benötigte Dateien löschen.','media'],
          ['Kontaktdaten','Adresse, Telefonnummern, E-Mail, WhatsApp und Öffnungszeiten ändern.','website'],
          ['Formulare und E-Mail','Formulare aktivieren und E-Mail-Benachrichtigungen einrichten.','forms'],
          ['Google / SEO','Titel und Beschreibung jeder Seite für Google bearbeiten.','seo'],
          ['Website-Menü','Bezeichnungen, Links und Sichtbarkeit der Menüeinträge ändern.','navigation'],
          ['Farben und Design','Farben, Schriftart und Textgröße der Website ändern.','design'],
          ['Online-Anmeldungen','Kundendaten, Dokumente, Notizen und Bearbeitungsstatus verwalten.','registrations'],
          ['Nachrichten','Kontaktanfragen ansehen und ihren Bearbeitungsstatus festlegen.','messages'],
          ['Änderungsverlauf','Prüfen, welcher Benutzer eine Änderung vorgenommen hat.','activity'],
          ['Benutzer','Benutzer mit Zugriff auf Inhalte und Kundenanfragen anlegen und Passwörter verwalten.','users'],
          ['Einstellungen und Sicherung','Datenaufbewahrung einstellen und eine Sicherung herunterladen.','settings'],
        ] as $m):?><a class="module-card" href="?section=<?=$m[2]?>"><span><?=icon(in_array($m[2],['homepage'],true)?'home':(in_array($m[2],['team'],true)?'team':'settings'))?></span><div><h2><?=$m[0]?></h2><p><?=$m[1]?></p><b>Öffnen →</b></div></a><?php endforeach;?>
      </div>

    <?php elseif ($section === 'settings'): $st=$site['settings']??[]; ?>
      <div class="page-heading"><div><span class="eyebrow">VERWALTUNG</span><h1>Einstellungen und Sicherung</h1><p>Technische Grundeinstellungen und Datensicherung des Admin Centers.</p></div></div>
      <div class="two-col"><section class="panel form-panel"><?php form_start('settings','settings');?><div class="grid2"><label>Dokumente aufbewahren (Tage)<input type="number" min="1" max="365" name="retention_days" value="<?=cms_e((string)($st['retention_days']??30))?>"><small>Empfohlen: nur so lange wie organisatorisch notwendig.</small></label><label>Benachrichtigungs-E-Mail<input type="email" name="notification_email" value="<?=cms_e((string)($st['notification_email']??''))?>"></label><label>Zeitzone<input name="timezone" value="<?=cms_e((string)($st['timezone']??'Europe/Berlin'))?>"></label></div><button class="btn primary">Einstellungen speichern</button></form></section><section class="panel form-panel"><span class="eyebrow">SICHERUNG</span><h2>Admin-Daten exportieren</h2><p class="muted-copy">Lädt eine JSON-Sicherung von Website-Einstellungen, Status und Aktivitätsprotokoll herunter. Kundendokumente werden aus Datenschutzgründen nicht in diesen Export aufgenommen.</p><a class="btn ghost" href="export.php">Sicherung herunterladen</a></section></div>

    <?php elseif ($section === 'profile'): ?>
      <div class="page-heading"><div><span class="eyebrow">KONTO</span><h1>Mein Konto</h1><p>Anmeldedaten und Zugriffsrolle.</p></div></div>
      <div class="two-col profile-layout"><section class="panel profile-card"><div class="avatar xlarge"><?=strtoupper(substr((string)($user['username']??'U'),0,1))?></div><h2><?=cms_e((string)($user['username']??''))?></h2><span class="badge <?=$isOwner?'status-erledigt':'status-neutral'?>"><?=$isOwner?'Hauptadministrator · Vollzugriff':'Mitarbeiter · Inhalte und Kunden'?></span><div class="permission-list"><?php if($isOwner):?><span>✓ Alle Website-Funktionen</span><span>✓ Benutzerverwaltung</span><span>✓ Kundenverwaltung</span><span>✓ Systemeinstellungen</span><?php else:?><span>✓ Startseite, Seiten und Texte</span><span>✓ Team, Galerie, Preise und Kurse</span><span>✓ Hinweise, Medien und Kontaktdaten</span><span>✓ Online-Anmeldungen, Dokumente und Nachrichten</span><span>✓ Bearbeitungsstatus und interne Notizen</span><span>— Keine Benutzerverwaltung, E-Mail- oder Systemeinstellungen</span><?php endif;?></div></section><section class="panel form-panel"><div class="panel-head"><div><span class="eyebrow">SICHERHEIT</span><h2>Passwort ändern</h2></div></div><?php form_start('self_password','profile');?><label>Neues Passwort<div class="password-field"><input id="profile-password" type="password" name="password" minlength="10" required><button type="button" class="password-eye" data-password-toggle="profile-password" aria-label="Passwort anzeigen" title="Passwort anzeigen">👁</button></div></label><label>Passwort wiederholen<div class="password-field"><input id="profile-password-confirm" type="password" name="password_confirm" minlength="10" required><button type="button" class="password-eye" data-password-toggle="profile-password-confirm" aria-label="Passwort anzeigen" title="Passwort anzeigen">👁</button></div></label><button class="btn primary">Passwort aktualisieren</button></form></section></div>
    <?php endif; ?>
  </div>
</main>
<script src="assets/admin.js?v=20261104-1"></script>
<script>
document.querySelectorAll('[data-password-toggle]').forEach(function(btn){
  btn.addEventListener('click', function(){
    var input=document.getElementById(btn.getAttribute('data-password-toggle'));
    if(!input) return;
    var show=input.type==='password';
    input.type=show?'text':'password';
    btn.textContent=show?'🙈':'👁';
    btn.setAttribute('aria-label', show?'Passwort ausblenden':'Passwort anzeigen');
    btn.setAttribute('title', show?'Passwort ausblenden':'Passwort anzeigen');
    input.focus({preventScroll:true});
  });
});
</script>
</body>
</html>
