<?php
declare(strict_types=1);

const BV_PROMO_FILE = __DIR__ . '/../private_admin/promotions.json';
const BV_PROMO_UPLOAD = 'assets/uploads/promotions/';

function bv_promo_read(): array {
    if (!is_file(BV_PROMO_FILE)) return ['version'=>0,'popups'=>[],'actions'=>[]];
    $raw = file_get_contents(BV_PROMO_FILE);
    $data = $raw === false ? null : json_decode($raw, true);
    if (!is_array($data) || !isset($data['version'],$data['popups'],$data['actions']) || !is_array($data['popups']) || !is_array($data['actions'])) throw new RuntimeException('Die Aktionsdaten konnten nicht gelesen werden.');
    return $data;
}

function bv_promo_write(array $data): void {
    $directory = dirname(BV_PROMO_FILE);
    if (!is_dir($directory) && !mkdir($directory,0700,true)) throw new RuntimeException('Der geschützte Speicher ist nicht beschreibbar.');
    $temp = tempnam($directory,'.promotions-');
    if ($temp === false) throw new RuntimeException('Speichern nicht möglich.');
    try {
        $json = json_encode($data,JSON_THROW_ON_ERROR|JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if (file_put_contents($temp,$json,LOCK_EX) === false || !chmod($temp,0600) || !rename($temp,BV_PROMO_FILE)) throw new RuntimeException('Die Aktionsdaten konnten nicht gespeichert werden.');
    } finally { if (is_file($temp)) unlink($temp); }
}

function bv_promo_pages(): array {
    $pages = [];
    foreach (glob(__DIR__.'/../*.html') ?: [] as $file) {
        $html = (string)file_get_contents($file);
        preg_match('~<title>(.*?)</title>~is',$html,$title);
        $name = basename($file);
        $label = trim(html_entity_decode(strip_tags($title[1] ?? $name),ENT_QUOTES|ENT_HTML5,'UTF-8'));
        $label = preg_replace('/\s*[|–-]\s*Fahrschule BV.*$/u','',$label) ?: $label;
        $positions = ['after-hero'=>'Nach dem Hauptbild / Seitenkopf','before-footer'=>'Vor der Fußzeile'];
        preg_match_all('~<section\b([^>]*)>(.*?)</section>~is',$html,$sections,PREG_SET_ORDER);
        foreach ($sections as $index=>$section) {
            if (!preg_match('~\bdata-cms-section=["\']([A-Za-z0-9_-]{1,80})["\']~i',$section[1],$key)) continue;
            preg_match('~<h[12]\b[^>]*>(.*?)</h[12]>~is',$section[2],$heading);
            $text = trim(preg_replace('/\s+/u',' ',html_entity_decode(strip_tags($heading[1] ?? ''),ENT_QUOTES|ENT_HTML5,'UTF-8')) ?? '');
            $positions['after:'.$key[1]] = 'Nach Abschnitt '.($index+1).($text !== '' ? ': '.$text : '');
        }
        $pages[$name] = ['label'=>$label,'positions'=>$positions];
    }
    uksort($pages,fn($a,$b)=>$a==='index.html'?-1:($b==='index.html'?1:strnatcasecmp($a,$b)));
    return $pages;
}

function bv_promo_text(array $data,string $key,int $limit=2000): string {
    if (isset($data[$key]) && !is_scalar($data[$key])) throw new InvalidArgumentException('Ungültiges Textfeld.');
    $text = trim(str_replace(["\r\n","\r"],"\n",(string)($data[$key] ?? '')));
    if (strlen($text)>$limit) throw new InvalidArgumentException('Ein Textfeld ist zu lang.');
    return $text;
}

function bv_promo_choice(mixed $value,array $allowed,string $default): string {
    if ($value === null) return $default;
    if (!is_string($value) || !in_array($value,$allowed,true)) throw new InvalidArgumentException('Ungültige Auswahl.');
    return $value;
}

function bv_promo_number(mixed $value,int $min,int $max,int $default): int {
    if ($value === null || $value === '') return $default;
    $number = filter_var($value,FILTER_VALIDATE_INT);
    if ($number === false || $number<$min || $number>$max) throw new InvalidArgumentException('Eine Zahl liegt außerhalb des erlaubten Bereichs.');
    return $number;
}

function bv_promo_date(string $input): ?int {
    if ($input === '') return null;
    $zone = new DateTimeZone('Europe/Berlin');
    $date = DateTimeImmutable::createFromFormat('!Y-m-d\TH:i',$input,$zone);
    if (!$date || $date->format('Y-m-d\TH:i') !== $input) throw new InvalidArgumentException('Bitte eine gültige Uhrzeit für Europe/Berlin wählen. Diese Uhrzeit kann bei der Zeitumstellung entfallen.');
    // During the autumn clock change, consistently choose the second occurrence.
    $timestamp = $date->getTimestamp();
    foreach ([$timestamp-3600,$timestamp+3600] as $candidate) {
        if ((new DateTimeImmutable('@'.$candidate))->setTimezone($zone)->format('Y-m-d\TH:i') === $input) $timestamp = max($timestamp,$candidate);
    }
    return $timestamp*1000;
}

function bv_promo_image(string $path): bool {
    if (!preg_match('~^assets/uploads/promotions/[0-9]{14}-[a-f0-9]{16}\.(?:jpg|png|webp|gif|avif)$~D',$path)) return false;
    $root = realpath(__DIR__.'/../assets/uploads/promotions');
    $file = realpath(__DIR__.'/../'.$path);
    return $root !== false && $file !== false && str_starts_with($file,$root.DIRECTORY_SEPARATOR) && is_file($file);
}

function bv_promo_url(string $url): bool {
    return $url === '' || (!preg_match('/[\x00-\x20\x7f]/',$url) && (!preg_match('~^[a-z][a-z0-9+.-]*:~i',$url) || preg_match('~^(?:https?://|mailto:|tel:)~i',$url)));
}

function bv_promo_defaults(string $kind): array {
    $base = ['active'=>false,'targets'=>['mode'=>'home','pages'=>[]],'start'=>'','end'=>'','startAt'=>null,'endAt'=>null,'order'=>0];
    if ($kind === 'popups') return $base+['image'=>'','frequency'=>'session','priority'=>0,'countdown'=>['enabled'=>false,'end'=>'','endAt'=>null,'placement'=>'below','align'=>'center','offset'=>12]];
    return $base+['title'=>'','description'=>'','offer'=>'','originalPrice'=>'','price'=>'','images'=>[],'background'=>'#14191f','textColor'=>'#f6f7f8','buttonColor'=>'#f47a20','layout'=>'left','align'=>'left','padding'=>32,'gap'=>24,'radius'=>18,'buttons'=>[],'placement'=>'after-hero','placements'=>[]];
}

function bv_promo_validate(string $kind,array $input,bool $publish=false): array {
    $pages = bv_promo_pages();
    $targets = $input['targets'] ?? [];
    if (!is_array($targets)) throw new InvalidArgumentException('Ungültige Seitenauswahl.');
    $mode = bv_promo_choice($targets['mode'] ?? null,['all','home','selected'],'home');
    $selected = $targets['pages'] ?? [];
    if (!is_array($selected) || count($selected)>100) throw new InvalidArgumentException('Ungültige Seitenauswahl.');
    foreach ($selected as $file) if (!is_string($file) || !isset($pages[$file])) throw new InvalidArgumentException('Eine ausgewählte Seite existiert nicht.');
    if ($mode==='selected' && !$selected && $publish) throw new InvalidArgumentException('Bitte mindestens eine Seite auswählen.');
    $start = bv_promo_text($input,'start',20); $end = bv_promo_text($input,'end',20);
    $startAt = bv_promo_date($start); $endAt = bv_promo_date($end);
    if ($startAt !== null && $endAt !== null && $endAt <= $startAt) throw new InvalidArgumentException('Das Ende muss nach dem Beginn liegen.');
    $result = ['active'=>!empty($input['active']),'targets'=>['mode'=>$mode,'pages'=>array_values(array_unique($selected))],'start'=>$start,'end'=>$end,'startAt'=>$startAt,'endAt'=>$endAt,'order'=>bv_promo_number($input['order'] ?? null,-9999,9999,0)];
    if ($kind === 'popups') {
        $image = bv_promo_text($input,'image',250);
        if (($image !== '' && !bv_promo_image($image)) || ($publish && $image==='')) throw new InvalidArgumentException('Bitte ein gültiges Pop-up-Bild hochladen.');
        $counter = $input['countdown'] ?? [];
        if (!is_array($counter)) throw new InvalidArgumentException('Ungültiger Countdown.');
        $counterEnd = bv_promo_text($counter,'end',20);
        $counterAt = bv_promo_date($counterEnd);
        if (!empty($counter['enabled']) && $counterAt===null && $publish) throw new InvalidArgumentException('Bitte das Ende des Countdowns festlegen.');
        return $result+['image'=>$image,'frequency'=>bv_promo_choice($input['frequency'] ?? null,['visit','session','daily','expiry'],'session'),'priority'=>bv_promo_number($input['priority'] ?? null,-9999,9999,0),'countdown'=>['enabled'=>!empty($counter['enabled']),'end'=>$counterEnd,'endAt'=>$counterAt,'placement'=>bv_promo_choice($counter['placement'] ?? null,['overlay','below'],'below'),'align'=>bv_promo_choice($counter['align'] ?? null,['left','center','right'],'center'),'offset'=>bv_promo_number($counter['offset'] ?? null,0,200,12)]];
    }
    foreach (['title'=>180,'description'=>6000,'offer'=>2000,'originalPrice'=>100,'price'=>100] as $key=>$limit) $result[$key] = bv_promo_text($input,$key,$limit);
    $images = $input['images'] ?? [];
    if (!is_array($images) || count($images)>6) throw new InvalidArgumentException('Maximal sechs Bilder pro Aktion.');
    foreach ($images as $image) if (!is_string($image) || !bv_promo_image($image)) throw new InvalidArgumentException('Ein Aktionsbild ist ungültig.');
    $result['images'] = array_values($images);
    if ($publish && $result['title']==='' && !$images && $result['offer']==='') throw new InvalidArgumentException('Bitte mindestens einen Titel, Angebotstext oder ein Bild hinzufügen.');
    foreach (['background'=>'#14191f','textColor'=>'#f6f7f8','buttonColor'=>'#f47a20'] as $key=>$default) {
        $color = $input[$key] ?? $default;
        if (!is_string($color) || !preg_match('/^#[a-f0-9]{6}$/iD',$color)) throw new InvalidArgumentException('Ungültige Farbe.');
        $result[$key] = $color;
    }
    $result['layout'] = bv_promo_choice($input['layout'] ?? null,['left','right','top'],'left');
    $result['align'] = bv_promo_choice($input['align'] ?? null,['left','center','right'],'left');
    foreach (['padding'=>[8,80,32],'gap'=>[0,64,24],'radius'=>[0,48,18]] as $key=>[$min,$max,$default]) $result[$key] = bv_promo_number($input[$key] ?? null,$min,$max,$default);
    $buttons = $input['buttons'] ?? [];
    if (!is_array($buttons) || count($buttons)>3) throw new InvalidArgumentException('Maximal drei Buttons pro Aktion.');
    $result['buttons'] = [];
    foreach ($buttons as $button) {
        if (!is_array($button)) throw new InvalidArgumentException('Ungültiger Button.');
        $text = bv_promo_text($button,'text',100);$url = bv_promo_text($button,'url',1000);
        if (!bv_promo_url($url)) throw new InvalidArgumentException('Bitte ein sicheres Linkziel verwenden (https://, mailto:, tel: oder eine Website-Seite).');
        if ($publish && (($text==='') !== ($url===''))) throw new InvalidArgumentException('Bitte Button-Text und Link gemeinsam ausfüllen.');
        if ($text!=='' || $url!=='') $result['buttons'][] = ['text'=>$text,'url'=>$url];
    }
    $result['placement'] = bv_promo_choice($input['placement'] ?? null,['after-hero','before-footer'],'after-hero');
    $placements = $input['placements'] ?? [];
    if (!is_array($placements) || count($placements)>100) throw new InvalidArgumentException('Ungültige Positionen.');
    $result['placements'] = [];
    foreach ($placements as $file=>$position) {
        if (!isset($pages[$file]) || !is_string($position) || !isset($pages[$file]['positions'][$position])) throw new InvalidArgumentException('Die gewählte Position ist auf dieser Seite nicht vorhanden.');
        $result['placements'][$file] = $position;
    }
    return $result;
}

function bv_promo_public(array $store): array {
    $output = ['version'=>(int)$store['version'],'serverTime'=>(int)round(microtime(true)*1000),'popups'=>[],'actions'=>[]];
    foreach (['popups','actions'] as $kind) foreach ($store[$kind] as $id=>$record) {
        $published = $record['published'] ?? null;
        if (!is_array($published) || empty($published['active'])) continue;
        $output[$kind][] = ['id'=>$id]+$published;
    }
    usort($output['popups'],fn($a,$b)=>($b['priority']<=>$a['priority']) ?: strcmp($a['id'],$b['id']));
    usort($output['actions'],fn($a,$b)=>($a['order']<=>$b['order']) ?: strcmp($a['id'],$b['id']));
    return $output;
}

function bv_promo_refs(mixed $value,array &$refs): void {
    if (is_string($value) && str_starts_with($value,BV_PROMO_UPLOAD)) $refs[$value]=true;
    if (is_array($value)) foreach ($value as $child) bv_promo_refs($child,$refs);
}

function bv_promo_cleanup(array $before,array $after): void {
    $old=[];$used=[];bv_promo_refs($before,$old);bv_promo_refs($after,$used);
    $publicFile = __DIR__.'/../assets/data/site-config.json';
    $site = is_file($publicFile) ? json_decode((string)file_get_contents($publicFile),true) : [];
    bv_promo_refs($site,$used);
    foreach (array_diff_key($old,$used) as $path=>$_) if (bv_promo_image($path)) @unlink(__DIR__.'/../'.$path);
}
