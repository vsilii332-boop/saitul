<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
cms_require_owner();
require __DIR__ . '/promotions-lib.php';
$payload = [
    'exported_at' => date('c'),
    'site' => cms_site(),
    'status' => cms_status(),
    'activity' => cms_activity(100),
    'promotions' => bv_promo_read(),
];
header('Content-Type: application/json; charset=utf-8');
header('Content-Disposition: attachment; filename="fahrschule-bv-admin-backup-' . date('Y-m-d-His') . '.json"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');
echo json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
