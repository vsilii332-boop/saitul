<?php
declare(strict_types=1);
require __DIR__.'/lib.php';
require __DIR__.'/editor-lib.php';
require __DIR__.'/promotions-lib.php';
header('Content-Type: application/json; charset=UTF-8');header('Cache-Control: no-store');
$kind=(string)($_GET['kind'] ?? '');
if(!in_array($kind,['popups','actions'],true) || !cms_logged_in() || !cms_section_allowed($kind)){http_response_code(403);echo '{"error":"Keine Berechtigung."}';exit;}
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);echo '{}';exit;}
if(empty($_SESSION['cms_csrf']) || !is_string($_POST['csrf'] ?? null) || !hash_equals($_SESSION['cms_csrf'],$_POST['csrf'])){http_response_code(403);echo '{"error":"Sitzung abgelaufen. Bitte neu laden."}';exit;}
try {
    if (isset($_POST['remove'])) {
        if (!is_string($_POST['remove'])) throw new InvalidArgumentException('Ungültiges Bild.');
        $path = $_POST['remove'];
        $lock = fopen(dirname(BV_PROMO_FILE).'/promotions.lock','c');
        if (!$lock || !flock($lock,LOCK_EX)) throw new RuntimeException();
        try {bv_promo_cleanup(['temporary'=>$path],bv_promo_read());}
        finally {flock($lock,LOCK_UN);fclose($lock);}
        echo json_encode(['ok'=>true,'retained'=>bv_promo_image($path)]);exit;
    }
    $file=$_FILES['image'] ?? null;
    if(!$file || $file['error']!==UPLOAD_ERR_OK || $file['size']<1 || $file['size']>cms_editor_upload_limit())throw new InvalidArgumentException('Bitte ein Bild innerhalb der angezeigten Dateigröße wählen.');
    $types=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif','image/avif'=>'avif'];
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if(!isset($types[$mime]) || !@getimagesize($file['tmp_name']))throw new InvalidArgumentException('Nur echte JPG-, PNG-, WEBP-, GIF- oder AVIF-Bilder sind erlaubt.');
    $path=BV_PROMO_UPLOAD.date('YmdHis').'-'.bin2hex(random_bytes(8)).'.'.$types[$mime];$target=__DIR__.'/../'.$path;
    if(!is_dir(dirname($target)) && !mkdir(dirname($target),0755,true))throw new RuntimeException();
    if(!move_uploaded_file($file['tmp_name'],$target))throw new RuntimeException();
    chmod($target,0644);
    echo json_encode(['ok'=>true,'path'=>$path]);
}catch(Throwable $e){http_response_code($e instanceof InvalidArgumentException?400:500);echo json_encode(['error'=>$e instanceof InvalidArgumentException?$e->getMessage():'Das Bild konnte nicht gespeichert werden. Bitte Schreibrechte prüfen.'],JSON_UNESCAPED_UNICODE);}
