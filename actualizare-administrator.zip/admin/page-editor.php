<?php
// Included only after the admin session and section authorization checks.
require_once __DIR__ . '/editor-lib.php';
$sel = (string)($_GET['page'] ?? ($section === 'gallery' ? 'galerie.html' : 'motorradkurs.html'));
if (!isset($pages[$sel])) $sel = (string)array_key_first($pages);
?>
<link rel="stylesheet" href="assets/page-editor.css?v=20261104-1">
<div class="page-heading"><div><span class="eyebrow">EINFACH BEARBEITEN</span><h1>Ihre Seite. Ihr Inhalt.</h1><p>Seite wählen, Text oder Bild anklicken und mit wenigen Schritten ändern.</p></div></div>
<div class="visual-editor" data-visual-editor data-initial-tab="<?=$section==='gallery'?'image':'text'?>" data-max-upload="<?=cms_editor_upload_limit()?>" data-version="<?=(int)($site['_meta']['version']??0)?>" data-page="<?=cms_e($sel)?>" data-csrf="<?=cms_e(cms_csrf())?>">
  <div class="visual-controls panel">
    <label for="visual-page">1. Seite auswählen</label>
    <select id="visual-page" data-visual-page><?php foreach($pages as $file=>$title):?><option value="<?=cms_e($file)?>" <?=$sel===$file?'selected':''?>><?=cms_e($title)?> · <?=cms_e($file)?></option><?php endforeach;?></select>
    <div class="visual-help"><span>2</span><p>Text oder Bild in der Vorschau anklicken. Oder hier in der Liste auswählen.</p></div>
    <div class="visual-tabs" aria-label="Inhaltsart"><button type="button" class="active" data-visual-tab="text" aria-pressed="true">Texte <span data-text-count>0</span></button><button type="button" data-visual-tab="image" aria-pressed="false">Bilder <span data-image-count>0</span></button></div>
    <label class="sr-only" for="visual-search">Inhalte suchen</label><input type="search" id="visual-search" data-visual-search placeholder="Text oder Bild suchen …">
    <div class="visual-list" data-visual-list aria-label="Bearbeitbare Inhalte"></div>
    <p class="visual-status" data-visual-status role="status">Vorschau wird geladen …</p>
    <button type="button" class="btn primary full" data-visual-save disabled>Änderungen speichern</button>
    <button type="button" class="btn ghost full visual-discard" data-visual-discard hidden>Änderungen verwerfen</button>
    <p class="visual-save-note">Die Vorschau bleibt privat. Erst „Speichern & veröffentlichen“ übernimmt Ihre Änderungen auf die Website.</p>
  </div>
  <section class="visual-preview">
    <div class="visual-preview-bar"><span><i class="status-dot online"></i> Seitenvorschau</span><div><button type="button" class="preview-mode active" data-visual-mode="desktop" aria-pressed="true">Desktop</button><button type="button" class="preview-mode" data-visual-mode="mobile" aria-pressed="false">Mobil</button></div></div>
    <p class="visual-preview-tip">Klicken Sie auf einen Text oder ein Bild, um es zu bearbeiten.</p>
    <iframe data-visual-frame src="../<?=rawurlencode($sel)?>?editor-preview=<?=time()?>" title="Anklickbare Seitenvorschau"></iframe>
  </section>
  <dialog class="visual-dialog" data-visual-dialog aria-labelledby="visual-dialog-title">
    <form method="dialog" data-visual-form>
      <div class="panel-head"><div><span class="eyebrow">3. INHALT ÄNDERN</span><h2 id="visual-dialog-title">Text bearbeiten</h2></div><button type="button" class="icon-btn" data-visual-cancel aria-label="Schließen">×</button></div>
      <div data-visual-fields></div>
      <p class="visual-dialog-error" data-visual-error role="alert"></p>
      <div class="form-actions"><button type="button" class="btn ghost" data-visual-cancel>Abbrechen</button><button type="submit" class="btn primary" data-visual-apply>In Vorschau übernehmen</button></div>
    </form>
  </dialog>
</div>
<script src="assets/page-editor.js?v=20261104-1" defer></script>
