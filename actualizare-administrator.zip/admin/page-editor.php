<?php
// Included only after the admin session and section authorization checks.
require_once __DIR__ . '/editor-lib.php';
$sel = (string)($_GET['page'] ?? 'index.html');
if (!isset($pages[$sel])) $sel = 'index.html';
?>
<link rel="stylesheet" href="assets/page-editor.css?v=20261104-2">
<div class="page-heading"><div><span class="eyebrow">SEITE BEARBEITEN</span><h1><?=cms_e($sectionTitle)?></h1><p>Alle Texte, Bilder und Links dieser Seite – einschließlich Kopfzeile, Fußzeile und Mobilansicht.</p></div><a class="btn ghost" href="../<?=rawurlencode($sel)?>" target="_blank" rel="noopener">Seite ansehen ↗</a></div>
<div class="visual-editor" data-visual-editor data-initial-tab="all" data-max-upload="<?=cms_editor_upload_limit()?>" data-version="<?=(int)($site['_meta']['version']??0)?>" data-page="<?=cms_e($sel)?>" data-csrf="<?=cms_e(cms_csrf())?>">
  <div class="visual-controls panel">
    <div class="visual-content-heading"><div><h2>Alle Inhalte dieser Seite</h2><p>Beim gewünschten Text oder Bild auf „Ändern“ klicken.</p></div></div>
    <div class="visual-tabs" aria-label="Inhaltsart">
      <button type="button" class="active" data-visual-tab="all" aria-pressed="true">Alles</button>
      <button type="button" data-visual-tab="text" aria-pressed="false">Texte <span data-text-count>0</span></button>
      <button type="button" data-visual-tab="image" aria-pressed="false">Bilder <span data-image-count>0</span></button>
      <button type="button" data-visual-tab="link" aria-pressed="false">Links <span data-link-count>0</span></button>
    </div>
    <label class="sr-only" for="visual-search">Inhalte suchen</label><input type="search" id="visual-search" data-visual-search placeholder="Inhalte dieser Seite durchsuchen …">
    <div class="visual-list" data-visual-list aria-label="Bearbeitbare Inhalte"></div>
    <div class="visual-save-bar"><p class="visual-status" data-visual-status role="status">Vorschau wird geladen …</p>
    <button type="button" class="btn primary full" data-visual-save disabled>Änderungen speichern</button>
    <button type="button" class="btn ghost full visual-discard" data-visual-discard hidden>Änderungen verwerfen</button>
    <p class="visual-save-note">Erst „Speichern & veröffentlichen“ übernimmt die Änderungen auf diese Seite.</p></div>
  </div>
  <section class="visual-preview">
    <div class="visual-preview-bar"><span><i class="status-dot online"></i> Seitenvorschau</span><div><button type="button" class="preview-mode active" data-visual-mode="desktop" aria-pressed="true">Desktop</button><button type="button" class="preview-mode" data-visual-mode="mobile" aria-pressed="false">Mobil</button></div></div>
    <p class="visual-preview-tip">Klicken Sie auf einen Text oder ein Bild, um es zu bearbeiten.</p>
    <iframe data-visual-frame src="../<?=rawurlencode($sel)?>?editor-preview=<?=time()?>" title="Anklickbare Seitenvorschau"></iframe>
  </section>
  <dialog class="visual-dialog" data-visual-dialog aria-labelledby="visual-dialog-title">
    <form method="dialog" data-visual-form>
      <div class="panel-head"><div><span class="eyebrow">INHALT ÄNDERN</span><h2 id="visual-dialog-title">Text bearbeiten</h2></div><button type="button" class="icon-btn" data-visual-cancel aria-label="Schließen">×</button></div>
      <div data-visual-fields></div>
      <p class="visual-dialog-error" data-visual-error role="alert"></p>
      <div class="form-actions"><button type="button" class="btn ghost" data-visual-cancel>Abbrechen</button><button type="submit" class="btn primary" data-visual-apply>In Vorschau übernehmen</button></div>
    </form>
  </dialog>
</div>
<script src="assets/page-editor.js?v=20261104-2" defer></script>
