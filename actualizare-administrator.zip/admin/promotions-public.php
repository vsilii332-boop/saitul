<?php
declare(strict_types=1);
require __DIR__.'/promotions-lib.php';
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, max-age=0');
header('X-Content-Type-Options: nosniff');
if($_SERVER['REQUEST_METHOD']!=='GET'){http_response_code(405);echo '{}';exit;}
try {echo json_encode(bv_promo_public(bv_promo_read()),JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);}
catch(Throwable $e){http_response_code(503);echo '{"error":"Aktionsdaten vorübergehend nicht verfügbar."}';}
