<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
cms_require_owner();
if (!cms_section_allowed('gallery')) { http_response_code(403); exit('Keine Berechtigung.'); }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
cms_check_csrf();

$targetRel = trim((string)($_POST['target'] ?? ''));
$target = cms_public_image_target($targetRel);
if ($target === null) cms_redirect('gallery', 'Bildpfad ist ungültig');
if (empty($_FILES['image']) || (int)$_FILES['image']['error'] !== UPLOAD_ERR_OK) cms_redirect('gallery', 'Bild konnte nicht hochgeladen werden');

$f = $_FILES['image'];
if ((int)$f['size'] < 1 || (int)$f['size'] > 15 * 1024 * 1024) cms_redirect('gallery', 'Bild ist zu groß (max. 15 MB)');
$mime = (new finfo(FILEINFO_MIME_TYPE))->file((string)$f['tmp_name']) ?: '';
$sourceTypes = ['image/jpeg','image/png','image/webp','image/gif','image/avif','image/x-icon','image/vnd.microsoft.icon'];
if (!in_array($mime, $sourceTypes, true)) cms_redirect('gallery', 'Nur JPG, PNG, WEBP, GIF, AVIF oder ICO erlaubt');

$ext = strtolower(pathinfo($target, PATHINFO_EXTENSION));
$directMime = [
    'jpg'=>['image/jpeg'], 'jpeg'=>['image/jpeg'], 'png'=>['image/png'], 'webp'=>['image/webp'],
    'gif'=>['image/gif'], 'avif'=>['image/avif'], 'ico'=>['image/x-icon','image/vnd.microsoft.icon'],
];

$tmpOut = $target . '.new-' . bin2hex(random_bytes(4));
$ok = false;

// If the uploaded format already matches the target format, keep the original bytes.
if (in_array($mime, $directMime[$ext] ?? [], true)) {
    $ok = move_uploaded_file((string)$f['tmp_name'], $tmpOut);
} elseif (in_array($ext, ['jpg','jpeg','png','webp','gif'], true) && function_exists('imagecreatefromstring')) {
    $raw = @file_get_contents((string)$f['tmp_name']);
    $im = $raw !== false ? @imagecreatefromstring($raw) : false;
    if ($im !== false) {
        if (in_array($ext, ['png','webp','gif'], true)) {
            imagealphablending($im, false); imagesavealpha($im, true);
        }
        if ($ext === 'jpg' || $ext === 'jpeg') $ok = @imagejpeg($im, $tmpOut, 90);
        elseif ($ext === 'png') $ok = @imagepng($im, $tmpOut, 6);
        elseif ($ext === 'webp' && function_exists('imagewebp')) $ok = @imagewebp($im, $tmpOut, 90);
        elseif ($ext === 'gif' && function_exists('imagegif')) $ok = @imagegif($im, $tmpOut);
        imagedestroy($im);
    }
} else {
    @unlink($tmpOut);
    cms_redirect('gallery', 'Für dieses Bild bitte denselben Dateityp wählen (z. B. PNG gegen PNG)');
}

if (!$ok || !is_file($tmpOut) || filesize($tmpOut) < 1) {
    @unlink($tmpOut); cms_redirect('gallery', 'Bild konnte nicht verarbeitet werden');
}

@chmod($tmpOut, 0644);
if (!@rename($tmpOut, $target)) {
    @unlink($tmpOut); cms_redirect('gallery', 'Bild konnte auf dem Server nicht ersetzt werden');
}
clearstatcache(true, $target);
cms_log_activity('Website-Bild ersetzt', $targetRel);
header('Location: index.php?section=gallery&focus=' . rawurlencode($targetRel) . '&msg=' . rawurlencode('Bild erfolgreich ersetzt'));
exit;
