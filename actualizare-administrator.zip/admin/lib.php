<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Strict',
        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    ]);
    session_start();
}

const CMS_STORAGE = __DIR__ . '/../private_admin';
const CMS_SITE_FILE = CMS_STORAGE . '/site.json';
const CMS_PUBLIC_SITE_FILE = __DIR__ . '/../assets/data/site-config.json';
const CMS_USERS_FILE = CMS_STORAGE . '/users.json';
const CMS_STATUS_FILE = CMS_STORAGE . '/status.json';
const CMS_ACTIVITY_FILE = CMS_STORAGE . '/activity.json';
const CMS_MAIL_FILE = CMS_STORAGE . '/mail.json';
const CMS_SUPERUSER = 'vsilii332@gmail.com';
const CMS_PAGE_MAP_FILE = __DIR__ . '/page-map.json';

function cms_json_read(string $file, array $default = []): array {
    if (!is_file($file)) return $default;
    $x = json_decode((string)@file_get_contents($file), true);
    return is_array($x) ? $x : $default;
}

function cms_json_write(string $file, array $data): bool {
    if (!is_dir(dirname($file))) @mkdir(dirname($file), 0700, true);
    $tmp = $file . '.tmp';
    $ok = file_put_contents($tmp, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX) !== false;
    if ($ok) {
        @chmod($tmp, 0600);
        $ok = @rename($tmp, $file);
    }
    return $ok;
}

function cms_site(): array { return cms_json_read(CMS_SITE_FILE, []); }
function cms_save_site(array $site): void {
    $site['_meta'] = [
        'updated_at' => date('c'),
        'updated_by' => (string)(cms_user()['username'] ?? 'System'),
        'version' => (int)($site['_meta']['version'] ?? 0) + 1,
    ];
    if (!cms_json_write(CMS_SITE_FILE, $site)) {
        throw new RuntimeException('Speichern fehlgeschlagen. Bitte die Schreibrechte des Ordners private_admin prüfen.');
    }
    if (!cms_json_write(CMS_PUBLIC_SITE_FILE, $site)) {
        throw new RuntimeException('Die Daten wurden gespeichert, konnten aber nicht veröffentlicht werden. Bitte die Schreibrechte des Ordners assets/data prüfen.');
    }
}

function cms_sync_public_site(): bool {
    $site = cms_site();
    return $site !== [] && cms_json_write(CMS_PUBLIC_SITE_FILE, $site);
}
function cms_mail_config(): array { return cms_json_read(CMS_MAIL_FILE, []); }
function cms_save_mail_config(array $config): void { if (!cms_json_write(CMS_MAIL_FILE, $config)) throw new RuntimeException('Die SMTP-Daten konnten nicht geschützt gespeichert werden.'); }
function cms_users(): array { return cms_json_read(CMS_USERS_FILE, []); }
function cms_has_superuser(): bool { foreach (cms_users() as $u) if (cms_is_superuser_name((string)($u['username'] ?? ''))) return true; return false; }
function cms_is_setup(): bool { return cms_has_superuser(); }
function cms_is_superuser_name(string $username): bool { return strtolower(trim($username)) === strtolower(CMS_SUPERUSER); }

function cms_user(): ?array {
    if (!isset($_SESSION['cms_user']) || !is_array($_SESSION['cms_user'])) return null;
    $last = (int)($_SESSION['cms_last'] ?? 0);
    if ($last > 0 && time() - $last > 7200) {
        unset($_SESSION['cms_user'], $_SESSION['cms_last']);
        return null;
    }
    $_SESSION['cms_last'] = time();
    $u = $_SESSION['cms_user'];
    $u['role'] = cms_is_superuser_name((string)($u['username'] ?? '')) ? 'owner' : 'staff';
    return $u;
}

function cms_logged_in(): bool { return cms_user() !== null; }
function cms_is_owner(): bool { $u = cms_user(); return $u !== null && cms_is_superuser_name((string)($u['username'] ?? '')); }
function cms_require_login(): void { if (!cms_logged_in()) { header('Location: index.php'); exit; } }
function cms_require_owner(): void { cms_require_login(); if (!cms_is_owner()) { http_response_code(403); exit('Keine Berechtigung für diese Aktion.'); } }

function cms_allowed_sections(): array {
    if (cms_is_owner()) return ['popups','actions','analytics','dashboard','homepage','pages','team','gallery','prices','summer','banner','media','website','forms','seo','navigation','design','registrations','messages','activity','users','settings','help','profile'];
    return ['popups','actions','analytics','dashboard','homepage','pages','team','gallery','prices','summer','banner','media','website','registrations','messages','profile'];
}

function cms_section_allowed(string $section): bool { return in_array($section, cms_allowed_sections(), true); }

function cms_csrf(): string {
    if (empty($_SESSION['cms_csrf'])) $_SESSION['cms_csrf'] = bin2hex(random_bytes(24));
    return $_SESSION['cms_csrf'];
}

function cms_check_csrf(): void {
    if (!hash_equals((string)($_SESSION['cms_csrf'] ?? ''), (string)($_POST['csrf'] ?? ''))) {
        http_response_code(403);
        exit('CSRF validation failed');
    }
}

function cms_e(string $s): string { return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function cms_redirect(string $section, string $msg = 'Gespeichert'): never {
    if (!cms_section_allowed($section)) $section = 'dashboard';
    header('Location: index.php?section=' . rawurlencode($section) . '&msg=' . rawurlencode($msg));
    exit;
}

function cms_log_activity(string $action, string $detail = ''): void {
    $rows = cms_json_read(CMS_ACTIVITY_FILE, []);
    array_unshift($rows, [
        'time' => date('c'),
        'user' => (string)(cms_user()['username'] ?? 'System'),
        'action' => $action,
        'detail' => $detail,
    ]);
    $rows = array_slice($rows, 0, 100);
    cms_json_write(CMS_ACTIVITY_FILE, $rows);
}

function cms_activity(int $limit = 10): array { return array_slice(cms_json_read(CMS_ACTIVITY_FILE, []), 0, max(1, $limit)); }

function cms_login(string $username, string $password): bool {
    foreach (cms_users() as $u) {
        if (strtolower((string)$u['username']) === strtolower(trim($username)) && !empty($u['active']) && password_verify($password, (string)$u['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['cms_user'] = [
                'username' => $u['username'],
                'role' => cms_is_superuser_name((string)$u['username']) ? 'owner' : 'staff',
            ];
            $_SESSION['cms_last'] = time();
            $_SESSION['cms_login_failures'] = 0;
            unset($_SESSION['cms_lock_until']);
            cms_log_activity('Anmeldung', 'Admin-Center geöffnet');
            return true;
        }
    }
    return false;
}

function cms_static_pages(): array {
    $files = glob(__DIR__ . '/../*.html') ?: [];
    $out = [];
    foreach ($files as $f) {
        $name = basename($f);
        $html = (string)file_get_contents($f);
        preg_match('/<title>(.*?)<\/title>/is', $html, $m);
        $title = html_entity_decode(strip_tags($m[1] ?? $name), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $title = preg_replace('/\s*[|–-]\s*Fahrschule BV.*$/iu', '', trim($title)) ?: trim($title);
        if ($name === '404.html') $title = '404 / Seite nicht gefunden';
        if ($name === 'danke.html') $title = 'Danke – Anmeldung';
        if ($name === 'danke-kontakt.html') $title = 'Danke – Kontakt';
        $out[$name] = $title;
    }
    asort($out);
    return $out;
}

function cms_page_map(): array {
    return cms_json_read(CMS_PAGE_MAP_FILE, ['pages'=>[]]);
}

function cms_page_editor_items(string $page): array {
    $safe = basename($page);
    $map = cms_page_map();
    $rows = $map['pages'][$safe]['items'] ?? [];
    return is_array($rows) ? $rows : [];
}

function cms_extract_editables(string $page): array {
    $safe = basename($page);
    $file = __DIR__ . '/../' . $safe;
    if (!is_file($file)) return [];
    $html = (string)file_get_contents($file);
    $out = [];
    if (preg_match_all('/<(h1|h2|h3|p|li|small|strong|a|span)\b([^>]*\bdata-cms-id="([^"]+)"[^>]*)>(.*?)<\/\1>/is', $html, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $m) {
            $href = '';
            if (strtolower($m[1]) === 'a' && preg_match('/\bhref="([^"]*)"/i', $m[2], $hm)) {
                $href = html_entity_decode($hm[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
            }
            $out[] = [
                'id' => $m[3],
                'tag' => strtolower($m[1]),
                'text' => trim(html_entity_decode(strip_tags($m[4]), ENT_QUOTES | ENT_HTML5, 'UTF-8')),
                'href' => $href,
            ];
        }
    }
    return $out;
}

function cms_registrations(): array {
    $root = __DIR__ . '/../private_uploads';
    $rows = [];
    foreach (glob($root . '/*/anmeldung.json') ?: [] as $f) {
        $r = json_decode((string)file_get_contents($f), true);
        if (is_array($r)) { $r['_dir'] = basename(dirname($f)); $rows[] = $r; }
    }
    usort($rows, fn($a,$b) => strcmp((string)($b['received_at'] ?? ''), (string)($a['received_at'] ?? '')));
    return $rows;
}

function cms_messages(): array {
    $root = __DIR__ . '/../private_messages';
    $rows = [];
    foreach (glob($root . '/*.json') ?: [] as $f) {
        $r = json_decode((string)file_get_contents($f), true);
        if (is_array($r)) { $r['_file'] = basename($f); $rows[] = $r; }
    }
    usort($rows, fn($a,$b) => strcmp((string)($b['received_at'] ?? ''), (string)($a['received_at'] ?? '')));
    return $rows;
}

function cms_status(): array { return cms_json_read(CMS_STATUS_FILE, ['registrations'=>[], 'messages'=>[]]); }
function cms_save_status(array $s): void { cms_json_write(CMS_STATUS_FILE, $s); }
function cms_slug(string $s): string { $s = iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$s) ?: $s; $s = strtolower(preg_replace('/[^a-zA-Z0-9]+/','-',$s) ?? ''); return trim($s,'-'); }
function cms_safe_media_name(string $name): string { $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION)); return date('YmdHis') . '-' . bin2hex(random_bytes(4)) . ($ext ? '.' . $ext : ''); }
function cms_digits(string $value): string { return preg_replace('/\D+/', '', $value) ?? ''; }
function cms_status_key(string $status): string { return strtolower(str_replace([' ', 'ä', 'ö', 'ü'], ['-', 'a', 'o', 'u'], $status)); }
