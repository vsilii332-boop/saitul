<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
require_once __DIR__ . '/access-data.php';
if (isset($_GET['editor_page'])) {
    require_once __DIR__ . '/lib.php';
    if (!cms_is_owner()) { http_response_code(403); echo '{}'; exit; }
    $key = (string)$_GET['editor_page'];
    if (!isset(cms_page_registry()[$key])) { http_response_code(404); echo '{}'; exit; }
    $data = cms_public_site(cms_site());
    $private = cms_site();
    foreach ($private['customPages'] ?? [] as $page) if ('custom:'.$page['id'] === $key && empty($page['active'])) $data['customPages'][] = $page;
    foreach (['visualEditor','seo','content','blocks','pageEditor'] as $bucket) if (isset($private[$bucket][$key])) $data[$bucket][$key] = $private[$bucket][$key];
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit;
}
$file = __DIR__ . '/../assets/data/site-config.json';
if (!is_file($file)) $file = __DIR__ . '/../private_admin/site.json';
if (!is_file($file)) {
    echo '{}';
    exit;
}
$raw = @file_get_contents($file);
$data = $raw !== false ? json_decode($raw, true) : null;
echo json_encode(cms_public_site(is_array($data) ? $data : []), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
