<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
cms_require_login();
if (!cms_section_allowed('analytics')) { http_response_code(403); exit; }
require __DIR__ . '/analytics-lib.php';
$month = (string)($_GET['month'] ?? bv_stats_month());
if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/D', $month)) { http_response_code(400); exit; }
$data = bv_stats_read($month);
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="statistik-' . $month . '.csv"');
header('Cache-Control: no-store');
$out = fopen('php://output','w'); fwrite($out,"\xEF\xBB\xBF");
fputcsv($out,['Besucher-ID','Erster Besuch','Letzter Besuch','Sitzungen','Aufrufe','Quelle','Gerät','Browser','Land','Sprache','Zeitzone','Seiten'],';');
foreach (($data['visitor_details'] ?? []) as $v) {
    $pages=[]; foreach(($v['pages']??[]) as $p=>$n) $pages[]=$p.' x'.$n;
    fputcsv($out,[
        $v['id']??'', $v['first_seen']??'', $v['last_seen']??'', $v['sessions']??0, $v['views']??0,
        $v['source']??'', $v['device']??'', $v['browser']??'', $v['country']??'', $v['language']??'', $v['timezone']??'', implode(' | ',$pages)
    ],';');
}
fclose($out);
