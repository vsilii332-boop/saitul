<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
require __DIR__ . '/editor-lib.php';
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');
if (!cms_logged_in() || !cms_section_allowed('pages')) { http_response_code(403); echo json_encode(['error'=>'Bitte erneut anmelden.']); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo '{}'; exit; }
if (empty($_SESSION['cms_csrf']) || empty($_POST['csrf'])) { http_response_code(403); echo json_encode(['error'=>'Sitzung abgelaufen. Bitte die Seite neu laden.']); exit; }
cms_check_csrf();
try {
    $page = (string)($_POST['page'] ?? '');
    if (!isset(cms_static_pages()[$page])) throw new InvalidArgumentException('Diese Seite wurde nicht gefunden.');
    $raw = (string)($_POST['changes'] ?? '');
    if (strlen($raw) > 2 * 1024 * 1024) throw new InvalidArgumentException('Zu viele Änderungen. Bitte in kleineren Schritten speichern.');
    $changes = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
    if (!is_array($changes) || !$changes || count($changes) > 2000) throw new InvalidArgumentException('Keine gültigen Änderungen übermittelt.');
    $site = cms_site();
    if ((string)($_POST['version'] ?? '') !== (string)($site['_meta']['version'] ?? 0)) {
        http_response_code(409);
        echo json_encode(['error'=>'Die Website wurde inzwischen geändert. Bitte Ihre Texte sichern, die Seite neu laden und erneut bearbeiten.']); exit;
    }
    $saved = (array)($site['visualEditor'][$page] ?? []);
    foreach ($changes as $row) {
        if (!is_array($row)) throw new InvalidArgumentException('Ungültige Änderung.');
        $entry = cms_editor_change($row);
        $saved[cms_editor_key($entry)] = $entry;
    }
    $site['visualEditor'][$page] = $saved;
    cms_save_site($site);
    cms_log_activity('Seite visuell bearbeitet', $page);
    echo json_encode(['ok'=>true, 'version'=>(int)($site['_meta']['version'] ?? 0)+1]);
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['error'=>$e instanceof InvalidArgumentException ? $e->getMessage() : 'Speichern fehlgeschlagen. Bitte erneut versuchen und die Schreibrechte prüfen.']);
}
