(() => {
  'use strict';
  const root = document.querySelector('.home-slideshow');
  if (!root) return;
  const slides = [...root.querySelectorAll('.home-slide')];
  const controls = root.querySelector('.home-slide-controls');
  if (controls) controls.remove();
  // A selected slide must remain still while editing its text or photos.
  if (window.self !== window.top && new URLSearchParams(location.search).has('editor-preview')) return;
  if (slides.length < 2) return;
  let current = Math.max(0, slides.findIndex(slide => slide.classList.contains('is-active')));
  let timer;
  const schedule = () => {
    clearTimeout(timer);
    if (!document.hidden) timer = setTimeout(advance, 6000);
  };
  function advance() {
    // Avoid leaving keyboard focus inside an invisible slide.
    if (slides[current].contains(document.activeElement)) document.activeElement.blur();
    current = (current + 1) % slides.length;
    slides.forEach((slide, index) => {
      const active = index === current;
      slide.classList.toggle('is-active', active);
      slide.setAttribute('aria-hidden', String(!active));
      slide.inert = !active;
    });
    schedule();
  }
  document.addEventListener('visibilitychange', schedule);
  schedule();
})();
