(() => {
  'use strict';
  const script = document.currentScript;
  const node = (tag, className, text) => { const el=document.createElement(tag);if(className)el.className=className;if(text!==undefined)el.textContent=text;return el; };
  const safeUrl = value => {const url=String(value||'').trim();return /[\x00-\x20\x7f]/.test(url) || (/^[a-z][a-z0-9+.-]*:/i.test(url)&&!/^(https?:\/\/|mailto:|tel:)/i.test(url)) ? '#' : url||'#';};
  const pageName = () => document.documentElement.dataset.cmsPage || location.pathname.split('/').pop() || 'index.html';
  const matches = (item,page=pageName()) => item.targets?.mode==='all' || (item.targets?.mode==='home'&&page==='index.html') || (item.targets?.mode==='selected'&&item.targets.pages?.includes(page));
  const eligible = (item,now) => item.active && (item.startAt==null||now>=item.startAt) && (item.endAt==null||now<item.endAt) && matches(item);
  const berlinDay = time => new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Berlin',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(time));
  const countdown = (end,now) => {
    const total=Math.max(0,Math.ceil(((end??now)-now)/1000));
    return {total,parts:[Math.floor(total/86400),Math.floor(total/3600)%24,Math.floor(total/60)%60,total%60]};
  };
  function berlinTime(value) {
    if(!value)return null;
    const parts=String(value).match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/);if(!parts)return null;
    const wanted=Date.UTC(...[Number(parts[1]),Number(parts[2])-1,Number(parts[3]),Number(parts[4]),Number(parts[5])]);
    const format=new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Berlin',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
    const candidates=[wanted-3600000,wanted-7200000].filter(time=>format.format(new Date(time)).replace(' ','T')===value);
    return candidates.length?Math.max(...candidates):null;
  }
  function popupVisual(item,now=Date.now,doc=document) {
    const root=doc.createElement('div');root.className='bv-popup-visual';
    const figure=doc.createElement('figure');figure.className='bv-popup-figure';
    const image=doc.createElement('img');image.className='bv-popup-image';image.alt='Aktuelles Angebot der Fahrschule BV';
    if(item.image)image.src=item.image;else {const empty=doc.createElement('p');empty.className='bv-promo-empty';empty.textContent='Ein Bild hochladen, um die Vorschau zu sehen.';figure.append(empty);}
    if(item.image)figure.append(image);root.append(figure);
    let interval,timerHolder;root.style.setProperty('--bv-below-offset',`${item.countdown?.enabled&&item.countdown.placement!=='overlay'?Number(item.countdown.offset)||0:0}px`);
    if(item.countdown?.enabled) {
      const counter=item.countdown;const holder=doc.createElement('div');holder.className=`bv-timer-slot bv-timer-${counter.placement||'below'} bv-timer-${counter.align||'center'}`;
      timerHolder=holder;
      holder.style.setProperty('--bv-timer-offset',`${Math.max(0,Math.min(200,Number(counter.offset)||0))}px`);
      const clock=doc.createElement('div');clock.className='bv-countdown';clock.setAttribute('aria-live','off');
      const digits=[];['TAGE','STD','MIN','SEK'].forEach((label,index)=>{
        if(index){const colon=doc.createElement('span');colon.className='bv-clock-colon';colon.textContent=':';colon.setAttribute('aria-hidden','true');clock.append(colon);}
        const group=doc.createElement('span');group.className='bv-clock-group';const value=doc.createElement('b');value.textContent='00';const caption=doc.createElement('small');caption.textContent=label;group.append(value,caption);clock.append(group);digits.push(value);
      });holder.append(clock);(counter.placement==='overlay'?figure:root).append(holder);
      if(counter.placement!=='overlay')root.classList.add('bv-popup-has-below');
      const tick=()=>{const remaining=countdown(counter.endAt,now());digits.forEach((digit,index)=>digit.textContent=String(remaining.parts[index]).padStart(2,'0'));clock.dataset.remaining=String(remaining.total);clock.setAttribute('aria-label',`${remaining.parts[0]} Tage, ${remaining.parts[1]} Stunden, ${remaining.parts[2]} Minuten, ${remaining.parts[3]} Sekunden verbleibend`);};
      tick();interval=setInterval(tick,1000);
    }
    const observer=new ResizeObserver(()=>{
      const width=image.getBoundingClientRect().width;root.style.setProperty('--bv-popup-width',`${width||400}px`);
      // A tiny image cannot contain a readable clock: keep its pixels intact and use the space below.
      if(width>0&&width<195&&timerHolder?.classList.contains('bv-timer-overlay')) {
        timerHolder.classList.replace('bv-timer-overlay','bv-timer-below');root.classList.add('bv-popup-has-below');root.style.setProperty('--bv-below-offset',`${Number(item.countdown.offset)||0}px`);root.append(timerHolder);
      }
    });
    observer.observe(image);
    return {element:root,destroy:()=>{clearInterval(interval);observer.disconnect();}};
  }
  function openPopup(item,onClose=()=>{},now=Date.now) {
    const previous=document.activeElement;
    const dialog=node('dialog','bv-popup-dialog');dialog.dataset.popupId=item.id||'preview';dialog.setAttribute('aria-label','Aktuelles Angebot');
    const bar=node('div','bv-popup-closebar');const close=node('button','bv-popup-close','×');close.type='button';close.setAttribute('aria-label','Pop-up schließen');bar.append(close);
    const visual=popupVisual(item,now);dialog.append(bar,visual.element);document.body.append(dialog);
    let finished=false;
    const finish=()=>{if(finished)return;finished=true;visual.destroy();if(dialog.open)dialog.close();dialog.remove();previous?.isConnected&&previous.focus?.();onClose();};
    close.addEventListener('click',finish);dialog.addEventListener('keydown',event=>{if(event.key==='Tab'){event.preventDefault();close.focus();}});dialog.addEventListener('cancel',event=>{event.preventDefault();finish();});dialog.addEventListener('close',finish);
    dialog.addEventListener('click',event=>{if(event.target===dialog)finish();});
    dialog.showModal();close.focus();return {close:finish,dialog};
  }
  function actionCard(item) {
    const section=node('section','bv-action');section.dataset.bvAction=item.id||'preview';
    section.style.setProperty('--bv-action-bg',item.background||'#14191f');section.style.setProperty('--bv-action-text',item.textColor||'#f6f7f8');section.style.setProperty('--bv-action-button',item.buttonColor||'#f47a20');
    section.style.setProperty('--bv-action-padding',`${item.padding??32}px`);section.style.setProperty('--bv-action-gap',`${item.gap??24}px`);section.style.setProperty('--bv-action-radius',`${item.radius??18}px`);
    section.dataset.layout=item.layout||'left';section.dataset.align=item.align||'left';
    const inner=node('div','bv-action-inner');const copy=node('div','bv-action-copy');
    if(item.title){const heading=node('h2','bv-action-title',item.title);copy.append(heading);section.setAttribute('aria-label',item.title);}
    if(item.offer)copy.append(node('p','bv-action-offer',item.offer));
    if(item.description)copy.append(node('p','bv-action-description',item.description));
    if(item.originalPrice||item.price){const prices=node('div','bv-action-prices');if(item.originalPrice)prices.append(node('del','',item.originalPrice));if(item.price)prices.append(node('strong','',item.price));copy.append(prices);}
    const buttons=node('div','bv-action-buttons');for(const data of item.buttons||[]){if(!data.text)continue;const link=node('a','bv-action-button',data.text);link.href=safeUrl(data.url);buttons.append(link);}if(buttons.childNodes.length)copy.append(buttons);
    if(item.images?.length){const media=node('div','bv-action-media');for(const path of item.images){const image=node('img','');image.src=path;image.alt=item.title||'Aktuelles Angebot';image.loading='lazy';media.append(image);}inner.append(media);}else section.classList.add('bv-action-text-only');
    inner.append(copy);section.append(inner);return section;
  }
  const campaignKey = item => `bv-promotion:${item.id}:${item.startAt??''}:${item.endAt??''}`;
  class PopupQueue {
    constructor(now=Date.now){this.now=now;this.items=[];this.shown=new Set();this.fallback=new Map();this.current=null;}
    read(storage,key){try{return storage.getItem(key);}catch(_){return this.fallback.get(key)||null;}}
    write(storage,key,value){try{storage.setItem(key,value);}catch(_){this.fallback.set(key,value);}}
    documentKey(item){return campaignKey(item)+(item.frequency==='daily'?':'+berlinDay(this.now()):'');}
    seen(item){const key=campaignKey(item);if(this.shown.has(this.documentKey(item)))return true;
      if(item.frequency==='session'){try{return this.read(sessionStorage,key)==='1';}catch(_){return this.fallback.get(key)==='1';}}
      if(item.frequency==='daily'){try{return this.read(localStorage,key)===berlinDay(this.now());}catch(_){return this.fallback.get(key)===berlinDay(this.now());}}
      if(item.frequency==='expiry'){try{return this.read(localStorage,key)==='1';}catch(_){return this.fallback.get(key)==='1';}}
      return false;
    }
    mark(item){const key=campaignKey(item);this.shown.add(this.documentKey(item));try{if(item.frequency==='session')this.write(sessionStorage,key,'1');if(item.frequency==='daily')this.write(localStorage,key,berlinDay(this.now()));if(item.frequency==='expiry')this.write(localStorage,key,'1');}catch(_){this.fallback.set(key,item.frequency==='daily'?berlinDay(this.now()):'1');}}
    update(items){this.items=[...items].sort((a,b)=>(b.priority-a.priority)||a.id.localeCompare(b.id));this.advance();}
    advance(){
      if(this.current){const live=this.items.find(item=>item.id===this.current.item.id);if(live&&eligible(live,this.now()))return;this.current.close();return;}
      const item=this.items.find(item=>eligible(item,this.now())&&!this.seen(item));if(!item)return;
      this.mark(item);const shown=openPopup(item,()=>{this.mark(item);this.current=null;queueMicrotask(()=>this.advance());},this.now);this.current={item,...shown};
    }
    destroy(){this.items=[];this.current?.close();this.current=null;}
  }
  function insertActions(items,now=Date.now,preview=null) {
    document.querySelectorAll('[data-bv-action-slot]').forEach(slot=>slot.remove());
    const entries=items.filter(item=>item.id!==preview?.id&&eligible(item,now()));if(preview)entries.push(preview);
    entries.sort((a,b)=>(a.order-b.order)||(a.id||'').localeCompare(b.id||''));
    const slots=new Map();
    for(const item of entries){
      const position=item.placements?.[pageName()]||item.placement||'after-hero';let slot=slots.get(position);
      if(!slot){slot=node('div','bv-action-slot');slot.dataset.bvActionSlot=position;const footer=document.querySelector('footer,.footer');
        if(position==='before-footer'&&footer)footer.before(slot);
        else {let anchor=null;if(position.startsWith('after:'))anchor=[...document.querySelectorAll('[data-cms-section]')].find(el=>el.dataset.cmsSection===position.slice(6));else anchor=document.querySelector('.hero,.page-hero');
          if(anchor)anchor.after(slot);else if(footer)footer.before(slot);else{const firstScript=[...document.body.children].find(el=>el.tagName==='SCRIPT');if(firstScript)firstScript.before(slot);else document.body.append(slot);}}
        slots.set(position,slot);
      }
      slot.append(actionCard(item));
    }
    if(preview){
      const selected=[...document.querySelectorAll('[data-bv-action]')].find(el=>el.dataset.bvAction===preview.id);
      const reveal=()=>{if(selected)window.scrollTo({top:Math.max(0,selected.getBoundingClientRect().top+window.scrollY-Math.max(20,(innerHeight-selected.offsetHeight)/2)),behavior:'instant'});};
      requestAnimationFrame(reveal);selected?.querySelectorAll('img').forEach(image=>image.addEventListener('load',reveal,{once:true}));
    }
  }
  const api={countdown,berlinTime,popupVisual,openPopup,actionCard,matches,eligible,PopupQueue,insertActions};window.BVPromotions=api;
  if(location.pathname.includes('/admin/'))return;
  const params=new URLSearchParams(location.search);const embedded=window.self!==window.top;
  // The existing page editor keeps its original DOM paths and never opens public pop-ups.
  if(embedded&&!params.has('promo-preview'))return;
  let data={popups:[],actions:[]},delta=0,lastActions='',previewDraft=null;
  const now=()=>Date.now()+delta;
  const queue=new PopupQueue(now);
  const render=()=>{
    const eligibleActions=data.actions.filter(item=>eligible(item,now()));const signature=JSON.stringify([eligibleActions,previewDraft]);
    if(signature!==lastActions){lastActions=signature;insertActions(data.actions,now,previewDraft);}
    if(!embedded)queue.advance();
  };
  const fetchData=async()=>{try{
    const endpoint=new URL('../../admin/promotions-public.php',script.src);const response=await fetch(endpoint,{cache:'no-store',credentials:'omit'});if(!response.ok)return;
    const payload=await response.json();if(!Array.isArray(payload.popups)||!Array.isArray(payload.actions))return;
    data=payload;delta=Number.isFinite(payload.serverTime)?payload.serverTime-Date.now():0;
    if(!embedded)queue.update(data.popups);render();
  }catch(_){/* A temporary promotions outage never blocks the rest of the website. */}};
  if(embedded&&params.has('promo-preview'))window.addEventListener('message',event=>{
    if(event.source!==parent||event.origin!==location.origin||event.data?.type!=='bv:promo-preview')return;
    previewDraft=event.data.item||null;render();
  });
  const start=()=>{fetchData();window.dispatchEvent(new CustomEvent('bv:promotions-ready'));};
  if(window.bvSiteConfig)start();else document.addEventListener('bv:cms-ready',start,{once:true});
  const timer=setInterval(render,1000);const poll=setInterval(fetchData,30000);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden){render();fetchData();}});
  window.addEventListener('pagehide',()=>{clearInterval(timer);clearInterval(poll);queue.destroy();});
})();
