const menu=document.querySelector('.menu');const nav=document.querySelector('.navlinks');if(menu&&nav){menu.type='button';const closeMenu=()=>{nav.classList.remove('open');menu.classList.remove('is-open');menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-label','Menü öffnen');menu.textContent='☰';document.body.classList.remove('mobile-menu-open')};const openMenu=()=>{nav.classList.add('open');menu.classList.add('is-open');menu.setAttribute('aria-expanded','true');menu.setAttribute('aria-label','Menü schließen');menu.textContent='×';document.body.classList.add('mobile-menu-open')};menu.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();nav.classList.contains('open')?closeMenu():openMenu()});nav.addEventListener('click',event=>event.stopPropagation());nav.querySelectorAll('a').forEach(link=>link.addEventListener('click',closeMenu));document.addEventListener('keydown',event=>{if(event.key==='Escape')closeMenu()});document.addEventListener('click',event=>{if(nav.classList.contains('open')&&!nav.contains(event.target)&&!menu.contains(event.target))closeMenu()});window.addEventListener('resize',()=>{if(window.innerWidth>980)closeMenu()})}
document.querySelectorAll('.gallery img').forEach(img=>img.addEventListener('click',()=>{const lb=document.querySelector('.lightbox');lb.querySelector('img').src=img.src;lb.classList.add('open')}));
const lb=document.querySelector('.lightbox');if(lb){lb.addEventListener('click',e=>{if(e.target===lb||e.target.tagName==='BUTTON')lb.classList.remove('open')});document.addEventListener('keydown',e=>{if(e.key==='Escape')lb.classList.remove('open')})}
const cf=document.querySelector('form[data-contact-form]');if(cf){cf.addEventListener('submit',()=>{const button=cf.querySelector('button[type="submit"]');const status=cf.querySelector('.form-status');if(button){button.disabled=true;button.textContent='WIRD GESENDET…'}if(status){status.textContent='Ihre Nachricht wird übertragen…';status.style.color='#cfcfd4'}})}
document.querySelectorAll('form[data-registration-form]').forEach(f=>f.addEventListener('submit',e=>{const files=[...f.querySelectorAll('input[type="file"]')].flatMap(input=>[...input.files]);const total=files.reduce((sum,file)=>sum+file.size,0);const maxMb=Math.max(1,Number(f.dataset.maxUploadMb||8));const status=f.querySelector('.form-status');if(total>maxMb*1024*1024){e.preventDefault();if(status){status.textContent=`Die Dateien sind zusammen größer als ${maxMb} MB. Bitte kleinere Dateien auswählen.`;status.style.color='#ff983f'}return}const button=f.querySelector('button[type="submit"]');if(button){button.disabled=true;button.textContent='WIRD GESENDET…'}if(status){status.textContent='Ihre Anmeldung wird sicher übertragen…';status.style.color='#cfcfd4'}}));

// V3.5 price table filter
document.querySelectorAll('.price-filter-btn').forEach(btn=>{btn.addEventListener('click',()=>{const group=btn.dataset.priceGroup;document.querySelectorAll('.price-filter-btn').forEach(b=>b.classList.toggle('active',b===btn));document.querySelectorAll('.price-matrix [data-group]').forEach(cell=>cell.classList.toggle('price-col-hidden',group!=='all'&&cell.dataset.group!==group));});});

// Smartphone price view: one license class at a time, without horizontal scrolling.
window.buildMobilePriceCards=()=>{
  const table=document.querySelector('.price-matrix');
  const host=document.querySelector('[data-mobile-prices]');
  if(!table||!host)return;
  const escapeHtml=value=>String(value).replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const headers=[...table.querySelectorAll('thead th')].slice(1);
  const rows=[...table.querySelectorAll('tbody tr')];
  const previous=host.querySelector('select')?.value||'B';
  const classes=headers.map((header,index)=>({
    index,
    name:header.textContent.trim(),
    href:header.querySelector('a')?.getAttribute('href')||'angebote.html',
    group:header.dataset.group||'auto'
  }));
  host.innerHTML='<div class="mobile-price-picker"><label for="mobile-price-class">Führerscheinklasse auswählen</label><select id="mobile-price-class"></select></div><article class="mobile-price-card" data-mobile-price-card></article>';
  const select=host.querySelector('select');
  const auto=document.createElement('optgroup');auto.label='Auto & Anhänger';
  const moto=document.createElement('optgroup');moto.label='Motorrad & Roller';
  classes.forEach(item=>{const option=document.createElement('option');option.value=item.name;option.textContent=`Klasse ${item.name}`;(item.group==='moto'?moto:auto).appendChild(option)});
  select.append(auto,moto);
  select.value=classes.some(item=>item.name===previous)?previous:(classes.some(item=>item.name==='B')?'B':classes[0]?.name||'');
  const render=()=>{
    const item=classes.find(entry=>entry.name===select.value)||classes[0];
    if(!item)return;
    const prices=rows.map(row=>({label:row.querySelector('th')?.textContent.trim()||'',value:row.querySelectorAll('td')[item.index]?.textContent.trim()||'–'}));
    const safeHref=/^(?:[a-z0-9._/-]+\.html(?:[?#].*)?|#.*)$/i.test(item.href)?item.href:'angebote.html';
    host.querySelector('[data-mobile-price-card]').innerHTML=`<header><div><span>Ausgewählte Klasse</span><h3>Klasse ${escapeHtml(item.name)}</h3></div><a href="${escapeHtml(safeHref)}">Klassendetails →</a></header><div class="mobile-price-rows">${prices.map(price=>`<div class="mobile-price-row${price.value==='–'?' is-empty':''}"><span>${escapeHtml(price.label)}</span><strong>${escapeHtml(price.value)}</strong></div>`).join('')}</div>`;
    host.querySelectorAll('.mobile-price-row strong').forEach((element,index)=>{
      element.bvPriceBinding = rows[index]?.querySelectorAll('td')[item.index]?.bvPriceBinding;
    });
  };
  select.addEventListener('change',render);render();
};
window.buildMobilePriceCards();
// Optional course announcement on the homepage. Its content and visibility are
// controlled from site-config.js so the homepage markup does not need editing.
const summerCourseBlock = document.querySelector('#summer-course-block');
if (summerCourseBlock) {
  const summerCourseConfig = window.FAHRSCHULE_CONFIG?.summerCourse;

  if (summerCourseConfig?.enabled) {
    const setSummerCourseText = (selector, value) => {
      const element = document.querySelector(selector);
      if (element && typeof value === 'string') element.textContent = value;
    };

    setSummerCourseText('#summer-course-label', summerCourseConfig.label);
    setSummerCourseText('#summer-course-title', summerCourseConfig.title);

    summerCourseConfig.courses?.slice(0, 2).forEach((course, index) => {
      const number = index + 1;
      setSummerCourseText(`#summer-course-${number}-label`, course.label);
      setSummerCourseText(`#summer-course-${number}-date`, course.date);
      setSummerCourseText(`#summer-course-${number}-time`, course.time);
    });

    const summerCourseButton = document.querySelector('#summer-course-button');
    if (summerCourseButton) {
      setSummerCourseText('#summer-course-button', summerCourseConfig.buttonText);
      if (typeof summerCourseConfig.buttonLink === 'string') {
        summerCourseButton.href = summerCourseConfig.buttonLink;
      }
    }

    summerCourseBlock.hidden = false;
  } else {
    summerCourseBlock.hidden = true;
  }
}

// BV Analytics V2 — statistici anonime, fara cookie/localStorage.
(() => {
  if (window.__bvVisitSent || window.self !== window.top || new URLSearchParams(location.search).has('preview')) return;
  window.__bvVisitSent = true;

  const sendVisit = () => {
    let path = location.pathname || '/';
    if (path === '/custom-page.php') {
      const slug = new URLSearchParams(location.search).get('slug') || '';
      path = '/custom-page.php?slug=' + slug;
    }

    let refHost = '';
    try { refHost = document.referrer ? new URL(document.referrer).hostname : ''; } catch (_) {}

    const query = new URLSearchParams(location.search);
    const body = new URLSearchParams({
      path,
      ref: refHost,
      lang: navigator.language || '',
      tz: Intl.DateTimeFormat().resolvedOptions().timeZone || '',
      utm_source: query.get('utm_source') || '',
      utm_medium: query.get('utm_medium') || '',
      utm_campaign: query.get('utm_campaign') || ''
    });

    fetch('/visit.php?v=2', {
      method: 'POST',
      body,
      credentials: 'omit',
      keepalive: true,
      headers: {'X-BV-Analytics': '2'}
    }).catch(() => {});
  };

  if (document.visibilityState === 'visible') sendVisit();
  else document.addEventListener('visibilitychange', function onVisible() {
    if (document.visibilityState === 'visible') {
      document.removeEventListener('visibilitychange', onVisible);
      sendVisit();
    }
  });
})();

// 2026-09-20 V2 — normalize footer credit/logo on every public page.
(() => {
  const applyFooterFix = () => {
    const footer = document.querySelector('.footer');
    if (!footer) return;

    // Always show the creator credit, even on a page whose older HTML missed it.
    let note = footer.querySelector('.footer-note');
    if (!note) {
      note = document.createElement('div');
      note.className = 'container footer-note';
      footer.appendChild(note);
    }

    let owner = note.querySelector('.footer-owner');
    if (!owner) {
      owner = document.createElement('span');
      owner.className = 'footer-owner';
      owner.textContent = '© 2026 Fahrschule BV · Inhaber Vitali Bek';
      note.prepend(owner);
    }

    let creator = note.querySelector('.footer-creator');
    if (!creator) {
      creator = document.createElement('span');
      creator.className = 'footer-creator';
      creator.textContent = 'Webdesign & Entwicklung: Vladimir Sili';
      note.appendChild(creator);
    }

    // Make the footer logo reliably tappable on phone/tablet and always go home.
    const footerLogo = footer.querySelector('img[alt="Fahrschule BV"]') || footer.querySelector('img');
    if (footerLogo) {
      let link = footerLogo.closest('a');
      if (!link) {
        link = document.createElement('a');
        footerLogo.parentNode.insertBefore(link, footerLogo);
        link.appendChild(footerLogo);
      }
      link.classList.add('footer-brand-link');
      link.href = '/';
      link.setAttribute('aria-label', 'Zur Startseite');
    }

    // Header logo should also always return to the homepage.
    const headerBrand = document.querySelector('.header .brand');
    if (headerBrand && headerBrand.tagName === 'A') headerBrand.setAttribute('href', '/');
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', applyFooterFix, {once:true});
  else applyFooterFix();
})();
