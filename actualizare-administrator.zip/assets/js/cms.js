(() => {
  const page = location.pathname.split('/').pop() || 'index.html';
  const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const nl = value => esc(value).replace(/\n/g, '<br>');
  const cmsScript = document.currentScript || [...document.scripts].find(script => /assets\/js\/cms\.js(?:\?|$)/.test(script.src));
  const cmsEndpoint = cmsScript ? new URL('../../admin/public-data.php', cmsScript.src) : new URL('admin/public-data.php', document.baseURI);
  const cmsSnapshot = cmsScript ? new URL('../data/site-config.json', cmsScript.src) : new URL('assets/data/site-config.json', document.baseURI);
  cmsEndpoint.searchParams.set('v', String(Date.now()));
  cmsSnapshot.searchParams.set('v', String(Date.now()));
  const loadCms = async () => {
    for (const url of [cmsEndpoint, cmsSnapshot]) {
      try {
        const response = await fetch(url, {cache: 'no-store', credentials: 'same-origin'});
        if (response.ok) return await response.json();
      } catch (_) {}
    }
    throw new Error('CMS configuration unavailable');
  };

  loadCms()
    .then(cms => {
      applyTheme(cms.theme || {});
      applyContactData(cms.general || {});
      applyGlobalText(cms.general || {});
      applyNavigation(cms);
      applyEditableContent((cms.content || {})[page] || {});
      applySeo((cms.seo || {})[page]);
      applyForms(cms.forms || {});
      if (page === 'index.html' || page === '') {
        applyHomepage(cms.homepage || {});
        applySummerCourse(cms.summerCourse);
        applyBanners(cms.banners || []);
      }
      if (page === 'fahrschule.html') applyTeam(cms.team || []);
      if (page === 'galerie.html' && Object.prototype.hasOwnProperty.call(cms, 'gallery')) applyGallery(cms.gallery);
      if (page === 'preisliste.html') applyPrices(cms.prices || {});
      renderBlocks((cms.blocks || {})[page] || []);
      applyPageEditorOverrides((cms.pageEditor || {})[page] || {});
      const visualChanges = Object.values((cms.visualEditor || {})[page] || {});
      const visualTargets = new Map();let visualImageId=0;
      const applyVisualChanges = () => {
        if (window.bvEditorPreview) return;
        visualChanges.forEach(change => {
          try {
            let target = visualTargets.get(change.xpath);
            if (!target?.isConnected) {target=document.evaluate(change.xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;if(target)visualTargets.set(change.xpath,target);}
            if (!target || target.closest('script,style,noscript,iframe,object,embed,template')) return;
            if (change.type === 'metadata') {
              if(change.field==='title')document.title=change.value;
              if(change.field==='description') {
                let meta=document.querySelector('meta[name=description]');
                if(!meta){meta=document.createElement('meta');meta.name='description';document.head.append(meta);}
                meta.content=change.value;
              }
            } else if (change.type === 'text') {
              const node = [...target.childNodes].filter(node => node.nodeType === Node.TEXT_NODE)[change.index];
              if (node) {
                target.bvVisualTextSlots = target.bvVisualTextSlots || new Set();target.bvVisualTextSlots.add(change.index);
                if (node.nodeValue !== change.value) node.nodeValue = change.value;
              }
            } else if (change.type === 'attribute' && ['alt','title','placeholder','aria-label','href','value'].includes(change.attr)) {
              if (change.attr==='href' && (/^[a-z][a-z0-9+.-]*:/i.test(change.value) && !/^(https?:\/\/|mailto:|tel:)/i.test(change.value) || /[\x00-\x20\x7f]/.test(change.value))) return;
              if (target.getAttribute(change.attr) !== change.value) target.setAttribute(change.attr, change.value);
            } else if (change.type === 'image' && !/^(?:[a-z]+:|\/\/)/i.test(change.value)) {
              if (change.attr === 'background') {
                const url = new URL(change.value, document.baseURI).href;
                const background = getComputedStyle(target,change.pseudo || null).backgroundImage;
                const replacement = `url("${url}")`;
                const result = /url\(/.test(background) ? background.replace(/url\(["']?[^"')]+["']?\)/,replacement) : (background === 'none' ? replacement : `${background}, ${replacement}`);
                if (change.pseudo && ['::before','::after'].includes(change.pseudo)) {
                  if(!target.dataset.bvVisualImage)target.dataset.bvVisualImage='visual-'+(++visualImageId);
                  const selector = '[data-bv-visual-image="'+target.dataset.bvVisualImage+'"]'+change.pseudo;
                  let style = [...document.querySelectorAll('style[data-bv-visual-background]')].find(style=>style.dataset.bvVisualBackground===selector);
                  if (!style) {style=document.createElement('style');style.dataset.bvVisualBackground=selector;document.head.append(style);}
                  const rule = `${selector}{background-image:${result}!important}`;
                  if (style.textContent!==rule) style.textContent=rule;
                } else if (!target.style.backgroundImage.includes(url)) target.style.setProperty('background-image',result,'important');
              } else if (['src','srcset'].includes(change.attr) && target.getAttribute(change.attr) !== change.value) target.setAttribute(change.attr, change.value);
            }
          } catch (_) { /* A removed element does not prevent the rest of the page loading. */ }
        });
      };
      applyVisualChanges();
      if (visualChanges.length) {
        let updateTimer;
        new MutationObserver(() => {
          clearTimeout(updateTimer);
          updateTimer = setTimeout(applyVisualChanges, 50);
        }).observe(document.body, {childList:true, subtree:true});
      }
      window.bvSiteConfig = cms;
      if (!document.querySelector('script[data-bv-promotions]')) {
        const css=document.createElement('link');css.rel='stylesheet';css.href=new URL('../css/promotions.css?v=20261105-1',cmsScript.src).href;document.head.append(css);
        const runtime=document.createElement('script');runtime.dataset.bvPromotions='1';runtime.src=new URL('promotions.js?v=20261105-1',cmsScript.src).href;document.head.append(runtime);
      }
      document.documentElement.dataset.cmsReady = 'true';
      document.dispatchEvent(new CustomEvent('bv:cms-ready'));


      function applyTheme(theme) {
        const root = document.documentElement;
        if (theme.orange) root.style.setProperty('--orange', theme.orange);
        if (theme.orange2) root.style.setProperty('--orange2', theme.orange2);
        if (theme.black) root.style.setProperty('--black', theme.black);
        if (theme.text) root.style.setProperty('--text', theme.text);
        if (theme.font) document.body.style.fontFamily = theme.font;
        if (theme.base_size) root.style.fontSize = `${theme.base_size}px`;
      }

      function applyContactData(general) {
        const address = [general.address, general.postal_city].filter(Boolean).join(', ');
        const mapUrl = `https://maps.google.com/?q=${encodeURIComponent(address)}`;
        document.querySelectorAll('[data-cms-contact]').forEach(link => {
          const key = link.dataset.cmsContact;
          if (key === 'address') { link.textContent = address; link.href = mapUrl; }
          if (key === 'phone') { link.textContent = general.phone || ''; link.href = `tel:${general.phone_href || ''}`; }
          if (key === 'mobile') { link.textContent = general.mobile || ''; link.href = `tel:${general.mobile_href || ''}`; }
          if (key === 'email') { link.textContent = general.email || ''; link.href = `mailto:${general.email || ''}`; }
        });
        document.querySelectorAll('.footer h4').forEach(heading => {
          if (heading.textContent.trim() !== 'Kontakt') return;
          const links = [];
          let node = heading.nextElementSibling;
          while (node && node.tagName === 'A') { links.push(node); node = node.nextElementSibling; }
          if (links[0] && address) { links[0].innerHTML = `${esc(general.address || '')}<br>${esc(general.postal_city || '')}`; links[0].href = mapUrl; }
          if (links[1] && general.phone) { links[1].textContent = general.phone; links[1].href = `tel:${general.phone_href || ''}`; }
          if (links[2] && general.mobile) { links[2].textContent = general.mobile; links[2].href = `tel:${general.mobile_href || ''}`; }
          if (links[3] && general.email) { links[3].textContent = general.email; links[3].href = `mailto:${general.email}`; }
        });
        document.querySelectorAll('.contact-dock a[href*="wa.me"]').forEach(link => { if (general.whatsapp) link.href = `https://wa.me/${general.whatsapp}`; });
        document.querySelectorAll('.contact-dock a[href^="mailto:"]').forEach(link => { if (general.email) link.href = `mailto:${general.email}`; });
        document.querySelectorAll('.contact-dock a[href^="tel:"]').forEach(link => { if (general.phone_href) link.href = `tel:${general.phone_href}`; });
        const fields = [
          ['[data-cms-id="index-strong-3"]', general.office_hours],
          ['[data-cms-id="index-strong-4"]', general.theory_hours],
          ['[data-cms-id="index-strong-5"]', general.phone],
          ['[data-cms-id="index-strong-6"]', general.address],
          ['[data-cms-id="kontakt-strong-1"]', address],
          ['[data-cms-id="kontakt-strong-2"]', [general.phone, general.mobile].filter(Boolean).join(' · ')],
          ['[data-cms-id="kontakt-strong-3"]', general.email]
        ];
        fields.forEach(([selector, value]) => { const element = document.querySelector(selector); if (element && value) element.textContent = value; });
      }

      function applyGlobalText(general) {
        const footer = document.querySelector('.footer');
        if (footer) {
          const cols = [...footer.querySelectorAll('.footer-grid > div')];
          const tagline = cols[0]?.querySelector('p');
          if (tagline) tagline.textContent = general.footer_tagline || 'Deine Fahrschule in Lahr – persönlich, modern und transparent.';

          const setHeading = (col, index, value) => {
            const h = cols[col]?.querySelectorAll('h4')?.[index];
            if (h && value) h.textContent = value;
          };
          setHeading(1, 0, general.footer_contact_title || 'Kontakt');
          setHeading(2, 0, general.footer_school_title || 'Fahrschule');
          setHeading(2, 1, general.footer_forms_title || 'Wichtige Formulare');
          setHeading(3, 0, general.footer_legal_title || 'Rechtliches');

          const applyLinks = (column, rows) => {
            const links = [...(cols[column]?.querySelectorAll('a') || [])];
            rows.forEach((row, index) => {
              const link = links[index];
              if (!link) return;
              if (row.label) link.textContent = row.label;
              if (row.href) link.setAttribute('href', row.href);
            });
          };
          applyLinks(2, [
            {label:general.footer_licenses_label || 'Führerscheinklassen', href:general.footer_licenses_href || 'angebote.html'},
            {label:general.footer_motorcycle_label || 'Motorradkurs', href:general.footer_motorcycle_href || 'motorradkurs.html'},
            {label:general.footer_prices_label || 'Preisliste', href:general.footer_prices_href || 'preisliste.html'},
            {label:general.footer_calendar_label || 'Unterrichtskalender', href:general.footer_calendar_href || 'calendar.html'},
            {label:general.footer_registration_label || 'Online Anmeldung', href:general.footer_registration_href || 'anmeldung.html'},
            {label:general.footer_form1_label || 'Anmeldeformular.pdf', href:general.footer_form1_href || 'Anmeldeformular.pdf'},
            {label:general.footer_form2_label || 'Führerscheinantrag (Ersterteilung / Erweiterung)', href:general.footer_form2_href || 'Fuehrerscheinantrag_Ersterteilung_Erweiterung.pdf'}
          ]);
          applyLinks(3, [
            {label:general.footer_privacy_label || 'Datenschutz', href:general.footer_privacy_href || 'datenschutz.html'},
            {label:general.footer_imprint_label || 'Impressum', href:general.footer_imprint_href || 'impressum.html'},
            {label:general.footer_agb_label || 'AGB', href:general.footer_agb_href || 'agb.html'},
            {label:general.footer_cookie_label || 'Cookie-Richtlinie', href:general.footer_cookie_href || 'cookie-richtlinie.html'}
          ]);

          let note = footer.querySelector('.footer-note');
          if (note) {
            [...note.childNodes].filter(node => node.nodeType === Node.TEXT_NODE && node.nodeValue.trim() !== '').forEach(node => node.remove());
            let owner = note.querySelector('.footer-owner');
            if (!owner) { owner = document.createElement('span'); owner.className = 'footer-owner'; note.prepend(owner); }
            let creator = note.querySelector('.footer-creator');
            if (!creator) { creator = document.createElement('span'); creator.className = 'footer-creator'; note.appendChild(creator); }
            const year = general.footer_year || new Date().getFullYear();
            owner.textContent = `© ${year} ${general.school_name || 'Fahrschule BV'} · ${general.footer_owner_label || 'Inhaber'} ${general.owner || 'Vitali Bek'}`;
            creator.textContent = `${general.footer_creator_label || 'Webdesign & Entwicklung'}: ${general.footer_creator_name || 'Vladimir Sili'}`;
          }
        }

        const dockLabels = [general.dock_whatsapp_label || 'WhatsApp', general.dock_email_label || 'E-Mail', general.dock_phone_label || 'Telefon'];
        document.querySelectorAll('.contact-dock .dock-btn strong').forEach((el, index) => { if (dockLabels[index]) el.textContent = dockLabels[index]; });
      }

      function applyNavigation(data) {
        const nav = document.querySelector('.navlinks');
        if (!nav || !Array.isArray(data.navigation)) return;
        nav.innerHTML = '';
        data.navigation.filter(item => item.enabled !== false).forEach(item => {
          const link = document.createElement('a');
          link.href = /^(https?:|mailto:|tel:|#|\/)/.test(item.href) ? item.href : `/${item.href}`;
          link.textContent = item.label;
          if (item.button) link.className = 'btn btn-primary';
          nav.appendChild(link);
        });
        (data.customPages || []).filter(item => item.active && item.menu_label).forEach(item => {
          const link = document.createElement('a');
          link.href = `/seite/${item.slug}`;
          link.textContent = item.menu_label;
          nav.insertBefore(link, nav.querySelector('.btn') || null);
        });
      }

      function applyEditableContent(overrides) {
        Object.entries(overrides).forEach(([id, value]) => {
          const element = document.querySelector(`[data-cms-id="${CSS.escape(id)}"]`);
          if (!element) return;
          if (value && typeof value.text === 'string') element.textContent = value.text;
          if (element.tagName === 'A' && value.href) element.href = value.href;
        });
      }

      function applySeo(seo) {
        if (!seo) return;
        if (seo.title) document.title = seo.title;
        const description = document.querySelector('meta[name="description"]');
        if (description && seo.description) description.content = seo.description;
        let robots = document.querySelector('meta[name="robots"]');
        if (!robots) { robots = document.createElement('meta'); robots.name = 'robots'; document.head.appendChild(robots); }
        robots.content = seo.index === false ? 'noindex,nofollow' : 'index,follow';
      }

      function applyHomepage(homepage) {
        const eyebrow = document.querySelector('.hero .eyebrow');
        const title = document.querySelector('.hero h1');
        const primary = document.querySelector('[data-cms-id="index-a-1"]');
        const secondary = document.querySelector('[data-cms-id="index-a-2"]');
        const desktop = document.querySelector('.hero-bg');
        const mobile = document.querySelector('.hero picture source');
        if (eyebrow && homepage.eyebrow) eyebrow.textContent = homepage.eyebrow;
        if (title && (homepage.title || homepage.accent)) title.innerHTML = `${esc(homepage.title || '')}<br><span>${esc(homepage.accent || '')}</span>`;
        if (primary) { if (homepage.primary_text) primary.textContent = homepage.primary_text; if (homepage.primary_link) primary.href = homepage.primary_link; }
        if (secondary) { if (homepage.secondary_text) secondary.textContent = homepage.secondary_text; if (homepage.secondary_link) secondary.href = homepage.secondary_link; }
        if (desktop && homepage.desktop_image) desktop.src = homepage.desktop_image;
        if (mobile && homepage.mobile_image) mobile.srcset = homepage.mobile_image;
      }

      function applySummerCourse(course) {
        if (!course) return;
        const block = document.querySelector('#summer-course-block');
        if (!block) return;
        const courses = Array.isArray(course.courses) ? course.courses.filter(item => item && item.active !== false && (item.label || item.date || item.time)) : [];
        block.hidden = !course.enabled || courses.length === 0;
        [['#summer-course-label',course.label],['#summer-course-title',course.title]].forEach(([selector,value]) => {
          const element = document.querySelector(selector);
          if (element && typeof value === 'string') element.textContent = value;
        });
        const dates = block.querySelector('.summer-dates');
        if (dates) {
          dates.innerHTML = '';
          courses.forEach((item, index) => {
            const card = document.createElement('div');
            card.className = 'summer-date';
            card.innerHTML = `<small>${esc(item.label || `Kurs ${index + 1}`)}</small><strong>${esc(item.date || '')}</strong><span>${esc(item.time || '')}</span>`;
            dates.appendChild(card);
          });
        }
        const button = document.querySelector('#summer-course-button');
        if (button) { button.textContent = course.buttonText || button.textContent; button.href = course.buttonLink || button.href; }
      }

      function applyBanners(banners) {
        banners.filter(banner => banner.active !== false && (!banner.start || Date.now() >= Date.parse(`${banner.start}T00:00:00`)) && (!banner.end || Date.now() <= Date.parse(`${banner.end}T23:59:59`))).forEach(banner => {
          const section = document.createElement('section');
          section.className = 'cms-banner';
          section.innerHTML = `<div class="container cms-banner-inner">${banner.image ? `<img src="${esc(banner.image)}" alt="">` : ''}<div><span class="eyebrow">Aktuell</span><h2>${esc(banner.title)}</h2><p>${esc(banner.text)}</p>${banner.buttonText && banner.buttonLink ? `<a class="btn btn-primary" href="${esc(banner.buttonLink)}">${esc(banner.buttonText)}</a>` : ''}</div></div>`;
          const hero = document.querySelector('.hero');
          if ((banner.position || 'after-hero') === 'before-hero' && hero) hero.before(section);
          else if (hero) hero.after(section);
          else document.querySelector('header')?.after(section);
        });
      }

      function applyTeam(team) {
        if (!Array.isArray(team) || !team.length) return;
        const grid = document.querySelector('.team-grid');
        if (!grid) return;
        const template = grid.querySelector('.instructor-card:last-of-type');
        while (grid.querySelectorAll('.instructor-card').length < team.length && template) {
          grid.appendChild(template.cloneNode(true));
        }
        document.querySelectorAll('.instructor-card').forEach((card, index) => {
          const member = team[index];
          if (!member || member.active === false) { card.hidden = true; return; }
          card.hidden = false;
          const image = card.querySelector('.instructor-photo img');
          const role = card.querySelector('.team-role-note');
          const name = card.querySelector('h2');
          const classes = card.querySelector('h3:not(.team-tagline)');
          const tagline = card.querySelector('.team-tagline');
          const paragraphs = card.querySelectorAll('p');
          if (image && member.image) { image.src = member.image; image.alt = `${member.name || ''} – ${member.role || 'Fahrlehrer'}`; }
          if (role && member.role) role.textContent = member.role;
          if (name && member.name) name.textContent = member.name;
          if (classes && member.classes) classes.textContent = member.classes;
          if (tagline && member.tagline) tagline.textContent = member.tagline;
          if (paragraphs[0] && member.description_1) paragraphs[0].textContent = member.description_1;
          if (paragraphs[1] && member.description_2) paragraphs[1].textContent = member.description_2;
        });
      }

      function applyGallery(gallery) {
        if (!Array.isArray(gallery)) return;
        const container = document.querySelector('.gallery');
        if (!container) return;
        container.innerHTML = '';
        gallery.filter(image => image.active !== false).forEach(item => {
          const image = document.createElement('img');
          image.src = item.path;
          image.alt = item.alt || 'Fahrschule BV Galerie';
          image.loading = 'lazy'; image.decoding = 'async';
          container.appendChild(image);
        });
      }

      function applyForms(forms) {
        const registration = document.querySelector('form[data-registration-form]');
        const contact = document.querySelector('form[data-contact-form]');
        if (registration) {
          registration.dataset.maxUploadMb = String(forms.max_upload_mb || 8);
          const uploadHint = registration.querySelector('[data-cms-id="anmeldung-small-1"]');
          if (uploadHint && forms.max_upload_mb) uploadHint.textContent = `Erlaubt sind JPG, PNG und PDF. Alle Dateien zusammen dürfen maximal ${forms.max_upload_mb} MB groß sein. Die Unterlagen werden ausschließlich zur Bearbeitung der Anmeldung verwendet.`;
          if (forms.registration_enabled === false) disableForm(registration, forms.registration_notice || 'Die Online-Anmeldung ist vorübergehend deaktiviert.');
        }
        if (contact && forms.contact_enabled === false) disableForm(contact, forms.contact_notice || 'Das Kontaktformular ist vorübergehend deaktiviert.');
      }

      function disableForm(form, message) {
        const notice = document.createElement('div');
        notice.className = form.className;
        notice.innerHTML = `<span class="eyebrow">Hinweis</span><h2>Formular vorübergehend geschlossen</h2><p>${esc(message)}</p>`;
        form.replaceWith(notice);
      }

      function applyPrices(prices) {
        const table = document.querySelector('.price-matrix');
        if (!table) return;
        const headers = [...table.querySelectorAll('thead th')].slice(1).map(th => th.textContent.trim());
        [...table.querySelectorAll('tbody tr')].forEach(row => {
          const label = row.querySelector('th')?.textContent.trim() || '';
          [...row.querySelectorAll('td')].forEach((cell, index) => {
            const group = prices[headers[index]];
            if (group && group[label] !== undefined) {
              cell.textContent = group[label];
              cell.bvPriceBinding = {class:headers[index], label};
            }
          });
        });
        const stat = document.querySelector('.price-mini-stats span:nth-child(2) b');
        if (stat && prices.B?.['Fahrstunde je 45 Min'] !== undefined) {
          stat.textContent = prices.B['Fahrstunde je 45 Min'];
          stat.bvPriceBinding = {class:'B',label:'Fahrstunde je 45 Min'};
        }
        if (typeof window.buildMobilePriceCards === 'function') window.buildMobilePriceCards();
      }

      function applyPageEditorOverrides(overrides) {
        if (!overrides || typeof overrides !== 'object') return;
        const byXPath = path => {
          try { return document.evaluate(path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; } catch (_) { return null; }
        };
        Object.values(overrides).forEach(entry => {
          if (!entry || !entry.xpath) return;
          const el = byXPath(entry.xpath);
          if (!el) return;
          if (entry.kind === 'attr' && entry.attr) {
            if (entry.attr === 'href' && /^\s*javascript:/i.test(String(entry.value || ''))) return;
            el.setAttribute(entry.attr, String(entry.value ?? ''));
            return;
          }
          if (entry.kind === 'text') {
            let node = null;
            if (entry.slot === 'tail') {
              node = el.nextSibling && el.nextSibling.nodeType === Node.TEXT_NODE ? el.nextSibling : null;
            } else {
              node = [...el.childNodes].find(item => item.nodeType === Node.TEXT_NODE && item.nodeValue.trim() !== '') ||
                     [...el.childNodes].find(item => item.nodeType === Node.TEXT_NODE) || null;
            }
            if (!node) return;
            const raw = node.nodeValue || '';
            const lead = (raw.match(/^\s*/) || [''])[0];
            const trail = (raw.match(/\s*$/) || [''])[0];
            node.nodeValue = lead + String(entry.value ?? '') + trail;
          }
        });
      }

      function renderBlocks(blocks) {
        if (!Array.isArray(blocks)) return;
        blocks.forEach(block => {
          const section = document.createElement('section');
          section.className = 'section cms-added-block';
          const media = block.image ? `<div class="editorial-photo"><img src="${esc(block.image)}" alt=""></div>` : '';
          const button = block.buttonText && block.buttonLink ? `<p><a class="btn btn-primary" href="${esc(block.buttonLink)}">${esc(block.buttonText)}</a></p>` : '';
          if (block.type === 'image') section.innerHTML = `<div class="container">${media}</div>`;
          else if (block.type === 'text_image') section.innerHTML = `<div class="container split"><div><h2>${esc(block.title)}</h2><p>${nl(block.text)}</p>${button}</div>${media}</div>`;
          else if (block.type === 'cta') section.innerHTML = `<div class="container prose"><span class="eyebrow">Fahrschule BV</span><h2>${esc(block.title)}</h2><p>${nl(block.text)}</p>${button}</div>`;
          else section.innerHTML = `<div class="container prose"><h2>${esc(block.title)}</h2><p>${nl(block.text)}</p>${button}</div>`;
          document.querySelector('footer')?.before(section);
        });
      }
    })
    .catch(error => console.error('Fahrschule BV: Die Admin-Konfiguration konnte nicht geladen werden.', error));
})();
