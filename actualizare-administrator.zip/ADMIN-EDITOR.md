# Editor vizual pentru Fahrschule BV

Proprietarul vede în meniul din stânga toate cele **25 de pagini HTML**
existente: Startseite, Fahrschule, Führerschein, Motorradkurs, Unterrichtskalender,
Galerie, Preise, Kontakt, Online anmelden, paginile claselor și paginile legale.
Ordinea primelor pagini urmează meniul site-ului. Ceilalți utilizatori văd și pot
edita numai paginile publicate, vizibile în meniul public. Detalii în ADMIN-PERMISIUNI.md.

1. Apasă direct pe pagina dorită din meniul din stânga.
2. În dreapta apare lista **Alle Inhalte dieser Seite**, cu toate textele,
   fotografiile și linkurile paginii. Lista pornește pe **Alles**; poți filtra
   Texte, Bilder sau Links și poți căuta un anumit conținut.
3. Apasă **Text ändern**, **Bild ändern** sau **Link ändern**. Poți selecta
   textul sau fotografia și prin clic în previzualizarea paginii.
4. Apasă **In Vorschau übernehmen**, apoi verifică rezultatul.
5. Apasă **Speichern & veröffentlichen** pentru publicarea modificărilor.
   **Änderungen verwerfen** anulează schimbările încă nesalvate.

Textele sunt afișate integral, grupate după conținutul paginii, antet,
subsol, butoanele de contact și datele pentru Google. Sunt incluse prețurile,
tabelele, etichetele formularelor, textele butoanelor și descrierile imaginilor.
Titlul și descrierea pentru Google sunt editabile din aceeași pagină.
Prețurile modificate din pagina Preise se actualizează din aceeași sursă
atât în tabelul de desktop, cât și în cardurile pentru telefon.

Fotografiile, variantele pentru mobil și fundalurile cu imagini au butoane de
modificare în această listă. Sunt acceptate JPG, PNG, WEBP, GIF și AVIF; limita
reală a serverului este afișată în fereastra de încărcare. Fotografia originală
este păstrată. Desktop / Mobil schimbă dimensiunea previzualizării.

Modificările sunt individuale pentru pagina și elementul ales, inclusiv antetul
și subsolul acelei pagini. Meniul public se modifică exclusiv de proprietar,
din „Seiten und Menü”; este protejat și în editorul vizual. Secțiunile separate de editare au fost eliminate din
meniu. Linkurile vechi către ele redirecționează către pagina corespunzătoare.
Statistica, înscrierile, mesajele, utilizatorii, istoricul, contul și setările
rămân funcții administrative separate. Configurarea tehnică a formularelor și
a e-mailului se deschide din Einstellungen und Sicherung.

## Actualizare pe hosting

Arhiva de actualizare conține numai fișierele de cod modificate sau adăugate.
Se copiază peste site, păstrând căile directoarelor. Nu înlocuiește datele din
private_admin, private_messages ori private_uploads și nu conține conturi,
documente sau mesaje ale cursanților. Include ADMIN-EDITOR.md pentru instrucțiuni.

Site-ul folosește PHP 8.1 sau mai nou (codul existent folosește tipul never).
Verificările locale au folosit PHP 8.4. Sunt necesare sesiuni, extensia fileinfo
și drepturi de scriere în private_admin, assets/data și assets/uploads.
admin/.user.ini configurează încărcări de 8 MB și cereri de 12 MB pentru
hostingurile PHP-FPM/CGI care acceptă acest fișier. Dacă hostingul impune o limită
mai mică, editorul o afișează și o respectă. Nu este necesară extensia GD:
imaginile noi sunt păstrate în formatul lor original.

Noile modificări se salvează în câmpul visualEditor al configurației existente.
Nu se schimbă parole, conturi, mesaje, înscrieri sau setări de e-mail.
Înainte de actualizarea hostingului, păstrează o copie a fișierelor și a
configurației existente. După încărcare, verifică o pagină în administrator și
într-o fereastră separată de browser. Publicarea pe hosting nu a fost efectuată
în această sesiune.
