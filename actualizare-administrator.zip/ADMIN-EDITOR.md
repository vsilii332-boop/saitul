# Editor vizual pentru Fahrschule BV

În administrator, deschide **Seiten und Texte**. Editorul pornește pe pagina
Motorradkurs. Din **Seite auswählen** poți alege oricare dintre cele 25 de pagini
HTML existente. **Bildergalerie** deschide același editor pe pagina galeriei,
cu lista de imagini selectată.

1. Apasă pe un text sau o fotografie din previzualizare. Poți folosi și lista
   **Texte / Bilder**, cu căutare și butoane **Ändern**.
2. Modifică textul sau alege o imagine nouă. Sunt acceptate JPG, PNG, WEBP, GIF
   și AVIF. Limita reală a serverului apare în fereastra de încărcare.
3. Apasă **In Vorschau übernehmen**. Vezi rezultatul fără să-l publici.
4. Apasă **Speichern & veröffentlichen** pentru salvare și publicare.
   **Änderungen verwerfen** anulează modificările încă nesalvate.

Lista include texte din meniuri, butoane, tabele, formulare și subsol, descrieri
de imagini, fotografii, variantele responsive și fundalurile cu imagini.
La înlocuirea unei fotografii dintr-un element picture poți include și varianta
pentru telefon. Fundalurile pot fi alese și din lista Bilder.
Desktop / Mobil schimbă dimensiunea previzualizării.

Modificările vizuale sunt individuale pentru pagina și elementul ales.
Fișierul fotografiei originale este păstrat. Pentru modificări globale, precum
aceeași adresă pe toate paginile, rămâne disponibilă secțiunea Kontaktdaten.
Paginile personalizate create prin sistemul existent rămân în zona avansată.

## Actualizare pe hosting

Arhiva de actualizare conține numai fișierele de cod modificate sau adăugate.
Se copiază peste site, păstrând căile directoarelor. Nu înlocuiește datele din
private_admin, private_messages ori private_uploads și nu conține conturi,
documente sau mesaje ale cursanților. Include ADMIN-EDITOR.md pentru instrucțiuni.

Site-ul folosește PHP 8.1 sau mai nou (codul existent folosește tipul never).
Verificările locale au folosit PHP 8.4. Sunt necesare sesiuni, extensia fileinfo
și drepturi de scriere în private_admin, assets/data și assets/uploads.
admin/.user.ini configurează încărcări de 8 MB și cereri de 12 MB pentru
hostingurile PHP-FPM/CGI care acceptă acest fișier. Dacă hostingul impune o limită
mai mică, editorul o afișează și o respectă. Nu este necesară extensia GD:
imaginile noi sunt păstrate în formatul lor original.

Noile modificări se salvează în câmpul visualEditor al configurației existente.
Nu se schimbă parole, conturi, mesaje, înscrieri sau setări de e-mail.
Înainte de actualizarea hostingului, păstrează o copie a fișierelor și a
configurației existente. După încărcare, verifică o pagină în administrator și
într-o fereastră separată de browser. Publicarea pe hosting nu a fost efectuată
în această sesiune.
