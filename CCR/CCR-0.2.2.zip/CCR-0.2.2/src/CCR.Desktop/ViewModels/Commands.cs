using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace CCR.Desktop.ViewModels;

public abstract class ObservableObject : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;
    protected void Notify([CallerMemberName] string? property = null) => PropertyChanged?.Invoke(this, new(property));
    protected bool Set<T>(ref T storage, T value, [CallerMemberName] string? property = null)
    {
        if (EqualityComparer<T>.Default.Equals(storage, value)) return false;
        storage = value; Notify(property); return true;
    }
}

public sealed class RelayCommand(Action<object?> execute, Func<bool>? canExecute = null) : ICommand
{
    public event EventHandler? CanExecuteChanged;
    public bool CanExecute(object? parameter) => canExecute?.Invoke() ?? true;
    public void Execute(object? parameter) { if (CanExecute(parameter)) execute(parameter); }
    public void Refresh() => CanExecuteChanged?.Invoke(this, EventArgs.Empty);
}

public sealed class AsyncCommand(Func<Task> execute, Func<bool> canExecute, Action<Exception> onError) : ICommand
{
    private bool _running;
    public event EventHandler? CanExecuteChanged;
    public Task ExecutionTask { get; private set; } = Task.CompletedTask;
    public bool CanExecute(object? parameter) => !_running && canExecute();
    public void Execute(object? parameter)
    {
        if (!CanExecute(parameter)) return;
        _running = true; Refresh(); ExecutionTask = RunAsync();
    }
    private async Task RunAsync()
    {
        try { await execute(); }
        catch (OperationCanceledException) { }
        catch (Exception error) { onError(error); }
        finally { _running = false; Refresh(); }
    }
    public void Refresh() => CanExecuteChanged?.Invoke(this, EventArgs.Empty);
}
