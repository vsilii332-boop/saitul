using Avalonia;
using Avalonia.Controls;
using Avalonia.Media;

namespace CCR.Desktop.Controls;

public sealed class TrendChart : Control
{
    public static readonly StyledProperty<IReadOnlyList<double>?> ValuesProperty = AvaloniaProperty.Register<TrendChart, IReadOnlyList<double>?>(nameof(Values));
    public IReadOnlyList<double>? Values { get => GetValue(ValuesProperty); set => SetValue(ValuesProperty, value); }
    static TrendChart() => AffectsRender<TrendChart>(ValuesProperty);

    public override void Render(DrawingContext context)
    {
        base.Render(context);
        var area = new Rect(20, 16, Math.Max(0, Bounds.Width - 40), Math.Max(0, Bounds.Height - 32));
        var grid = new Pen(new SolidColorBrush(Color.Parse("#253247")), 1);
        for (var i = 0; i <= 4; i++) context.DrawLine(grid, new(area.Left, area.Top + area.Height * i / 4), new(area.Right, area.Top + area.Height * i / 4));
        if (Values is not { Count: >= 2 } values) return;
        var geometry = new StreamGeometry();
        using (var path = geometry.Open())
        {
            for (var i = 0; i < values.Count; i++)
            {
                var point = new Point(area.Left + area.Width * i / (values.Count - 1), area.Bottom - area.Height * Math.Clamp(values[i] / 4000d, 0, 1));
                if (i == 0) path.BeginFigure(point, false); else path.LineTo(point);
            }
            path.EndFigure(false);
        }
        context.DrawGeometry(null, new Pen(new SolidColorBrush(Color.Parse("#FF994F")), 2.5), geometry);
    }
}
