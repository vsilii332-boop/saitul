using System.Globalization;
using System.Text;

namespace CCR.Core;

public static class DiagnosticReport
{
    public const char CsvSeparator = ';';

    public static string ToCsv(IEnumerable<DiagnosticModule> modules, DateTimeOffset createdAt, string? vin = null)
    {
        var rows = modules.ToArray();
        var simulation = rows.All(m => m.IsSimulated);
        var text = new StringBuilder();
        // A single rectangular table lets spreadsheet importers identify the delimiter reliably.
        // Repeating report metadata also keeps each diagnostic row useful when filtered or copied.
        void WriteRow(params string[] cells) => text.Append(string.Join(CsvSeparator, cells.Select(Cell))).Append("\r\n");
        WriteRow("Tip raport", "Data", "VIN", "Modul", "Cod DTC", "Descriere", "Stare", "Observatii");
        var kind = simulation ? "RAPORT DE SIMULARE - FARA VEHICUL REAL" : "RAPORT OBD-II - DOAR CITIRE";
        var date = createdAt.ToString("O", CultureInfo.InvariantCulture);
        var vehicle = simulation ? "SIMULARE" : vin ?? "Indisponibil";
        foreach (var module in rows)
        {
            var scope = module.IsSimulated ? "Date generate de simulator." : "Acoperire OBD-II standard. Nu este o scanare completa a vehiculului.";
            var notes = string.Join(" ", new[] { scope, module.ReadNote }.Where(s => !string.IsNullOrWhiteSpace(s)));
            if (module.Faults.Count == 0)
                WriteRow(kind, date, vehicle, module.Name, "", !module.IsComplete ? "Citire incompleta" : module.IsSimulated ? "Fara erori" : "Fara coduri memorate", module.IsSimulated ? "SIMULARE" : "OBD-II", notes);
            foreach (var fault in module.Faults)
                WriteRow(kind, date, vehicle, module.Name, fault.Code, fault.Description, fault.Status, notes);
        }
        return text.ToString();
    }

    private static string Cell(string value)
    {
        // Keep spreadsheet applications from interpreting external text as a formula.
        if (value.TrimStart().FirstOrDefault() is '=' or '+' or '-' or '@') value = "'" + value;
        return "\"" + value.Replace("\"", "\"\"") + "\"";
    }
}
