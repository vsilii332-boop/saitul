using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace CCR.Core.Elm;

/// <summary>One ELM command/prompt exchange at a time. Interrupted exchanges invalidate the TCP session.</summary>
public sealed class ElmTcpConnection : IAsyncDisposable
{
    private readonly string _host;
    private readonly int _port;
    private readonly SemaphoreSlim _exchange = new(1);
    private readonly TimeSpan _connectTimeout;
    private TcpClient? _client;
    private NetworkStream? _stream;
    private bool _disposed;
    private readonly List<CommunicationExchange> _traffic = [];
    public bool IsOpen => _stream is not null;
    public IReadOnlyList<CommunicationExchange> RecentTraffic { get { lock (_traffic) return _traffic.ToArray(); } }

    public ElmTcpConnection(string host, int port, TimeSpan? connectTimeout = null)
    {
        if (!IPAddress.TryParse(host.Trim(), out var address)) throw new ArgumentException("Introdu o adresă IP validă pentru adaptor.", nameof(host));
        if (port is < 1 or > 65535) throw new ArgumentOutOfRangeException(nameof(port), "Portul trebuie să fie între 1 și 65535.");
        _host = address.ToString(); _port = port; _connectTimeout = connectTimeout ?? TimeSpan.FromSeconds(5);
    }

    public async Task OpenAsync(CancellationToken cancellationToken)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(_connectTimeout);
        DropConnection();
        var client = new TcpClient { NoDelay = true };
        try
        {
            await client.ConnectAsync(IPAddress.Parse(_host), _port, timeout.Token);
            timeout.Token.ThrowIfCancellationRequested();
            ObjectDisposedException.ThrowIf(_disposed, this);
            _client = client; _stream = client.GetStream();
            if (_disposed) { DropConnection(); throw new ObjectDisposedException(nameof(ElmTcpConnection)); }
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested) { client.Dispose(); throw new TimeoutException("Adaptorul nu a răspuns la conexiunea TCP. Verifică rețeaua Wi-Fi, IP-ul și portul."); }
        catch { client.Dispose(); throw; }
    }

    public async Task<string> ExchangeAsync(string command, CancellationToken cancellationToken, TimeSpan? commandTimeout = null)
    {
        if (string.IsNullOrWhiteSpace(command) || command.Any(c => !char.IsAsciiLetterOrDigit(c))) throw new ArgumentException("Comandă ELM invalidă.", nameof(command));
        ObjectDisposedException.ThrowIf(_disposed, this);
        await _exchange.WaitAsync(cancellationToken);
        var watch = Stopwatch.StartNew();
        var response = new StringBuilder();
        try
        {
            var stream = _stream ?? throw new InvalidOperationException("Conexiunea cu adaptorul este închisă.");
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeout.CancelAfter(commandTimeout ?? TimeSpan.FromSeconds(6));
            try
            {
                await stream.WriteAsync(Encoding.ASCII.GetBytes(command.ToUpperInvariant() + "\r"), timeout.Token);
                var buffer = new byte[512];
                while (true)
                {
                    var count = await stream.ReadAsync(buffer, timeout.Token);
                    if (count == 0) throw new IOException("Adaptorul a închis conexiunea Wi-Fi.");
                    var prompt = Array.IndexOf(buffer, (byte)'>', 0, count);
                    var length = prompt < 0 ? count : prompt;
                    if (response.Length + length > 32768) throw new InvalidDataException("Răspunsul adaptorului depășește limita acceptată.");
                    for (var i = 0; i < length; i++)
                    {
                        var c = buffer[i];
                        if (c is 9 or 10 or 13 || c is >= 32 and <= 126) response.Append((char)c);
                        else throw new InvalidDataException("Adaptorul a trimis date care nu sunt text ELM.");
                    }
                    if (prompt >= 0)
                    {
                        // No next command has been sent; non-whitespace after the prompt cannot belong to it.
                        if (buffer.Skip(prompt + 1).Take(count - prompt - 1).Any(b => b is not (9 or 10 or 13 or 32))) throw new InvalidDataException("Date neașteptate după promptul ELM.");
                        return response.ToString();
                    }
                }
            }
            catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested) { throw new TimeoutException("Adaptorul nu a încheiat răspunsul la comanda " + command + ". Reconectează adaptorul."); }
        }
        catch { DropConnection(); throw; }
        finally
        {
            lock (_traffic)
            {
                _traffic.Add(new(DateTimeOffset.Now, command.ToUpperInvariant(), response.ToString(), watch.ElapsedMilliseconds));
                if (_traffic.Count > 100) _traffic.RemoveAt(0);
            }
            _exchange.Release();
        }
    }

    public void DropConnection() { _stream?.Dispose(); _client?.Dispose(); _stream = null; _client = null; }
    public ValueTask DisposeAsync() { if (!_disposed) { _disposed = true; DropConnection(); } return ValueTask.CompletedTask; }
}
