using System.Globalization;
using System.Text;

namespace CCR.Core.Elm;

public sealed record ObdMessage(string Ecu, byte[] Data);

public static class ObdResponseParser
{
    public static bool IsCan(int protocol) => protocol is >= 6 and <= 9;

    public static IReadOnlyList<ObdMessage> Parse(string raw, string command, int protocol)
    {
        if (protocol is < 1 or > 9) throw new NotSupportedException("Protocol OBD neacceptat în această versiune.");
        var messages = new List<ObdMessage>();
        var fragments = new Dictionary<string, (int Length, byte Sequence, List<byte> Data)>();
        foreach (var original in raw.Replace('\n', '\r').Split('\r', StringSplitOptions.RemoveEmptyEntries))
        {
            var line = original.Trim().ToUpperInvariant();
            if (line.Replace(" ", "") == command.ToUpperInvariant()) continue;
            if (line.StartsWith("SEARCHING...", StringComparison.Ordinal)) line = line[12..].Trim();
            if (line.StartsWith("BUS INIT:", StringComparison.Ordinal)) { if (line.EndsWith("OK", StringComparison.Ordinal)) continue; throw new IOException("Inițializarea magistralei OBD a eșuat."); }
            if (line.Length == 0 || line == "NO DATA") continue;
            if (line is "?" or "STOPPED" || line.Contains("ERROR", StringComparison.Ordinal) || line.Contains("UNABLE TO CONNECT", StringComparison.Ordinal) || line.Contains("BUFFER FULL", StringComparison.Ordinal) || line.Contains("CAN BUS", StringComparison.Ordinal)) throw new IOException("Adaptorul a raportat: " + line);
            var hex = string.Concat(line.Where(c => !char.IsWhiteSpace(c)));
            if (!hex.All(Uri.IsHexDigit)) throw new InvalidDataException("Răspuns ELM nerecunoscut: " + line);
            if (IsCan(protocol))
            {
                var headerLength = protocol is 7 or 9 ? 8 : 3;
                if (hex.Length <= headerLength + 2) throw new InvalidDataException("Cadru CAN prea scurt.");
                var ecu = hex[..headerLength];
                if (headerLength == 3 && int.Parse(ecu, NumberStyles.HexNumber, CultureInfo.InvariantCulture) > 0x7FF) throw new InvalidDataException("Identificator CAN invalid.");
                if (headerLength == 8 && uint.Parse(ecu, NumberStyles.HexNumber, CultureInfo.InvariantCulture) > 0x1FFFFFFF) throw new InvalidDataException("Identificator CAN invalid.");
                var frameText = hex[headerLength..];
                if (frameText.Length % 2 != 0)
                {
                    var dlc = int.Parse(frameText[..1], NumberStyles.HexNumber, CultureInfo.InvariantCulture);
                    frameText = frameText[1..];
                    if (dlc > 8 || frameText.Length / 2 != dlc) throw new InvalidDataException("Lungime DLC nevalidă.");
                }
                var frame = Convert.FromHexString(frameText);
                if (frame.Length is < 1 or > 8) throw new InvalidDataException("Lungime CAN neacceptată.");
                var type = frame[0] >> 4;
                if (type == 0)
                {
                    var length = frame[0] & 15;
                    if (length < 1 || length > frame.Length - 1 || fragments.ContainsKey(ecu)) throw new InvalidDataException("Cadru ISO-TP simplu invalid.");
                    messages.Add(new(ecu, frame.Skip(1).Take(length).ToArray()));
                }
                else if (type == 1)
                {
                    if (frame.Length < 3 || fragments.ContainsKey(ecu)) throw new InvalidDataException("Început ISO-TP invalid.");
                    var length = ((frame[0] & 15) << 8) | frame[1];
                    if (length <= 7 || length > 4095) throw new InvalidDataException("Lungime ISO-TP invalidă.");
                    fragments[ecu] = (length, 1, frame.Skip(2).ToList());
                }
                else if (type == 2)
                {
                    if (!fragments.TryGetValue(ecu, out var packet) || (frame[0] & 15) != packet.Sequence || frame.Length < 2) throw new InvalidDataException("Secvență ISO-TP incompletă sau în ordine greșită.");
                    packet.Data.AddRange(frame.Skip(1));
                    if (packet.Data.Count >= packet.Length) { messages.Add(new(ecu, packet.Data.Take(packet.Length).ToArray())); fragments.Remove(ecu); }
                    else fragments[ecu] = (packet.Length, (byte)((packet.Sequence + 1) & 15), packet.Data);
                }
                else throw new InvalidDataException("Cadru ISO-TP neașteptat în răspuns.");
            }
            else
            {
                if (hex.Length % 2 != 0) throw new InvalidDataException("Cadru OBD vechi incomplet.");
                var frame = Convert.FromHexString(hex);
                if (frame.Length < 5) throw new InvalidDataException("Cadru OBD vechi prea scurt.");
                var start = protocol is 4 or 5 && (frame[0] & 0x3F) == 0 ? 4 : 3;
                if (frame.Length <= start + 1) throw new InvalidDataException("Cadru OBD vechi fără date.");
                if (protocol is 3 or 4 or 5 && (frame.Take(frame.Length - 1).Sum(b => b) & 255) != frame[^1]) throw new InvalidDataException("Checksum OBD nevalid.");
                if (protocol is 1 or 2 && J1850Crc(frame.AsSpan(0, frame.Length - 1)) != frame[^1]) throw new InvalidDataException("CRC J1850 nevalid.");
                var payloadLength = frame.Length - start - 1;
                if (protocol is 4 or 5)
                {
                    var declaredLength = (frame[0] & 0x3F) == 0 ? frame[3] : frame[0] & 0x3F;
                    if (declaredLength != payloadLength) throw new InvalidDataException("Lungime KWP nevalidă.");
                }
                messages.Add(new(frame[2].ToString("X2", CultureInfo.InvariantCulture), frame.Skip(start).Take(payloadLength).ToArray()));
            }
        }
        if (fragments.Count > 0) throw new InvalidDataException("Răspuns ISO-TP incomplet; rezultatele nu pot fi confirmate.");
        return messages;
    }

    public static HashSet<int> SupportedPids(byte[] response, int start)
    {
        if (response.Length != 6 || response[0] != 0x41 || response[1] != start) throw new InvalidDataException("Lista PID este incompletă.");
        var pids = new HashSet<int>();
        for (var i = 0; i < 32; i++) if ((response[2 + i / 8] & (1 << (7 - i % 8))) != 0) pids.Add(start + i + 1);
        return pids;
    }

    private static byte J1850Crc(ReadOnlySpan<byte> data)
    {
        var crc = 0xFF;
        foreach (var b in data)
        {
            crc ^= b;
            for (var bit = 0; bit < 8; bit++) crc = ((crc << 1) ^ ((crc & 0x80) != 0 ? 0x1D : 0)) & 0xFF;
        }
        return (byte)(crc ^ 0xFF);
    }

    public static string DtcCode(byte first, byte second) => $"{new[] { 'P', 'C', 'B', 'U' }[first >> 6]}{(first >> 4) & 3}{first & 15:X1}{second:X2}";

    public static IReadOnlyList<string> DtcCodes(byte[] data, bool isCan)
    {
        var offset = isCan ? 2 : 1;
        if (data.Length < offset || data[0] is not (0x43 or 0x47 or 0x4A)) throw new InvalidDataException("Răspuns DTC invalid.");
        var available = data.Length - offset;
        var count = isCan ? data[1] : available / 2;
        if ((!isCan && available % 2 != 0) || count * 2 > available) throw new InvalidDataException("Lista DTC este incompletă.");
        if (isCan && data.Skip(offset + count * 2).Any(b => b != 0)) throw new InvalidDataException("Numărul codurilor DTC nu corespunde răspunsului.");
        var codes = new List<string>();
        for (var i = 0; i < count; i++)
        {
            var a = data[offset + 2 * i]; var b = data[offset + 2 * i + 1];
            if (a == 0 && b == 0) { if (isCan) throw new InvalidDataException("Cod DTC nul în lista declarată."); continue; }
            codes.Add(DtcCode(a, b));
        }
        return codes;
    }

    public static string Description(string code) => code switch
    {
        "P0100" => "Circuit debitmetru de aer", "P0115" => "Circuit senzor temperatură lichid de răcire", "P0130" => "Circuit senzor oxigen · banca 1, senzor 1",
        "P0171" => "Amestec prea sărac · banca 1", "P0172" => "Amestec prea bogat · banca 1", "P0300" => "Rateuri aleatorii sau multiple detectate",
        "P0301" => "Rateu detectat · cilindrul 1", "P0420" => "Eficiență catalizator sub prag · banca 1", _ => "Descriere indisponibilă în baza locală. Verifică documentația vehiculului."
    };

    public static string? Vin(IEnumerable<ObdMessage> messages, string ecu, bool isCan)
    {
        var records = messages.Where(m => m.Ecu == ecu && m.Data.Length >= 3 && m.Data[0] == 0x49 && m.Data[1] == 2).ToArray();
        byte[] bytes;
        if (isCan)
        {
            if (records.Length != 1 || records[0].Data.Length != 20 || records[0].Data[2] != 1) return null;
            bytes = records[0].Data[3..];
        }
        else
        {
            var ordered = records.OrderBy(r => r.Data[2]).ToArray();
            if (ordered.Length != 5 || !ordered.Select(r => (int)r.Data[2]).SequenceEqual(Enumerable.Range(1, 5)) || ordered.Any(r => r.Data.Length != 7)) return null;
            bytes = ordered.SelectMany(r => r.Data[3..]).SkipWhile(b => b == 0).ToArray();
        }
        if (bytes.Length != 17 || bytes.Any(b => !(b is >= (byte)'0' and <= (byte)'9' || b is >= (byte)'A' and <= (byte)'Z') || b is (byte)'I' or (byte)'O' or (byte)'Q')) return null;
        return Encoding.ASCII.GetString(bytes);
    }
}
