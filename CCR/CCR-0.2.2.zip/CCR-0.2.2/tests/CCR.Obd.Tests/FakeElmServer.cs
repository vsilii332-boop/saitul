using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace CCR.Obd.Tests;

internal sealed record FakeReply(string Text, int FragmentSize = 0, bool Prompt = true, bool Close = false);

/// <summary>Loopback ELM emulator for integration tests. Never connects to a vehicle or a LAN host.</summary>
internal sealed class FakeElmServer : IAsyncDisposable
{
    private readonly TcpListener _listener = new(IPAddress.Loopback, 0);
    private readonly CancellationTokenSource _stop = new();
    private readonly Func<string, FakeReply> _reply;
    private readonly ConcurrentBag<Task> _sessions = [];
    private readonly ConcurrentBag<TcpClient> _clients = [];
    private readonly Task _accept;
    public ConcurrentQueue<string> Commands { get; } = new();
    public int Port => ((IPEndPoint)_listener.LocalEndpoint).Port;
    public FakeElmServer(Func<string, FakeReply> reply) { _reply = reply; _listener.Start(); _accept = AcceptAsync(); }
    private async Task AcceptAsync()
    {
        try
        {
            while (!_stop.IsCancellationRequested)
            {
                var client = await _listener.AcceptTcpClientAsync(_stop.Token); client.NoDelay = true;
                _clients.Add(client); _sessions.Add(ServeAsync(client));
            }
        }
        catch (OperationCanceledException) { }
        catch (SocketException) when (_stop.IsCancellationRequested) { }
    }
    private async Task ServeAsync(TcpClient client)
    {
        try
        {
            using (client)
            {
                var stream = client.GetStream(); var bytes = new byte[512]; var text = new StringBuilder();
                while (!_stop.IsCancellationRequested)
                {
                    var count = await stream.ReadAsync(bytes, _stop.Token); if (count == 0) return;
                    for (var i = 0; i < count; i++)
                    {
                        var c = (char)bytes[i]; if (c == '\n') continue;
                        if (c != '\r') { text.Append(c); continue; }
                        var command = text.ToString(); text.Clear(); Commands.Enqueue(command);
                        var reply = _reply(command);
                        var response = Encoding.ASCII.GetBytes(reply.Text + (reply.Prompt ? ">" : ""));
                        var fragment = reply.FragmentSize == 0 ? Math.Max(1, response.Length) : reply.FragmentSize;
                        for (var at = 0; at < response.Length; at += fragment)
                        {
                            await stream.WriteAsync(response.AsMemory(at, Math.Min(fragment, response.Length - at)), _stop.Token);
                            if (reply.FragmentSize > 0) await Task.Yield();
                        }
                        if (reply.Close) return;
                    }
                }
            }
        }
        catch (OperationCanceledException) { }
        catch (IOException) { }
        catch (ObjectDisposedException) when (_stop.IsCancellationRequested) { }
    }
    public async ValueTask DisposeAsync()
    {
        _stop.Cancel(); _listener.Stop(); foreach (var client in _clients) client.Dispose();
        await _accept; await Task.WhenAll(_sessions); _stop.Dispose();
    }
}
