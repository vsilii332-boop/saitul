using Avalonia;
using Avalonia.Controls;
using Avalonia.Headless;
using Avalonia.Interactivity;
using Avalonia.Media.Imaging;
using Avalonia.Threading;
using CCR.Core;
using CCR.Core.Elm;
using CCR.Obd.Tests;
using CCR.Desktop;
using CCR.Desktop.ViewModels;

// Integration checks use the real Avalonia XAML, bindings, commands and local simulator.
AppBuilder.Configure<App>().UseSkia().UseHeadless(new() { UseHeadlessDrawing = false }).WithInterFont().SetupWithoutStarting();
var checks = new List<string>();
var export = "";
var window = new MainWindow(new SimulatedDiagnosticAdapter(TimeSpan.FromMilliseconds(100)), value => { export = value; return Task.FromResult(true); });
var workspace = window.Workspace;
window.Show();
Pump();

void Expect(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
void Pass(string value) { checks.Add(value); Console.WriteLine("PASS " + value); }
void Pump() => Dispatcher.UIThread.RunJobs();
void Finish(Task task)
{
    var until = DateTime.UtcNow.AddSeconds(10);
    while (!task.IsCompleted && DateTime.UtcNow < until) { Pump(); Thread.Sleep(2); }
    Expect(task.IsCompleted, "Operation exceeded test deadline.");
    task.GetAwaiter().GetResult(); Pump();
}
Button FindButton(string name) => window.FindControl<Button>(name) ?? throw new InvalidOperationException("Missing button: " + name);
void Click(string name, bool pump = true)
{
    var button = FindButton(name);
    Expect(button.IsEffectivelyEnabled, "Button should be enabled: " + name);
    Expect(button.Command is not null, "Missing bound command: " + name);
    button.Command!.Execute(button.CommandParameter); if (pump) Pump();
}

Expect(workspace.IsDisconnected && workspace.IsOverview, "Initial disconnected overview.");
Expect(!FindButton("ScanButton").IsEffectivelyEnabled, "Cannot scan while disconnected.");
Expect(!workspace.RequestClearCommand.CanExecute(null), "Cannot clear while disconnected.");
Expect(workspace.RpmText == "—" && workspace.ModuleCount == 0, "No invented initial readings.");
Pass("Disconnected state: scan/clear/live unavailable, no displayed vehicle measurements.");

Click("ConnectButton", false);
Expect(workspace.IsBusy, "Connecting should be busy.");
Expect(!workspace.ScanCommand.CanExecute(null), "Commands serialize during connecting.");
Finish(workspace.ConnectCommand.ExecutionTask);
Expect(workspace.IsConnected && workspace.Status.Contains("Simulator"), "Connected simulation state.");
Click("ScanButton"); Finish(workspace.ScanCommand.ExecutionTask);
Expect(workspace.IsDiagnostics && workspace.ModuleCount == 3 && workspace.FaultCount == 2, "Scan module and DTC results.");
Expect(workspace.Faults.Select(f => f.Code).SequenceEqual(new[] { "P0130", "P0300" }), "OBD DTC examples.");
Expect(FindButton("ExportButton").IsEffectivelyEnabled, "Can export a completed scan.");
Pass("Connect and scan: real XAML commands, operation state, three simulated modules and two DTCs.");

Click("ClearButton"); Expect(workspace.ConfirmationVisible, "Clear requires confirmation.");
Expect(window.FindControl<Border>("ClearConfirmation")!.IsVisible, "Confirmation is displayed.");
Click("CancelClearButton"); Expect(!workspace.ConfirmationVisible && workspace.FaultCount == 2, "Cancel preserves DTCs.");
Click("ClearButton"); Click("ConfirmClearButton"); Finish(workspace.ConfirmClearCommand.ExecutionTask);
Expect(!workspace.ConfirmationVisible && workspace.FaultCount == 0 && workspace.HasNoFaults, "Confirmed clear changes simulator only.");
Click("RescanButton"); Finish(workspace.ScanCommand.ExecutionTask);
Expect(workspace.FaultCount == 0, "A rescan must not recreate cleared DTCs.");
Expect(!FindButton("ClearButton").IsEffectivelyEnabled, "Clear disabled without DTCs.");
Pass("Clear DTC: confirmation, cancellation, confirmed removal, rescan persistence and empty-state handling.");

Click("ExportButton"); Finish(workspace.ExportCommand.ExecutionTask);
Expect(export.Contains("RAPORT DE SIMULARE - FARA VEHICUL REAL") && export.Contains("Injecție / motor") && export.Contains("Fara erori"), "CSV report content and simulation label.");
Expect(DiagnosticReport.ToCsv([new("x", "=1+1", [new("P0001", "text, \"quoted\"")])], DateTimeOffset.Now).Contains("\"'=1+1\""), "CSV formula text is escaped.");
Expect(DiagnosticReport.ToCsv([new("x", "test", [new("P0001", "text, \"quoted\"")])], DateTimeOffset.Now).Contains("\"text, \"\"quoted\"\"\""), "CSV quotations preserved.");
Pass("CSV export: module results, unmistakable simulation heading, quotation and spreadsheet formula escaping.");

Click("LiveNav"); Click("LiveToggleButton");
var sampleDeadline = DateTime.UtcNow.AddSeconds(8);
while (workspace.RpmHistory.Count < 60 && DateTime.UtcNow < sampleDeadline) { Finish(workspace.RefreshLiveAsync()); Pump(); Thread.Sleep(2); }
Expect(workspace.IsLivePage && workspace.IsLive && workspace.RpmHistory.Count == 60, $"Live sampling: active={workspace.IsLive}, page={workspace.CurrentPage}, samples={workspace.RpmHistory.Count}, status={workspace.Status}");
Expect(workspace.RpmText != "—" && workspace.RpmHistory.All(v => v >= 800 && v <= 2300), "Plausible simulation RPM.");
Expect(window.FindControl<TextBlock>("RpmValue")!.Text == workspace.RpmText, "Live label binding updated.");
Click("LiveToggleButton"); var last = workspace.RpmText; Finish(workspace.RefreshLiveAsync());
Expect(workspace.RpmText == last, "Paused readings stay stable.");
Pass("Live data: numeric bindings, chart updates, 60-sample limit and pause without fabricated updates.");

foreach (var (button, page) in new[] { ("ServiceNav", "service"), ("ProgrammingNav", "programming"), ("HistoryNav", "history"), ("SettingsNav", "settings"), ("OverviewNav", "overview") })
{
    Click(button); Expect(workspace.CurrentPage == page, "Navigation route: " + page);
}
Expect(workspace.History.Any(h => h.Action == "Ștergere DTC · demo"), "History includes clear action.");
Expect(workspace.History.Any(h => h.Action == "Export CSV"), "History includes export action.");
Pass("All navigation destinations and session history work; service/programming are labeled future modules.");

// Capture the rendered window at desktop and smaller supported sizes.
var output = Environment.GetEnvironmentVariable("CCR_TEST_ARTIFACTS");
if (!string.IsNullOrWhiteSpace(output))
{
    Directory.CreateDirectory(output);
    foreach (var (page, width, height, file) in new[] { ("overview", 1280d, 820d, "ccr-overview.png"), ("live", 1280d, 820d, "ccr-live.png"), ("diagnostics", 1040d, 720d, "ccr-diagnostics-small.png") })
    {
        workspace.CurrentPage = page; window.Width = width; window.Height = height;
        Pump();
        AvaloniaHeadlessPlatform.ForceRenderTimerTick();
        using var image = window.CaptureRenderedFrame();
        Expect(image is not null, "Rendered frame available."); image!.Save(Path.Combine(output, file), PngBitmapEncoderOptions.Default);
    }
    Pass("Rendered desktop/live/small-window screenshots generated from the actual Avalonia UI.");
}

workspace.CurrentPage = "overview"; Pump(); Click("DisconnectButton"); Finish(workspace.DisconnectCommand.ExecutionTask);
Expect(workspace.IsDisconnected && workspace.Modules.Count == 0 && workspace.RpmHistory.Count == 0 && workspace.RpmText == "—", "Disconnect clears stale measurements.");
Click("ConnectButton"); Finish(workspace.ConnectCommand.ExecutionTask); Click("ScanButton"); Finish(workspace.ScanCommand.ExecutionTask);
Expect(workspace.FaultCount == 2, "New demo session deliberately starts with example faults.");
Pass("Disconnect clears stale state; a new simulator session consistently starts with its documented fixture.");

var cancelled = new SimulatedDiagnosticAdapter(TimeSpan.FromMilliseconds(20));
using (var cts = new CancellationTokenSource())
{
    cts.Cancel(); var task = cancelled.ConnectAsync(cts.Token);
    try { Finish(task); throw new InvalidOperationException("Cancellation was ignored."); } catch (OperationCanceledException) { }
    Expect(!cancelled.IsConnected, "Cancelled connect must never report connected.");
}
try { Finish(cancelled.ScanAsync(CancellationToken.None)); throw new InvalidOperationException("Disconnected scan succeeded."); } catch (InvalidOperationException e) when (e.Message.Contains("Conectează")) { }
Finish(cancelled.DisposeAsync().AsTask());
Pass("Adapter cancellation and disconnected calls fail without creating a fake connection.");

window.Close(); Pump();
Expect(!workspace.IsConnected && !workspace.IsLive, "Closing releases the simulator and live session.");

var noRpm = false;
var breakConnection = false;
var silentReset = false;
FakeReply WifiReply(string command)
{
    if (silentReset && command == "ATZ") return new("", Prompt: false);
    if (breakConnection && command == "03") return new("", Prompt: false, Close: true);
    return new(command switch
    {
        "ATZ"=>"ELM327 v1.5\r", "ATE0" or "ATL0" or "ATS0" or "ATH1" or "ATSP0" or "ATD0"=>"OK\r", "ATDPN"=>"A6\r",
        "0100"=>"7E806410008180000\r", "0902"=>"NO DATA\r", "03"=>"7E80443010130\r", "07" or "0A"=>"NO DATA\r",
        "010C"=>noRpm ? "NO DATA\r" : "7E804410C1AF8\r", "010D"=>"7E803410D2A\r", "0105"=>"7E803410582\r", "ATRV"=>"12.6V\r", _=>"?\r"
    }, FragmentSize: 3);
}
var wifiServer = new FakeElmServer(WifiReply);
try
{
    window = new MainWindow(new SimulatedDiagnosticAdapter(), value => { export = value; return Task.FromResult(true); }, settings => settings.UseWifi ? new ElmWifiDiagnosticAdapter(settings.Host, settings.Port, TimeSpan.FromSeconds(2)) : new SimulatedDiagnosticAdapter());
    workspace = window.Workspace; window.Show(); workspace.CurrentPage = "settings"; Pump();
    window.FindControl<ComboBox>("ConnectionModeSelector")!.SelectedIndex = 1; Pump();
    Expect(workspace.UseWifi && !workspace.IsSimulation, "Selecting Wi-Fi changes the actual connection mode.");
    window.FindControl<TextBox>("WifiHostInput")!.Text = "127.0.0.1";
    window.FindControl<TextBox>("WifiPortInput")!.Text = "0"; Pump();
    Expect(!FindButton("SettingsConnectButton").IsEffectivelyEnabled, "Invalid endpoint cannot connect.");
    window.FindControl<TextBox>("WifiPortInput")!.Text = wifiServer.Port.ToString(); Pump();
    Click("SettingsConnectButton"); Finish(workspace.ConnectCommand.ExecutionTask);
    Expect(workspace.IsConnected && !workspace.IsSimulation && workspace.ProtocolText.Contains("CAN") && workspace.BadgeText.Contains("WI-FI"), "Real adapter selected through actual UI controls.");
    Expect(!window.FindControl<TextBox>("WifiHostInput")!.IsEffectivelyEnabled, "Endpoint immutable while connected.");
    workspace.SelectedConnectionMode = 0; Expect(workspace.UseWifi, "Cannot silently switch to simulator while connected.");
    Click("ScanButton"); Finish(workspace.ScanCommand.ExecutionTask);
    Expect(workspace.FaultCount == 1 && workspace.ModuleCount == 1 && workspace.HasModuleNote, "Real OBD result and partial-service notes.");
    Expect(!FindButton("ClearButton").IsVisible && !workspace.RequestClearCommand.CanExecute(null), "Physical erase unavailable in read-only stage.");
    Click("ExportButton"); Finish(workspace.ExportCommand.ExecutionTask);
    Expect(export.Contains("RAPORT OBD-II") && !export.Contains("RAPORT DE SIMULARE"), "Real export not mislabeled as demo.");
    Pass("Wi-Fi UI: validated IP/port, real TCP driver, immutable active settings, OBD scope/notes and erase disabled.");

    Click("LiveNav"); Click("LiveToggleButton");
    var liveDeadline = DateTime.UtcNow.AddSeconds(5);
    while (workspace.RpmText == "—" && DateTime.UtcNow < liveDeadline) { Finish(workspace.RefreshLiveAsync()); Pump(); Thread.Sleep(2); }
    Expect(workspace.RpmText == "1726" && workspace.SpeedText == "42" && workspace.CoolantText == "90", "Real PID readings reach screen.");
    noRpm = true;
    liveDeadline = DateTime.UtcNow.AddSeconds(5);
    while (workspace.RpmText != "—" && DateTime.UtcNow < liveDeadline) { Finish(workspace.RefreshLiveAsync()); Pump(); Thread.Sleep(2); }
    Expect(workspace.RpmText == "—", "Missing RPM must clear the displayed previous value.");
    breakConnection = true;
    workspace.CurrentPage = "diagnostics"; Pump(); Click("RescanButton"); Finish(workspace.ScanCommand.ExecutionTask);
    Expect(!workspace.IsConnected && !workspace.IsLive && workspace.Modules.Count == 0 && workspace.RpmText == "—", "Link loss clears stale live/session state.");
    Expect(workspace.UseWifi && workspace.BadgeText.Contains("WI-FI") && workspace.Status.Contains("nu a reușit"), "A failed real link never falls back to simulated data.");
    Pass("Live UI: measured values, absent PID shown as —, dropped TCP clears session and never switches to demo.");

    breakConnection = false; silentReset = true;
    workspace.CurrentPage = "settings"; Pump(); Click("SettingsConnectButton");
    Expect(workspace.IsBusy, "Wi-Fi connect is in progress.");
    workspace.CancelOperationCommand.Execute(null); Finish(workspace.ConnectCommand.ExecutionTask);
    Expect(!workspace.IsBusy && !workspace.IsConnected && workspace.Status.Contains("anulată"), "Cancel interrupts connection without claiming success.");
    if (!string.IsNullOrWhiteSpace(output))
    {
        workspace.WifiHost = "192.168.0.10"; workspace.WifiPort = "35000"; Pump(); AvaloniaHeadlessPlatform.ForceRenderTimerTick();
        using var image = window.CaptureRenderedFrame(); image!.Save(Path.Combine(output, "ccr-wifi-settings.png"), PngBitmapEncoderOptions.Default);
    }
    Pass("Wi-Fi connect can be cancelled; edit controls become available again and no connection is fabricated.");
    window.Close(); Pump();
}
finally { Finish(wifiServer.DisposeAsync().AsTask()); }
Console.WriteLine($"SUCCESS: {checks.Count} integration groups passed.");
if (!string.IsNullOrWhiteSpace(output)) File.WriteAllText(Path.Combine(output, "test-results.txt"), string.Join(Environment.NewLine, checks.Select(x => "PASS " + x)) + Environment.NewLine);
