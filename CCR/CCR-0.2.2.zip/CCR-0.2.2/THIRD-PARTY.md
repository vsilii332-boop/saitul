# Componente externe

Interfața și logica CCR din acest pachet au fost scrise pentru proiectul CCR.
Aplicația nu include cod sau baze de date Renault CLIP.

- Avalonia UI 12.1.5 și pachetele Avalonia utilizate de proiect: MIT.
  https://github.com/AvaloniaUI/Avalonia
- .NET: licențele distribuției .NET și ale componentelor runtime/SDK.
  https://github.com/dotnet/runtime
- Fontul Inter, distribuit prin Avalonia.Fonts.Inter: SIL Open Font License 1.1.
  https://github.com/rsms/inter
- SkiaSharp / componentele native Skia, aduse tranzitiv de Avalonia:
  licențele și notificările incluse în pachetele respective.
  https://github.com/mono/SkiaSharp

Acest ZIP conține sursele CCR, nu copii ale SDK-ului sau ale pachetelor NuGet.
La distribuirea unei aplicații compilate trebuie păstrate notificările și
licențele dependențelor efectiv incluse în distribuție.
