using CCR.Core;
using CCR.Core.History;
using Microsoft.Data.Sqlite;

var root = Path.Combine(Path.GetTempPath(), "ccr-history-tests-" + Guid.NewGuid().ToString("N"));
var path = Path.Combine(root, "history.sqlite3");
var checks = new List<string>();
void Expect(bool condition, string description) { if (!condition) throw new InvalidOperationException(description); }
async Task Fails<T>(Func<Task> action) where T : Exception { try { await action(); } catch (T) { return; } throw new InvalidOperationException("Expected " + typeof(T).Name); }
void Pass(string description) { checks.Add(description); Console.WriteLine("PASS " + description); }
SavedDiagnosticSession Fixture(bool simulation, string? id = null, long revision = 1)
{
    var started = new DateTimeOffset(2026, 11, 6, 22, 0, 0, TimeSpan.FromHours(1));
    return new(id ?? Guid.NewGuid().ToString("N"), revision, started, started.AddMinutes(revision), simulation,
        simulation ? null : "VF100000000000001", simulation ? "Simulator CCR" : "ELM327 test", simulation ? "Simulare" : "ISO 14230 KWP", "Citire DTC",
        [new("test", "ECU test", [new("P0130", "Descriere; cu diacritice și \"ghilimele\"")], simulation)],
        [new(started.AddSeconds(20), new(796, 0, 74, 13.9, simulation ? "Tensiune demo" : "Tensiune adaptor"))],
        [new(started.AddSeconds(10), "Citire", "Înregistrare de test")]);
}
void Execute(string sql)
{
    using var db = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = path, Pooling = false }.ToString()); db.Open();
    using var command = db.CreateCommand(); command.CommandText = sql; command.ExecuteNonQuery();
}

try
{
    var store = new SqliteDiagnosticSessionStore(path);
    var real = Fixture(false); var demo = Fixture(true);
    await store.SaveAsync(real); await store.SaveAsync(demo);
    var reopened = new SqliteDiagnosticSessionStore(path);
    var loaded = await reopened.LoadAsync(real.Id);
    Expect(loaded is not null && loaded.Id == real.Id && loaded.Vin == real.Vin && !loaded.IsSimulated, "Identity survives a new store instance.");
    Expect(loaded!.Modules[0].Faults[0].Description == real.Modules[0].Faults[0].Description && loaded.Samples[0].Values.Rpm == 796 && loaded.Events[0].Detail == "Înregistrare de test", "Full DTC, live and event snapshot round-trip.");
    Expect((await reopened.ListAsync()).Count == 2, "Both independent sessions are retained.");
    Pass("SQLite persistence survives reopen and preserves VIN/mode, DTC descriptions, live samples and session events.");

    var latest = real with { Revision = 3, SavedAt = real.SavedAt.AddHours(1), Reason = "Închidere aplicație", Modules = [real.Modules[0] with { Faults = [] }] };
    await reopened.SaveAsync(latest); await store.SaveAsync(real with { Revision = 2, Reason = "stale live write" });
    loaded = await reopened.LoadAsync(real.Id);
    Expect(loaded!.Revision == 3 && loaded.Reason == "Închidere aplicație" && loaded.Modules[0].Faults.Count == 0, "Older asynchronous snapshots cannot overwrite final data.");
    Expect((await store.ListAsync()).Count == 2, "Updating a session does not duplicate it.");
    await Fails<InvalidDataException>(() => store.SaveAsync(latest with { Revision = 4, Vin = "VF100000000000002" }));
    Expect((await store.LoadAsync(real.Id))!.Vin == real.Vin, "Identity rejection rolls back without damaging the stored session.");
    Pass("Atomic revision updates, stale-write protection, no duplicate sessions and immutable vehicle identity.");

    Expect((await store.ListAsync(simulated: true)).Single().Id == demo.Id && (await store.ListAsync(simulated: false)).Single().Id == real.Id, "Real/demo filters are separate.");
    Expect((await store.ListAsync(search: "000001")).Single().Id == real.Id, "VIN substring search.");
    Expect((await store.ListAsync(search: "%")).Count == 0 && (await store.ListAsync(search: "_")).Count == 0 && (await store.ListAsync(search: "' OR 1=1--")).Count == 0, "Search is literal and parameterized.");
    Expect((await store.ListAsync())[0].Id == real.Id, "Newest saved session comes first.");
    Pass("Real/demo filtering, VIN lookup, literal wildcard handling and SQL-injection-resistant searches.");

    await store.DeleteAsync(demo.Id);
    Expect(await store.LoadAsync(demo.Id) is null && (await store.ListAsync()).Single().Id == real.Id, "Delete is scoped to one record.");
    await Fails<InvalidOperationException>(() => reopened.SaveAsync(demo with { Revision = 99 }));
    Expect(await reopened.LoadAsync(demo.Id) is null, "An old application instance cannot resurrect a deleted session.");
    Pass("Scoped deletion and tombstones prevent a delayed autosave from restoring a deleted session.");

    var count = (await store.ListAsync()).Count;
    using (var cancelled = new CancellationTokenSource())
    {
        cancelled.Cancel(); await Fails<OperationCanceledException>(() => store.SaveAsync(Fixture(true), cancelled.Token));
    }
    await Fails<InvalidDataException>(() => store.SaveAsync(real with { Id = Guid.NewGuid().ToString("N"), Samples = Enumerable.Repeat(real.Samples[0], 61).ToArray() }));
    await Fails<InvalidDataException>(() => store.SaveAsync(real with { Id = Guid.NewGuid().ToString("N"), IsSimulated = true }));
    await Fails<ArgumentException>(() => store.DeleteAsync("' OR 1=1--"));
    Expect((await store.ListAsync()).Count == count, "Rejected writes leave existing records unchanged.");
    if (!OperatingSystem.IsWindows())
    {
        var other = UnixFileMode.GroupRead | UnixFileMode.GroupWrite | UnixFileMode.OtherRead | UnixFileMode.OtherWrite;
        Expect((File.GetUnixFileMode(path) & other) == 0, "Database permissions should be private to the current user.");
    }
    Pass("Cancellation/invalid snapshots do not create partial records; Unix database permissions are private.");

    var simultaneous = Enumerable.Range(0, 8).Select(_ => new SqliteDiagnosticSessionStore(path).SaveAsync(Fixture(true))).ToArray();
    await Task.WhenAll(simultaneous);
    Expect((await store.ListAsync()).Count == count + 8, "Concurrent store instances preserve every committed session.");
    Execute("UPDATE sessions SET payload='not-json' WHERE id='" + real.Id + "'");
    await Fails<InvalidDataException>(() => store.LoadAsync(real.Id));
    Expect((await store.ListAsync()).Count == count + 8, "Unreadable payload is not silently deleted.");
    Execute("PRAGMA user_version=9");
    await Fails<NotSupportedException>(() => new SqliteDiagnosticSessionStore(path).ListAsync());
    Execute("PRAGMA user_version=1");
    Expect((await store.ListAsync()).Count == count + 8, "Future schema rejection does not reset the database.");
    Pass("Concurrent writers, corrupted payload handling and forward-schema rejection preserve existing data.");

    Console.WriteLine($"SUCCESS: {checks.Count} history integration groups passed.");
    var output = Environment.GetEnvironmentVariable("CCR_TEST_ARTIFACTS");
    if (!string.IsNullOrWhiteSpace(output)) { Directory.CreateDirectory(output); await File.WriteAllTextAsync(Path.Combine(output, "history-tests.txt"), string.Join(Environment.NewLine, checks.Select(x => "PASS " + x)) + Environment.NewLine); }
    return 0;
}
catch (Exception error) { Console.Error.WriteLine(error); return 1; }
finally { if (Directory.Exists(root)) Directory.Delete(root, true); }
