using System.Globalization;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;

namespace CCR.Core.History;

public sealed class SqliteDiagnosticSessionStore : IDiagnosticSessionStore
{
    private readonly SemaphoreSlim _gate = new(1);
    public string StoragePath { get; }
    public SqliteDiagnosticSessionStore(string databasePath) => StoragePath = Path.GetFullPath(databasePath);

    public static string DefaultPath()
    {
        var parent = OperatingSystem.IsMacOS()
            ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Library", "Application Support")
            : Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        if (string.IsNullOrWhiteSpace(parent)) throw new IOException("Folderul local de date nu este disponibil.");
        return Path.Combine(parent, "CCR", "history.sqlite3");
    }

    public Task SaveAsync(SavedDiagnosticSession session, CancellationToken cancellationToken = default)
    {
        Validate(session);
        var payload = JsonSerializer.Serialize(session);
        if (Encoding.UTF8.GetByteCount(payload) > 4 * 1024 * 1024) throw new InvalidDataException("Sesiunea depășește limita de salvare locală.");
        return RunAsync((db, token) =>
        {
            using var transaction = db.BeginTransaction();
            using (var deleted = db.CreateCommand())
            {
                deleted.Transaction = transaction; deleted.CommandText = "SELECT 1 FROM deleted_sessions WHERE id=$id";
                deleted.Parameters.AddWithValue("$id", session.Id);
                if (deleted.ExecuteScalar() is not null) throw new InvalidOperationException("Sesiunea a fost ștearsă din istoricul local.");
            }
            using (var identity = db.CreateCommand())
            {
                identity.Transaction = transaction; identity.CommandText = "SELECT started_at,is_simulated,vin FROM sessions WHERE id=$id";
                identity.Parameters.AddWithValue("$id", session.Id); using var existing = identity.ExecuteReader();
                if (existing.Read() && (existing.GetString(0) != Date(session.StartedAt) || (existing.GetInt64(1) != 0) != session.IsSimulated || (existing.IsDBNull(2) ? null : existing.GetString(2)) != session.Vin))
                    throw new InvalidDataException("Identitatea unei sesiuni salvate nu poate fi schimbată.");
            }
            using var command = db.CreateCommand(); command.Transaction = transaction;
            command.CommandText = """
                INSERT INTO sessions(id,revision,started_at,saved_at,is_simulated,vin,module_count,fault_count,reason,payload)
                VALUES($id,$revision,$started,$saved,$mode,$vin,$modules,$faults,$reason,$payload)
                ON CONFLICT(id) DO UPDATE SET revision=excluded.revision,saved_at=excluded.saved_at,
                  module_count=excluded.module_count,fault_count=excluded.fault_count,reason=excluded.reason,payload=excluded.payload
                WHERE excluded.revision > sessions.revision
                """;
            command.Parameters.AddWithValue("$id", session.Id); command.Parameters.AddWithValue("$revision", session.Revision);
            command.Parameters.AddWithValue("$started", Date(session.StartedAt)); command.Parameters.AddWithValue("$saved", Date(session.SavedAt));
            command.Parameters.AddWithValue("$mode", session.IsSimulated ? 1 : 0); command.Parameters.AddWithValue("$vin", (object?)session.Vin ?? DBNull.Value);
            command.Parameters.AddWithValue("$modules", session.Modules.Count); command.Parameters.AddWithValue("$faults", session.Modules.Sum(m => m.Faults.Count));
            command.Parameters.AddWithValue("$reason", session.Reason); command.Parameters.AddWithValue("$payload", payload);
            command.ExecuteNonQuery(); token.ThrowIfCancellationRequested(); transaction.Commit(); return true;
        }, cancellationToken);
    }

    public Task<IReadOnlyList<DiagnosticSessionSummary>> ListAsync(string search = "", bool? simulated = null, CancellationToken cancellationToken = default) => RunAsync<IReadOnlyList<DiagnosticSessionSummary>>((db, token) =>
    {
        using var command = db.CreateCommand();
        command.CommandText = """
            SELECT id,revision,started_at,saved_at,is_simulated,vin,module_count,fault_count,reason FROM sessions
            WHERE ($mode IS NULL OR is_simulated=$mode) AND ($empty=1 OR vin LIKE $search ESCAPE '\')
            ORDER BY saved_at DESC,id DESC LIMIT 100
            """;
        var term = search.Trim().Replace("\\", "\\\\").Replace("%", "\\%").Replace("_", "\\_");
        command.Parameters.AddWithValue("$mode", simulated.HasValue ? simulated.Value ? 1 : 0 : DBNull.Value);
        command.Parameters.AddWithValue("$empty", term.Length == 0 ? 1 : 0); command.Parameters.AddWithValue("$search", "%" + term + "%");
        var rows = new List<DiagnosticSessionSummary>(); using var reader = command.ExecuteReader();
        while (reader.Read())
        {
            token.ThrowIfCancellationRequested();
            rows.Add(new(reader.GetString(0), reader.GetInt64(1), ParseDate(reader.GetString(2)), ParseDate(reader.GetString(3)), reader.GetInt64(4) != 0,
                reader.IsDBNull(5) ? null : reader.GetString(5), reader.GetInt32(6), reader.GetInt32(7), reader.GetString(8)));
        }
        return rows;
    }, cancellationToken);

    public Task<SavedDiagnosticSession?> LoadAsync(string id, CancellationToken cancellationToken = default)
    {
        ValidateId(id);
        return RunAsync<SavedDiagnosticSession?>((db, token) =>
        {
            using var command = db.CreateCommand(); command.CommandText = "SELECT revision,is_simulated,vin,payload FROM sessions WHERE id=$id";
            command.Parameters.AddWithValue("$id", id); using var reader = command.ExecuteReader();
            if (!reader.Read()) return null;
            token.ThrowIfCancellationRequested();
            SavedDiagnosticSession session;
            try { session = JsonSerializer.Deserialize<SavedDiagnosticSession>(reader.GetString(3)) ?? throw new InvalidDataException("Sesiunea salvată este goală."); }
            catch (JsonException error) { throw new InvalidDataException("Datele sesiunii salvate nu pot fi citite.", error); }
            Validate(session);
            if (session.Id != id || session.Revision != reader.GetInt64(0) || session.IsSimulated != (reader.GetInt64(1) != 0) || session.Vin != (reader.IsDBNull(2) ? null : reader.GetString(2)))
                throw new InvalidDataException("Datele sesiunii nu corespund metadatelor salvate.");
            return session;
        }, cancellationToken);
    }

    public Task DeleteAsync(string id, CancellationToken cancellationToken = default)
    {
        ValidateId(id);
        return RunAsync((db, token) =>
        {
            using var transaction = db.BeginTransaction(); using var command = db.CreateCommand(); command.Transaction = transaction;
            command.CommandText = "INSERT OR IGNORE INTO deleted_sessions(id) VALUES($id); DELETE FROM sessions WHERE id=$id";
            command.Parameters.AddWithValue("$id", id); command.ExecuteNonQuery(); token.ThrowIfCancellationRequested(); transaction.Commit(); return true;
        }, cancellationToken);
    }

    private async Task<T> RunAsync<T>(Func<SqliteConnection, CancellationToken, T> action, CancellationToken token)
    {
        await _gate.WaitAsync(token).ConfigureAwait(false);
        try
        {
            return await Task.Run(() =>
            {
                token.ThrowIfCancellationRequested();
                var directory = Path.GetDirectoryName(StoragePath)!;
                if (OperatingSystem.IsWindows()) Directory.CreateDirectory(directory);
                else Directory.CreateDirectory(directory, UnixFileMode.UserRead | UnixFileMode.UserWrite | UnixFileMode.UserExecute);
                using var db = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = StoragePath, Mode = SqliteOpenMode.ReadWriteCreate, Pooling = false, DefaultTimeout = 3 }.ToString());
                db.Open();
                if (!OperatingSystem.IsWindows()) File.SetUnixFileMode(StoragePath, UnixFileMode.UserRead | UnixFileMode.UserWrite);
                EnsureSchema(db, token);
                return action(db, token);
            }, token).ConfigureAwait(false);
        }
        finally { _gate.Release(); }
    }

    private static void EnsureSchema(SqliteConnection db, CancellationToken token)
    {
        using var version = db.CreateCommand(); version.CommandText = "PRAGMA user_version";
        var current = Convert.ToInt32(version.ExecuteScalar(), CultureInfo.InvariantCulture);
        if (current > 1) throw new NotSupportedException("Istoricul a fost creat de o versiune mai nouă a CCR.");
        if (current == 1) return;
        token.ThrowIfCancellationRequested(); using var transaction = db.BeginTransaction(); using var create = db.CreateCommand(); create.Transaction = transaction;
        create.CommandText = """
            CREATE TABLE IF NOT EXISTS sessions (
              id TEXT PRIMARY KEY, revision INTEGER NOT NULL CHECK(revision>0),
              started_at TEXT NOT NULL,saved_at TEXT NOT NULL,is_simulated INTEGER NOT NULL CHECK(is_simulated IN(0,1)),
              vin TEXT,module_count INTEGER NOT NULL,fault_count INTEGER NOT NULL,reason TEXT NOT NULL,payload TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS sessions_saved ON sessions(saved_at DESC);
            CREATE INDEX IF NOT EXISTS sessions_vin ON sessions(vin);
            CREATE TABLE IF NOT EXISTS deleted_sessions(id TEXT PRIMARY KEY);
            PRAGMA user_version=1;
            """;
        create.ExecuteNonQuery(); token.ThrowIfCancellationRequested(); transaction.Commit();
    }
    private static void ValidateId(string id) { if (!Guid.TryParseExact(id, "N", out _)) throw new ArgumentException("Identificator de sesiune invalid.", nameof(id)); }
    private static void Validate(SavedDiagnosticSession session)
    {
        ValidateId(session.Id);
        if (session.Revision < 1 || session.Modules is null || session.Samples is null || session.Events is null || session.Samples.Count > 60 || session.Events.Count > 100)
            throw new InvalidDataException("Structura sesiunii salvate nu este validă.");
        if (session.Modules.Any(m => m is null || m.IsSimulated != session.IsSimulated || m.Faults is null) || session.Samples.Any(s => s is null || s.Values is null) || session.Events.Any(e => e is null) || (session.IsSimulated && session.Vin is not null))
            throw new InvalidDataException("Datele simulate și cele reale nu pot fi amestecate în aceeași sesiune.");
    }
    private static string Date(DateTimeOffset value) => value.ToUniversalTime().ToString("O", CultureInfo.InvariantCulture);
    private static DateTimeOffset ParseDate(string value) => DateTimeOffset.ParseExact(value, "O", CultureInfo.InvariantCulture, DateTimeStyles.None);
}
