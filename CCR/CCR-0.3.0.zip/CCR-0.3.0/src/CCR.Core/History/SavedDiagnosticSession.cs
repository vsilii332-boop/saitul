namespace CCR.Core.History;

public sealed record SavedLiveSample(DateTimeOffset Time, LiveSnapshot Values);
public sealed record SavedSessionEvent(DateTimeOffset Time, string Action, string Detail);

public sealed record SavedDiagnosticSession(
    string Id, long Revision, DateTimeOffset StartedAt, DateTimeOffset SavedAt,
    bool IsSimulated, string? Vin, string Adapter, string Protocol, string Reason,
    IReadOnlyList<DiagnosticModule> Modules, IReadOnlyList<SavedLiveSample> Samples,
    IReadOnlyList<SavedSessionEvent> Events);

public sealed record DiagnosticSessionSummary(string Id, long Revision, DateTimeOffset StartedAt,
    DateTimeOffset SavedAt, bool IsSimulated, string? Vin, int ModuleCount, int FaultCount, string Reason);

public interface IDiagnosticSessionStore
{
    string StoragePath { get; }
    Task SaveAsync(SavedDiagnosticSession session, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<DiagnosticSessionSummary>> ListAsync(string search = "", bool? simulated = null, CancellationToken cancellationToken = default);
    Task<SavedDiagnosticSession?> LoadAsync(string id, CancellationToken cancellationToken = default);
    Task DeleteAsync(string id, CancellationToken cancellationToken = default);
}
