using System.Collections.ObjectModel;
using System.Globalization;
using CCR.Core;

namespace CCR.Desktop.ViewModels;

public sealed record SessionEntry(string Time, string Action, string Detail);

public sealed class WorkspaceViewModel : ObservableObject, IAsyncDisposable
{
    private readonly IDiagnosticAdapter _adapter;
    private readonly Func<string, Task<bool>> _saveReport;
    private readonly CancellationTokenSource _lifetime = new();
    private string _currentPage = "overview", _status = "Pregătit. Conectează simulatorul pentru a începe.";
    private bool _connected, _busy, _isLive, _confirmation, _disposed, _polling;
    private DiagnosticModule? _selectedModule;
    private LiveSnapshot? _live;
    private IReadOnlyList<double> _rpmHistory = [];

    public WorkspaceViewModel(IDiagnosticAdapter adapter, Func<string, Task<bool>> saveReport)
    {
        _adapter = adapter; _saveReport = saveReport;
        NavigateCommand = new(p => CurrentPage = p as string ?? "overview");
        ConnectCommand = new(() => RunAsync("Conectare la simulator…", ConnectAsync), () => !IsConnected && !IsBusy, HandleError);
        DisconnectCommand = new(() => RunAsync("Deconectare…", DisconnectAsync), () => IsConnected && !IsBusy, HandleError);
        ScanCommand = new(() => RunAsync("Scanare module demonstrative…", ScanAsync), () => IsConnected && !IsBusy, HandleError);
        RequestClearCommand = new(_ => ConfirmationVisible = true, () => IsConnected && !IsBusy && Faults.Count > 0);
        CancelClearCommand = new(_ => ConfirmationVisible = false, () => !IsBusy);
        ConfirmClearCommand = new(() => RunAsync("Ștergere erori din simulare…", ClearAsync), () => ConfirmationVisible && IsConnected && !IsBusy, HandleError);
        ToggleLiveCommand = new(_ => { IsLive = !IsLive; Log(IsLive ? "Date live pornite" : "Date live oprite", "Valori generate local de simulator."); }, () => IsConnected && !IsBusy);
        ExportCommand = new(() => RunAsync("Pregătire raport CSV…", ExportAsync), () => Modules.Count > 0 && !IsBusy, HandleError);
        Log("Aplicație pornită", "CCR 0.1.1 · mod demonstrativ. Nicio conexiune cu un vehicul.");
    }

    public ObservableCollection<DiagnosticModule> Modules { get; } = [];
    public ObservableCollection<DiagnosticFault> Faults { get; } = [];
    public ObservableCollection<SessionEntry> History { get; } = [];
    public RelayCommand NavigateCommand { get; }
    public AsyncCommand ConnectCommand { get; }
    public AsyncCommand DisconnectCommand { get; }
    public AsyncCommand ScanCommand { get; }
    public RelayCommand RequestClearCommand { get; }
    public RelayCommand CancelClearCommand { get; }
    public AsyncCommand ConfirmClearCommand { get; }
    public RelayCommand ToggleLiveCommand { get; }
    public AsyncCommand ExportCommand { get; }

    public string CurrentPage
    {
        get => _currentPage;
        set
        {
            if (value is not ("overview" or "diagnostics" or "live" or "service" or "programming" or "history" or "settings")) return;
            if (!Set(ref _currentPage, value)) return;
            foreach (var name in new[] { nameof(PageTitle), nameof(IsOverview), nameof(IsDiagnostics), nameof(IsLivePage), nameof(IsService), nameof(IsProgramming), nameof(IsHistory), nameof(IsSettings) }) Notify(name);
        }
    }
    public string PageTitle => CurrentPage switch { "diagnostics"=>"Diagnoză", "live"=>"Date live", "service"=>"Operațiuni service", "programming"=>"Programare", "history"=>"Istoric sesiune", "settings"=>"Conexiune și setări", _=>"Prezentare generală" };
    public bool IsOverview => CurrentPage == "overview";
    public bool IsDiagnostics => CurrentPage == "diagnostics";
    public bool IsLivePage => CurrentPage == "live";
    public bool IsService => CurrentPage == "service";
    public bool IsProgramming => CurrentPage == "programming";
    public bool IsHistory => CurrentPage == "history";
    public bool IsSettings => CurrentPage == "settings";
    public bool IsConnected { get => _connected; private set { if (Set(ref _connected, value)) { Notify(nameof(IsDisconnected)); Notify(nameof(ConnectionLabel)); RefreshCommands(); } } }
    public bool IsDisconnected => !IsConnected;
    public bool IsBusy { get => _busy; private set { if (Set(ref _busy, value)) RefreshCommands(); } }
    public bool IsLive { get => _isLive; private set { if (Set(ref _isLive, value)) Notify(nameof(LiveButtonLabel)); } }
    public string LiveButtonLabel => IsLive ? "Oprește datele live" : "Pornește datele live";
    public bool ConfirmationVisible { get => _confirmation; private set { if (Set(ref _confirmation, value)) RefreshCommands(); } }
    public string ConnectionLabel => IsConnected ? "Simulator conectat" : "Deconectat";
    public string Status { get => _status; private set => Set(ref _status, value); }
    public int ModuleCount => Modules.Count;
    public int FaultCount => Modules.Sum(x => x.Faults.Count);
    public bool HasModules => Modules.Count > 0;
    public bool HasNoModules => !HasModules;
    public bool HasFaults => Faults.Count > 0;
    public bool HasNoFaults => !HasFaults && SelectedModule is not null;
    public string SelectedModuleName => SelectedModule?.Name ?? "Alege un modul după scanare";
    public DiagnosticModule? SelectedModule
    {
        get => _selectedModule;
        set { if (!Set(ref _selectedModule, value)) return; UpdateFaults(); Notify(nameof(SelectedModuleName)); }
    }
    public string RpmText => _live?.Rpm.ToString(CultureInfo.InvariantCulture) ?? "—";
    public string SpeedText => _live?.SpeedKph.ToString(CultureInfo.InvariantCulture) ?? "—";
    public string CoolantText => _live?.CoolantCelsius.ToString(CultureInfo.InvariantCulture) ?? "—";
    public string VoltageText => _live?.Voltage.ToString("F2", CultureInfo.GetCultureInfo("ro-RO")) ?? "—";
    public IReadOnlyList<double> RpmHistory { get => _rpmHistory; private set => Set(ref _rpmHistory, value); }

    private async Task ConnectAsync()
    {
        await _adapter.ConnectAsync(_lifetime.Token);
        IsConnected = true; ResetReadings();
        Status = "Simulator conectat. Poți începe scanarea demonstrativă.";
        Log("Conectare", "Simulator CCR · fără adaptor fizic.");
    }
    private async Task DisconnectAsync()
    {
        IsLive = false; await _adapter.DisconnectAsync(); IsConnected = false;
        ConfirmationVisible = false; Modules.Clear(); SelectedModule = null; UpdateFaults(); ResetReadings(); UpdateCounts();
        Status = "Simulator deconectat."; Log("Deconectare", "Sesiunea de simulare a fost închisă.");
    }
    private async Task ScanAsync()
    {
        var modules = await _adapter.ScanAsync(_lifetime.Token);
        ReplaceModules(modules);
        CurrentPage = "diagnostics";
        Status = $"Scanare demo finalizată: {ModuleCount} module, {FaultCount} erori.";
        Log("Scanare", $"{ModuleCount} module simulate · {FaultCount} erori. Exemplele nu provin dintr-un vehicul.");
    }
    private async Task ClearAsync()
    {
        var module = SelectedModule ?? throw new InvalidOperationException("Alege mai întâi un modul.");
        try
        {
            await _adapter.ClearFaultsAsync(module.Id, _lifetime.Token);
            ReplaceModules(await _adapter.ScanAsync(_lifetime.Token), module.Id);
            Status = "Erorile modulului au fost șterse din simulare.";
            Log("Ștergere DTC · demo", module.Name + " · nu a fost trimisă nicio comandă unui vehicul.");
        }
        finally { ConfirmationVisible = false; }
    }
    private async Task ExportAsync()
    {
        var saved = await _saveReport(DiagnosticReport.ToCsv(Modules, DateTimeOffset.Now));
        Status = saved ? "Raportul de simulare a fost exportat." : "Export anulat.";
        if (saved) Log("Export CSV", "Raport de simulare salvat în locația aleasă.");
    }
    private async Task RunAsync(string status, Func<Task> action)
    {
        if (_disposed || IsBusy) return;
        IsBusy = true; Status = status;
        try { await action(); }
        finally { IsBusy = false; }
    }
    public async Task RefreshLiveAsync()
    {
        if (_disposed || !IsConnected || !IsLive || IsBusy || _polling) return;
        _polling = true;
        try
        {
            var value = await _adapter.ReadLiveAsync(_lifetime.Token);
            if (_disposed || !IsConnected || !IsLive) return;
            _live = value; RpmHistory = RpmHistory.Append((double)value.Rpm).TakeLast(60).ToArray(); NotifyReadings();
        }
        catch (OperationCanceledException) { }
        catch (Exception error) { IsLive = false; HandleError(error); }
        finally { _polling = false; }
    }
    private void ReplaceModules(IReadOnlyList<DiagnosticModule> modules, string? selectedId = null)
    {
        Modules.Clear(); foreach (var module in modules) Modules.Add(module);
        SelectedModule = Modules.FirstOrDefault(x => x.Id == selectedId) ?? Modules.FirstOrDefault(); UpdateCounts();
    }
    private void UpdateFaults()
    {
        Faults.Clear(); foreach (var fault in SelectedModule?.Faults ?? []) Faults.Add(fault);
        Notify(nameof(HasFaults)); Notify(nameof(HasNoFaults)); RefreshCommands();
    }
    private void UpdateCounts() { Notify(nameof(ModuleCount)); Notify(nameof(FaultCount)); Notify(nameof(HasModules)); Notify(nameof(HasNoModules)); RefreshCommands(); }
    private void ResetReadings() { _live = null; RpmHistory = []; NotifyReadings(); }
    private void NotifyReadings() { Notify(nameof(RpmText)); Notify(nameof(SpeedText)); Notify(nameof(CoolantText)); Notify(nameof(VoltageText)); }
    private void RefreshCommands()
    {
        ConnectCommand?.Refresh(); DisconnectCommand?.Refresh(); ScanCommand?.Refresh(); RequestClearCommand?.Refresh(); CancelClearCommand?.Refresh(); ConfirmClearCommand?.Refresh(); ToggleLiveCommand?.Refresh(); ExportCommand?.Refresh();
    }
    private void Log(string action, string detail)
    {
        History.Insert(0, new(DateTimeOffset.Now.ToString("HH:mm:ss"), action, detail));
        while (History.Count > 200) History.RemoveAt(History.Count - 1);
    }
    private void HandleError(Exception error) { Status = "Operațiunea nu a reușit: " + error.Message; Log("Eroare", error.Message); }
    public async ValueTask DisposeAsync()
    {
        if (_disposed) return; _disposed = true; IsLive = false; _lifetime.Cancel();
        await _adapter.DisposeAsync(); IsConnected = false; _lifetime.Dispose();
    }
}
