using System.Globalization;
using System.Text;

namespace CCR.Core;

public static class DiagnosticReport
{
    public static string ToCsv(IEnumerable<DiagnosticModule> modules, DateTimeOffset createdAt)
    {
        var text = new StringBuilder();
        text.AppendLine("\"CCR\",\"RAPORT DE SIMULARE - FARA VEHICUL REAL\"");
        text.AppendLine($"\"Data\",{Cell(createdAt.ToString("O", CultureInfo.InvariantCulture))}");
        text.AppendLine("\"Modul\",\"Cod DTC\",\"Descriere\",\"Stare\"");
        foreach (var module in modules)
        {
            if (module.Faults.Count == 0) text.AppendLine($"{Cell(module.Name)},\"\",\"Fara erori\",\"SIMULARE\"");
            foreach (var fault in module.Faults) text.AppendLine($"{Cell(module.Name)},{Cell(fault.Code)},{Cell(fault.Description)},{Cell(fault.Status)}");
        }
        return text.ToString();
    }

    private static string Cell(string value)
    {
        // Keep spreadsheet applications from interpreting external text as a formula.
        if (value.TrimStart().FirstOrDefault() is '=' or '+' or '-' or '@') value = "'" + value;
        return "\"" + value.Replace("\"", "\"\"") + "\"";
    }
}
