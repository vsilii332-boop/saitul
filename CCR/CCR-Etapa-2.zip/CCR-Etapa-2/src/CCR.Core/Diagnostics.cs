namespace CCR.Core;

public sealed record DiagnosticFault(string Code, string Description, string Status = "Memorat · demo");

public sealed record DiagnosticModule(string Id, string Name, IReadOnlyList<DiagnosticFault> Faults)
{
    public string FaultSummary => Faults.Count == 0 ? "Fără erori · demo" : $"{Faults.Count} erori · demo";
}

public sealed record LiveSnapshot(int Rpm, int SpeedKph, int CoolantCelsius, double Voltage);

public interface IDiagnosticAdapter : IAsyncDisposable
{
    bool IsConnected { get; }
    Task ConnectAsync(CancellationToken cancellationToken);
    Task DisconnectAsync();
    Task<IReadOnlyList<DiagnosticModule>> ScanAsync(CancellationToken cancellationToken);
    Task ClearFaultsAsync(string moduleId, CancellationToken cancellationToken);
    Task<LiveSnapshot> ReadLiveAsync(CancellationToken cancellationToken);
}

/// <summary>Local demonstration only. Never opens a network, Bluetooth or serial connection.</summary>
public sealed class SimulatedDiagnosticAdapter : IDiagnosticAdapter
{
    private bool _disposed;
    private int _tick;
    private DiagnosticFault[] _engineFaults = [];
    private readonly TimeSpan _delay;
    public bool IsConnected { get; private set; }

    public SimulatedDiagnosticAdapter(TimeSpan? delay = null) => _delay = delay ?? TimeSpan.FromMilliseconds(450);

    public async Task ConnectAsync(CancellationToken cancellationToken)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (IsConnected) return;
        await Task.Delay(_delay, cancellationToken);
        cancellationToken.ThrowIfCancellationRequested();
        _engineFaults = [new("P0130", "Circuit senzor oxigen · banca 1, senzor 1"), new("P0300", "Rateuri aleatorii sau multiple detectate")];
        _tick = 0;
        IsConnected = true;
    }

    public Task DisconnectAsync() { IsConnected = false; return Task.CompletedTask; }

    public async Task<IReadOnlyList<DiagnosticModule>> ScanAsync(CancellationToken cancellationToken)
    {
        RequireConnection();
        await Task.Delay(_delay, cancellationToken);
        RequireConnection();
        return [new("engine", "Injecție / motor", _engineFaults.ToArray()), new("abs", "ABS / frânare", []), new("uch", "UCH / caroserie", [])];
    }

    public async Task ClearFaultsAsync(string moduleId, CancellationToken cancellationToken)
    {
        RequireConnection();
        if (moduleId is not ("engine" or "abs" or "uch")) throw new ArgumentException("Modul demonstrativ necunoscut.", nameof(moduleId));
        await Task.Delay(_delay, cancellationToken);
        RequireConnection();
        if (moduleId == "engine") _engineFaults = [];
    }

    public async Task<LiveSnapshot> ReadLiveAsync(CancellationToken cancellationToken)
    {
        RequireConnection();
        await Task.Delay(TimeSpan.FromMilliseconds(15), cancellationToken);
        RequireConnection();
        var wave = Math.Sin(++_tick * .18);
        return new((int)(1550 + 650 * wave), (int)(32 + 16 * Math.Sin(_tick * .07)), (int)(88 + 3 * Math.Sin(_tick * .03)), 14.1 + .15 * wave);
    }

    private void RequireConnection()
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (!IsConnected) throw new InvalidOperationException("Conectează mai întâi simulatorul.");
    }

    public ValueTask DisposeAsync() { IsConnected = false; _disposed = true; return ValueTask.CompletedTask; }
}
