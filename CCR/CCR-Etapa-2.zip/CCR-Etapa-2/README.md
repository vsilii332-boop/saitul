# CCR · Car Control & Repair

**Etapa 2 · versiunea 0.1.1 · interfață proprie și simulator local**

Aplicație pentru macOS Apple Silicon, construită cu C# / .NET 10 și Avalonia.
Acest pachet conține codul sursă complet al acestei etape. Nu este un program
de instalare și nu conține SDK-ul .NET sau pachetele descărcate din NuGet.

## Ce faci acum pe Mac

1. Închide fereastra veche „Welcome to Avalonia!”.
2. Dezarhivează pachetul. Folderul rezultat se numește `CCR-Etapa-2`.
3. Dacă l-ai dezarhivat în Downloads, deschide Terminal și execută:

```bash
cd ~/Downloads/CCR-Etapa-2
dotnet run --project src/CCR.Desktop/CCR.Desktop.csproj
```

Prima pornire descarcă automat pachetele necesare și are nevoie de internet.
Simulatorul funcționează apoi local. Folderul vechi `CCR` poate fi păstrat;
nu este nevoie să copiezi aceste fișiere peste proiectul inițial.

Pentru a deschide codul în Visual Studio Code, din același folder:

```bash
code .
```

## Ce testezi în fereastră

1. În **Prezentare generală**, apasă **Conectează simulatorul**.
2. Apasă **Scanează vehiculul demo**. Se deschide Diagnoză cu trei module
   demonstrative: injecție/motor, ABS și UCH. Motorul are două erori de exemplu.
3. Selectează modulele din listă. Pe motor, încearcă **Șterge erorile din simulare**.
   **Anulează** păstrează erorile; confirmarea le elimină numai din simulator.
   O nouă scanare în aceeași conexiune păstrează rezultatul ștergerii.
4. Deschide **Date live** și apasă **Pornește datele live**. Apar turația,
   viteza, temperatura lichidului de răcire, tensiunea și graficul turației.
   Butonul de oprire păstrează ultima valoare, fără actualizări noi.
5. În **Diagnoză**, **Export CSV** deschide dialogul macOS pentru salvare.
   Raportul este etichetat explicit ca simulare și se poate deschide în Numbers
   sau Excel. Exportul poate fi anulat.
6. **Istoric sesiune** arată operațiile din sesiunea curentă. Istoricul este
   momentan în memorie și se pierde la închiderea aplicației.
7. **Deconectează** oprește datele live și elimină valorile vechi. O reconectare
   creează o nouă sesiune demonstrativă cu erorile inițiale.

## Limitele acestei etape

**Nu există încă o conexiune reală cu un vehicul.** Eticheta DEMO este vizibilă
în toate ecranele. Profilul Renault Clio II din interfață este un exemplu;
aplicația nu a citit un VIN și nu identifică automat o mașină reală.

Citirea și ștergerea DTC, scanarea modulelor și datele live folosesc exclusiv
simulatorul. Nu sunt deschise conexiuni TCP, Bluetooth sau USB și nu sunt
trimise comenzi către ECU-uri.

Meniurile **Service** și **Programare** prezintă module viitoare. Resetările,
adaptările, codarea, programarea ECU, cheile/imobilizatorul și baza de date
cu proceduri nu sunt implementate în această etapă. Un adaptor ieftin nu
garantează suportul viitor pentru fiecare funcție sau fiecare vehicul.

Următoarea etapă: implementarea și testarea comunicației ELM327 prin Wi-Fi,
cu citire OBD-II standard, după identificarea adaptorului și a mașinii.
Bluetooth și USB vor fi adăugate pe baza compatibilității reale cu macOS.

## Structură

- `src/CCR.Core` — contractul adaptorului, simulatorul, modelele și raportul CSV.
- `src/CCR.Desktop` — fereastra Avalonia, navigarea, comenzile și modelul interfeței.
- `tests/CCR.Desktop.Tests` — verificări de integrare ale interfeței și simulatorului.

Dependențele Avalonia sunt fixate la **12.1.5**. SDK-ul necesar este **.NET 10**;
versiunea 10.0.402 instalată pe Macul tău este compatibilă cu proiectul.

Pentru compilare:

```bash
dotnet build CCR.slnx
```

Pentru testele automate:

```bash
dotnet run --project tests/CCR.Desktop.Tests/CCR.Desktop.Tests.csproj
```

Verificările automate folosesc Avalonia Headless și simulatorul. Nu necesită
adaptor OBD și nu accesează un vehicul. Pachetul a fost compilat și verificat
în mediul Linux; lansarea nativă macOS și dialogul de salvare se verifică pe Mac.

## Date și dependențe

Aplicația nu cere cont, parolă sau acces la contactele tale și nu transmite
datele simulatorului unui server. La compilare, .NET descarcă dependențele;
comportamentul instrumentelor SDK este separat de funcționarea aplicației.
Raportul CSV se salvează numai când alegi o locație. Codul acestui pachet nu
conține conturi sau date din proiectul Fahrschule BV.

Avalonia și .NET sunt dependențe externe, cu licențele proprii; vezi
`THIRD-PARTY.md`.
