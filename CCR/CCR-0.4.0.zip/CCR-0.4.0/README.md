# CCR · Car Control & Repair

**Etapa 5 · versiunea 0.4.0 · martor motor și monitoare de emisii OBD-II**

Poți instala și verifica această etapă în casă, cu simulatorul. Nu este necesară
mașina sau interfața OBD pentru testul istoricului.

## Pornirea pe Mac

1. Închide versiunea CCR anterioară.
2. Dezarhivează pachetul în Downloads, în folderul `CCR-0.4.0`.
3. Cu Macul conectat la internet pentru restaurarea dependențelor .NET:

```bash
cd ~/Downloads/CCR-0.4.0 && dotnet run --project src/CCR.Desktop/CCR.Desktop.csproj
```

Nu trebuie instalat separat un server sau un program SQLite. Pachetul .NET
include biblioteca nativă pentru macOS ARM64. Nu copia fișiere peste versiunile
vechi ale proiectului. În interfață trebuie să vezi **CCR 0.4.0 / Etapa 5**.

După prima pornire compilată, funcționarea și istoricul local nu necesită internet.
Pentru pornire fără restaurarea dependențelor:

```bash
cd ~/Downloads/CCR-0.4.0 && dotnet run --no-restore --project src/CCR.Desktop/CCR.Desktop.csproj
```

## Testul din casă, fără mașină

1. Păstrează modul **Simulator** și apasă **Conectează simulatorul**.
2. Apasă **Scanează vehiculul demo**.
3. Poți porni datele live pentru a adăuga câteva eșantioane.
4. Închide normal fereastra CCR. Aplicația finalizează salvarea înainte de ieșire.
5. Pornește din nou aceeași versiune și deschide **Istoric local**.
6. Selectează sesiunea, apoi apasă **Deschide raportul**. Este marcată SIMULARE.
7. Folosește **Export CSV salvat**. Nu trebuie conectat simulatorul pentru a
   deschide sau exporta un raport deja păstrat.

Un raport salvat nu activează conexiunea și nu înlocuiește valorile live din
sesiunea curentă. Poți consulta un raport real vechi chiar când folosești simulatorul.

## Nou: starea emisiilor OBD-II

În **Diagnoză**, apasă **Verifică starea emisiilor** după conectare.
Poți testa interfața în casă cu simulatorul. Pentru date reale, conectează Macul
la rețeaua adaptorului, alege ELM327 Wi-Fi, IP `192.168.0.10`, port `35000`,
apoi conectează cu contactul complet; pe vehiculul testat răspunsul a fost
confirmat cu motorul pornit, mașina staționată într-un loc ventilat.

- Se citește comanda standard **01 01**, numai de la ECU-ul principal.
- **MIL** reprezintă comanda ECU pentru martorul motor, nu o verificare vizuală
  a becului. Numărul DTC raportat este separat de lista codurilor citite.
- Tipul de aprindere raportat de ECU selectează monitoarele pentru benzină
  sau diesel. În **Monitoare de emisii · detalii**, fiecare test apare ca
  **Finalizat / Nefinalizat / Nesuportat**.
- Starea se referă la perioada de la ultima ștergere DTC. Un test nefinalizat
  nu confirmă un defect și rezultatele nu sunt un verdict ITP.
- Un PID nesuportat, refuzat ori fără răspuns nu generează valori presupuse;
  citirea precedentă nu rămâne afișată ca rezultat actual.
- Citirea, data și monitoarele se salvează automat în aceeași sesiune SQLite,
  se redeschid din **Istoric local → Stare emisii salvată** și se exportă în CSV.
  Poți exporta și o citire a emisiilor fără scanarea DTC.
- Rapoartele create cu 0.3.0 rămân accesibile. Nu se resetează baza de date.
  Istoricul vechi nu conține automat date despre emisii care nu au fost citite.

## Ce se păstrează automat

Fiecare conectare creează o sesiune cu identificator propriu. Scanările ulterioare
actualizează aceeași sesiune, în loc să creeze copii la fiecare citire.

Se păstrează tipul real/simulat, momentele sesiunii, VIN-ul când a fost citit,
adaptorul, protocolul, modulele și DTC-urile cu stările și notele lor. Activitatea
sesiunii este limitată la ultimele 100 de evenimente, iar valorile live la ultimele
60 de eșantioane, inclusiv cele cu parametri indisponibili. Nu este încă o
înregistrare nelimitată a tuturor parametrilor de-a lungul întregii diagnoze.

Salvarea are loc la conectare, după citirea DTC, după ștergerea din simulator,
după verificarea emisiilor, la exportul raportului, la fiecare 10 eșantioane live, la oprirea datelor live,
la deconectare, la pierderea conexiunii și la închiderea normală. Oprirea forțată
a procesului sau a calculatorului poate pierde datele de după ultimul punct salvat.

Scrierile sunt tranzacționale, iar numărul de revizie împiedică o salvare întârziată
să suprascrie un rezultat mai nou. Dacă stocarea nu poate fi folosită, apare un
mesaj vizibil; diagnoza poate continua și poți exporta manual raportul curent.

**Sesiunile încep să fie salvate automat din 0.3.0.** Datele care au rămas numai
în memoria versiunilor 0.2.x nu se recuperează automat. Fișierele CSV exportate
anterior rămân fișiere independente și nu sunt importate automat în această etapă.

## Istoric local

- Lista afișează cel mult cele mai recente 100 de sesiuni pentru filtrul ales.
- Poți căuta după VIN sau o parte din el.
- Poți filtra **Toate / Vehicule reale / Simulări**, apoi apăsa **Actualizează**.
- **Deschide raportul** arată data salvării, adaptorul, protocolul, codurile,
  notele de acoperire, ultimul eșantion live și activitatea păstrată.
- **Export CSV salvat** folosește data și tipul sesiunii arhivate, chiar dacă
  aplicația este deconectată ori folosește altă conexiune în prezent.
- **Șterge sesiunea** cere confirmare și elimină doar înregistrarea aleasă.
  Sesiunea conectată nu poate fi ștearsă înainte de deconectare. Un marcaj intern
  cu identificatorul ei împiedică o instanță veche a aplicației să o recreeze
  printr-o scriere întârziată. Marcajul nu păstrează VIN-ul sau raportul șters.

## Unde sunt datele

Pe macOS, baza de date este:

```text
~/Library/Application Support/CCR/history.sqlite3
```

Locația exactă apare și în **Conexiune și setări → Salvare locală**. Acest fișier
este în afara folderului proiectului, astfel încât schimbarea folderului surselor
nu mută și nu resetează istoricul. Pentru o copie manuală, închide mai întâi CCR
și copiază baza de date. Nu înlocui baza existentă cu fișiere din alte surse.

Datele sunt locale; nu sunt trimise unui server. Baza de date nu este criptată;
pe Mac/Linux fișierul primește permisiuni de citire/scriere doar pentru utilizator.
Include VIN-uri și informații despre vehiculele testate, deci păstreaz-o separat
față de fișierele de cod pe care le distribui. ZIP-ul acestei versiuni nu conține
baza de date, rapoartele sau jurnalul mașinii tale.

## Funcțiile OBD-II păstrate

Citirea reală prin ELM327 Wi-Fi, protocolul automat, DTC, VIN și datele live
rămân disponibile ca în etapa 3. **Conexiunea la vehicul este încă doar pentru
citire.** ABS, airbag, UCH, resetările de service, codările și programarea sunt
module viitoare. Butonul de ștergere DTC funcționează numai în simulator.

Mesajele `UNABLE TO CONNECT` și `A0` disting lipsa răspunsului vehiculului de
un protocol neacceptat. `NRC 11` la citirea codurilor permanente indică faptul
că serviciul nu este acceptat de acel ECU; nu este un DTC al mașinii.

Exportul CSV are un singur antet și opt coloane, cu separator **`;`**, UTF-8 și
câmpuri citate. În Numbers sau Excel, dacă se cere separatorul, alege `;`.

## Verificări

Au trecut 36 de grupuri automate, pe Linux, cu date fictive:

- 18 grupuri pentru interfață, inclusiv închidere/restart, citire offline,
  export real din arhivă în timpul folosirii simulatorului, filtre, confirmarea
  ștergerii și funcționarea diagnozei la eroare de stocare.
- 7 grupuri SQLite pentru persistență, tranzacții/revizii, identitate, căutare,
  ștergere, concurență, date corupte, schemă viitoare și permisiuni.
- 11 grupuri OBD/TCP și CSV pentru protocoale, date live, VIN, erori și importul tabelar.

Biblioteca SQLite pentru macOS ARM64 este inclusă prin dependențele NuGet.
Testele includ răspunsuri simulate CAN și K-Line, decodarea diesel/benzină,
stări indisponibile și redeschiderea sesiunilor 0.3.0. Testarea noii citiri
pe vehiculul tău rămâne de făcut; istoricul, CSV-ul și interfața pot fi testate
în casă cu simulatorul.

```bash
dotnet build CCR.slnx -c Release
dotnet run --project tests/CCR.History.Tests/CCR.History.Tests.csproj
dotnet run --project tests/CCR.Obd.Tests/CCR.Obd.Tests.csproj
dotnet run --project tests/CCR.Desktop.Tests/CCR.Desktop.Tests.csproj
```

Dependențe fixate: .NET 10, Avalonia 12.1.5, Microsoft.Data.Sqlite 10.0.14.
Sursele proprii CCR și licențele componentelor externe sunt descrise în
`THIRD-PARTY.md`. Rapoartele și capturile din teste folosesc numai date sintetice.
