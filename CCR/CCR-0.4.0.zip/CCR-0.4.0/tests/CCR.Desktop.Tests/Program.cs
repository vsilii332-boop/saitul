using Avalonia;
using Avalonia.Controls;
using Avalonia.Headless;
using Avalonia.Interactivity;
using Avalonia.Media.Imaging;
using Avalonia.Threading;
using CCR.Core;
using CCR.Core.Elm;
using CCR.Core.History;
using CCR.Obd.Tests;
using CCR.Desktop;
using CCR.Desktop.ViewModels;

// Integration checks use the real Avalonia XAML, bindings, commands and local simulator.
AppBuilder.Configure<App>().UseSkia().UseHeadless(new() { UseHeadlessDrawing = false }).WithInterFont().SetupWithoutStarting();
var checks = new List<string>();
var export = "";
var window = new MainWindow(new SimulatedDiagnosticAdapter(TimeSpan.FromMilliseconds(100)), value => { export = value; return Task.FromResult(true); });
var workspace = window.Workspace;
window.Show();
Pump();

void Expect(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
void Pass(string value) { checks.Add(value); Console.WriteLine("PASS " + value); }
void Pump() => Dispatcher.UIThread.RunJobs();
void Finish(Task task)
{
    var until = DateTime.UtcNow.AddSeconds(10);
    while (!task.IsCompleted && DateTime.UtcNow < until) { Pump(); Thread.Sleep(2); }
    Expect(task.IsCompleted, "Operation exceeded test deadline.");
    task.GetAwaiter().GetResult(); Pump();
}
Button FindButton(string name) => window.FindControl<Button>(name) ?? throw new InvalidOperationException("Missing button: " + name);
T Complete<T>(Task<T> task) { Finish(task); return task.GetAwaiter().GetResult(); }
void Click(string name, bool pump = true)
{
    var button = FindButton(name);
    Expect(button.IsEffectivelyEnabled, "Button should be enabled: " + name);
    Expect(button.Command is not null, "Missing bound command: " + name);
    button.Command!.Execute(button.CommandParameter); if (pump) Pump();
}

Expect(workspace.IsDisconnected && workspace.IsOverview, "Initial disconnected overview.");
Expect(!FindButton("ScanButton").IsEffectivelyEnabled, "Cannot scan while disconnected.");
Expect(!workspace.RequestClearCommand.CanExecute(null), "Cannot clear while disconnected.");
Expect(workspace.RpmText == "—" && workspace.ModuleCount == 0, "No invented initial readings.");
Expect(!FindButton("ReadReadinessButton").IsEffectivelyEnabled && !workspace.HasReadiness, "Cannot read emissions while disconnected.");
Pass("Disconnected state: scan/clear/live unavailable, no displayed vehicle measurements.");

Click("ConnectButton", false);
Expect(workspace.IsBusy, "Connecting should be busy.");
Expect(!workspace.ScanCommand.CanExecute(null), "Commands serialize during connecting.");
Finish(workspace.ConnectCommand.ExecutionTask);
Expect(workspace.IsConnected && workspace.Status.Contains("Simulator"), "Connected simulation state.");
Click("ScanButton"); Finish(workspace.ScanCommand.ExecutionTask);
Expect(workspace.IsDiagnostics && workspace.ModuleCount == 3 && workspace.FaultCount == 2, "Scan module and DTC results.");
Expect(workspace.Faults.Select(f => f.Code).SequenceEqual(new[] { "P0130", "P0300" }), "OBD DTC examples.");
Expect(FindButton("ExportButton").IsEffectivelyEnabled, "Can export a completed scan.");
Pass("Connect and scan: real XAML commands, operation state, three simulated modules and two DTCs.");

Click("ReadReadinessButton"); Finish(workspace.ReadReadinessCommand.ExecutionTask);
Expect(workspace.HasReadiness && workspace.EmissionDtcText == "2" && workspace.MilText.Contains("Aprins") && workspace.ReadinessMessage.Contains("SIMULARE"), "Demo emissions are explicitly marked and consistent with the DTC fixture.");
Expect(window.FindControl<TextBlock>("MilValue")!.Text == workspace.MilText && workspace.EmissionMonitors.Count == 11, "Emission bindings reach the actual rendered XAML.");
Pass("Readiness UI: disconnected protection, bound MIL/count/monitors and explicit simulator identification.");

Click("ClearButton"); Expect(workspace.ConfirmationVisible, "Clear requires confirmation.");
Expect(window.FindControl<Border>("ClearConfirmation")!.IsVisible, "Confirmation is displayed.");
Click("CancelClearButton"); Expect(!workspace.ConfirmationVisible && workspace.FaultCount == 2, "Cancel preserves DTCs.");
Click("ClearButton"); Click("ConfirmClearButton"); Finish(workspace.ConfirmClearCommand.ExecutionTask);
Expect(!workspace.ConfirmationVisible && workspace.FaultCount == 0 && workspace.HasNoFaults, "Confirmed clear changes simulator only.");
Expect(!workspace.HasReadiness, "Clearing demo faults invalidates the previous readiness reading.");
Click("RescanButton"); Finish(workspace.ScanCommand.ExecutionTask);
Expect(workspace.FaultCount == 0, "A rescan must not recreate cleared DTCs.");
Expect(!FindButton("ClearButton").IsEffectivelyEnabled, "Clear disabled without DTCs.");
Pass("Clear DTC: confirmation, cancellation, confirmed removal, rescan persistence and empty-state handling.");

Click("ExportButton"); Finish(workspace.ExportCommand.ExecutionTask);
Expect(export.Contains("RAPORT DE SIMULARE - FARA VEHICUL REAL") && export.Contains("Injecție / motor") && export.Contains("Fara erori"), "CSV report content and simulation label.");
Expect(DiagnosticReport.ToCsv([new("x", "=1+1", [new("P0001", "text, \"quoted\"")])], DateTimeOffset.Now).Contains("\"'=1+1\""), "CSV formula text is escaped.");
Expect(DiagnosticReport.ToCsv([new("x", "test", [new("P0001", "text, \"quoted\"")])], DateTimeOffset.Now).Contains("\"text, \"\"quoted\"\"\""), "CSV quotations preserved.");
Pass("CSV export: module results, unmistakable simulation heading, quotation and spreadsheet formula escaping.");

Click("LiveNav"); Click("LiveToggleButton");
var sampleDeadline = DateTime.UtcNow.AddSeconds(8);
while (workspace.RpmHistory.Count < 60 && DateTime.UtcNow < sampleDeadline) { Finish(workspace.RefreshLiveAsync()); Pump(); Thread.Sleep(2); }
Expect(workspace.IsLivePage && workspace.IsLive && workspace.RpmHistory.Count == 60, $"Live sampling: active={workspace.IsLive}, page={workspace.CurrentPage}, samples={workspace.RpmHistory.Count}, status={workspace.Status}");
Expect(workspace.RpmText != "—" && workspace.RpmHistory.All(v => v >= 800 && v <= 2300), "Plausible simulation RPM.");
Expect(window.FindControl<TextBlock>("RpmValue")!.Text == workspace.RpmText, "Live label binding updated.");
Click("LiveToggleButton"); var last = workspace.RpmText; Finish(workspace.RefreshLiveAsync());
Expect(workspace.RpmText == last, "Paused readings stay stable.");
Pass("Live data: numeric bindings, chart updates, 60-sample limit and pause without fabricated updates.");

foreach (var (button, page) in new[] { ("ServiceNav", "service"), ("ProgrammingNav", "programming"), ("HistoryNav", "history"), ("SettingsNav", "settings"), ("OverviewNav", "overview") })
{
    Click(button); Expect(workspace.CurrentPage == page, "Navigation route: " + page);
}
Expect(workspace.History.Any(h => h.Action == "Ștergere DTC · demo"), "History includes clear action.");
Expect(workspace.History.Any(h => h.Action == "Export CSV"), "History includes export action.");
Pass("All navigation destinations and session history work; service/programming are labeled future modules.");

// Capture the rendered window at desktop and smaller supported sizes.
var output = Environment.GetEnvironmentVariable("CCR_TEST_ARTIFACTS");
if (!string.IsNullOrWhiteSpace(output))
{
    Directory.CreateDirectory(output);
    foreach (var (page, width, height, file) in new[] { ("overview", 1280d, 820d, "ccr-overview.png"), ("live", 1280d, 820d, "ccr-live.png"), ("diagnostics", 1040d, 720d, "ccr-diagnostics-small.png") })
    {
        workspace.CurrentPage = page; window.Width = width; window.Height = height;
        Pump();
        AvaloniaHeadlessPlatform.ForceRenderTimerTick();
        using var image = window.CaptureRenderedFrame();
        Expect(image is not null, "Rendered frame available."); image!.Save(Path.Combine(output, file), PngBitmapEncoderOptions.Default);
    }
    Pass("Rendered desktop/live/small-window screenshots generated from the actual Avalonia UI.");
}

workspace.CurrentPage = "overview"; Pump(); Click("DisconnectButton"); Finish(workspace.DisconnectCommand.ExecutionTask);
Expect(workspace.IsDisconnected && workspace.Modules.Count == 0 && workspace.RpmHistory.Count == 0 && workspace.RpmText == "—", "Disconnect clears stale measurements.");
Click("ConnectButton"); Finish(workspace.ConnectCommand.ExecutionTask); Click("ScanButton"); Finish(workspace.ScanCommand.ExecutionTask);
Expect(workspace.FaultCount == 2, "New demo session deliberately starts with example faults.");
Pass("Disconnect clears stale state; a new simulator session consistently starts with its documented fixture.");

var cancelled = new SimulatedDiagnosticAdapter(TimeSpan.FromMilliseconds(20));
using (var cts = new CancellationTokenSource())
{
    cts.Cancel(); var task = cancelled.ConnectAsync(cts.Token);
    try { Finish(task); throw new InvalidOperationException("Cancellation was ignored."); } catch (OperationCanceledException) { }
    Expect(!cancelled.IsConnected, "Cancelled connect must never report connected.");
}
try { Finish(cancelled.ScanAsync(CancellationToken.None)); throw new InvalidOperationException("Disconnected scan succeeded."); } catch (InvalidOperationException e) when (e.Message.Contains("Conectează")) { }
Finish(cancelled.DisposeAsync().AsTask());
Pass("Adapter cancellation and disconnected calls fail without creating a fake connection.");

window.Close(); Finish(window.ShutdownTask);
Expect(!workspace.IsConnected && !workspace.IsLive, "Closing releases the simulator and live session.");

var noRpm = false;
var breakConnection = false;
var silentReset = false;
var noReadiness = false;
FakeReply WifiReply(string command)
{
    if (silentReset && command == "ATZ") return new("", Prompt: false);
    if (breakConnection && command == "03") return new("", Prompt: false, Close: true);
    return new(command switch
    {
        "ATZ"=>"ELM327 v1.5\r", "ATE0" or "ATL0" or "ATS0" or "ATH1" or "ATSP0" or "ATD0"=>"OK\r", "ATDPN"=>"A6\r",
        "0100"=>"7E806410088180000\r", "0101"=>noReadiness ? "NO DATA\r" : "7E8064101000FEB40\r", "0902"=>"NO DATA\r", "03"=>"7E80443010130\r", "07" or "0A"=>"NO DATA\r",
        "010C"=>noRpm ? "NO DATA\r" : "7E804410C1AF8\r", "010D"=>"7E803410D2A\r", "0105"=>"7E803410582\r", "ATRV"=>"12.6V\r", _=>"?\r"
    }, FragmentSize: 3);
}
var wifiServer = new FakeElmServer(WifiReply);
try
{
    window = new MainWindow(new SimulatedDiagnosticAdapter(), value => { export = value; return Task.FromResult(true); }, settings => settings.UseWifi ? new ElmWifiDiagnosticAdapter(settings.Host, settings.Port, TimeSpan.FromSeconds(2)) : new SimulatedDiagnosticAdapter());
    workspace = window.Workspace; window.Show(); workspace.CurrentPage = "settings"; Pump();
    window.FindControl<ComboBox>("ConnectionModeSelector")!.SelectedIndex = 1; Pump();
    Expect(workspace.UseWifi && !workspace.IsSimulation, "Selecting Wi-Fi changes the actual connection mode.");
    window.FindControl<TextBox>("WifiHostInput")!.Text = "127.0.0.1";
    window.FindControl<TextBox>("WifiPortInput")!.Text = "0"; Pump();
    Expect(!FindButton("SettingsConnectButton").IsEffectivelyEnabled, "Invalid endpoint cannot connect.");
    window.FindControl<TextBox>("WifiPortInput")!.Text = wifiServer.Port.ToString(); Pump();
    Click("SettingsConnectButton"); Finish(workspace.ConnectCommand.ExecutionTask);
    Expect(workspace.IsConnected && !workspace.IsSimulation && workspace.ProtocolText.Contains("CAN") && workspace.BadgeText.Contains("WI-FI"), "Real adapter selected through actual UI controls.");
    Expect(!window.FindControl<TextBox>("WifiHostInput")!.IsEffectivelyEnabled, "Endpoint immutable while connected.");
    workspace.SelectedConnectionMode = 0; Expect(workspace.UseWifi, "Cannot silently switch to simulator while connected.");
    Click("ScanButton"); Finish(workspace.ScanCommand.ExecutionTask);
    Expect(workspace.FaultCount == 1 && workspace.ModuleCount == 1 && workspace.HasModuleNote, "Real OBD result and partial-service notes.");
    Expect(!FindButton("ClearButton").IsVisible && !workspace.RequestClearCommand.CanExecute(null), "Physical erase unavailable in read-only stage.");
    Click("ExportButton"); Finish(workspace.ExportCommand.ExecutionTask);
    Expect(export.Contains("RAPORT OBD-II") && !export.Contains("RAPORT DE SIMULARE"), "Real export not mislabeled as demo.");
    Pass("Wi-Fi UI: validated IP/port, real TCP driver, immutable active settings, OBD scope/notes and erase disabled.");

    Click("ReadReadinessButton"); Finish(workspace.ReadReadinessCommand.ExecutionTask);
    Expect(workspace.HasReadiness && workspace.IgnitionText.Contains("diesel") && workspace.ReadinessMessage.Contains("VEHICUL") && workspace.EmissionMonitors.Single(m => m.Name == "Filtru de particule").Status == "Nefinalizat", "Real diesel monitor status is not labeled as a diagnosed fault.");
    if (!string.IsNullOrWhiteSpace(output))
    {
        workspace.CurrentPage = "diagnostics"; window.Width = 1280; window.Height = 900; Pump(); AvaloniaHeadlessPlatform.ForceRenderTimerTick();
        using var image = window.CaptureRenderedFrame(); image!.Save(Path.Combine(output, "ccr-readiness.png"), PngBitmapEncoderOptions.Default);
    }
    noReadiness = true; Click("ReadReadinessButton"); Finish(workspace.ReadReadinessCommand.ExecutionTask);
    Expect(!workspace.HasReadiness && workspace.MilText == "—" && workspace.ReadinessMessage.Contains("indisponibilă") && workspace.IsConnected, "Missing readiness removes stale values without inventing a healthy state or disconnecting.");
    Pass("Readiness UI: real diesel results, rendered screen, explicit unavailable state and no stale MIL after a missing response.");

    Click("LiveNav"); Click("LiveToggleButton");
    var liveDeadline = DateTime.UtcNow.AddSeconds(5);
    while (workspace.RpmText == "—" && DateTime.UtcNow < liveDeadline) { Finish(workspace.RefreshLiveAsync()); Pump(); Thread.Sleep(2); }
    Expect(workspace.RpmText == "1726" && workspace.SpeedText == "42" && workspace.CoolantText == "90", "Real PID readings reach screen.");
    noRpm = true;
    liveDeadline = DateTime.UtcNow.AddSeconds(5);
    while (workspace.RpmText != "—" && DateTime.UtcNow < liveDeadline) { Finish(workspace.RefreshLiveAsync()); Pump(); Thread.Sleep(2); }
    Expect(workspace.RpmText == "—", "Missing RPM must clear the displayed previous value.");
    breakConnection = true;
    workspace.CurrentPage = "diagnostics"; Pump(); Click("RescanButton"); Finish(workspace.ScanCommand.ExecutionTask);
    Expect(!workspace.IsConnected && !workspace.IsLive && workspace.Modules.Count == 0 && workspace.RpmText == "—", "Link loss clears stale live/session state.");
    Expect(workspace.UseWifi && workspace.BadgeText.Contains("WI-FI") && workspace.Status.Contains("nu a reușit"), "A failed real link never falls back to simulated data.");
    Pass("Live UI: measured values, absent PID shown as —, dropped TCP clears session and never switches to demo.");

    breakConnection = false; silentReset = true;
    workspace.CurrentPage = "settings"; Pump(); Click("SettingsConnectButton");
    Expect(workspace.IsBusy, "Wi-Fi connect is in progress.");
    workspace.CancelOperationCommand.Execute(null); Finish(workspace.ConnectCommand.ExecutionTask);
    Expect(!workspace.IsBusy && !workspace.IsConnected && workspace.Status.Contains("anulată"), "Cancel interrupts connection without claiming success.");
    if (!string.IsNullOrWhiteSpace(output))
    {
        workspace.WifiHost = "192.168.0.10"; workspace.WifiPort = "35000"; Pump(); AvaloniaHeadlessPlatform.ForceRenderTimerTick();
        using var image = window.CaptureRenderedFrame(); image!.Save(Path.Combine(output, "ccr-wifi-settings.png"), PngBitmapEncoderOptions.Default);
    }
    Pass("Wi-Fi connect can be cancelled; edit controls become available again and no connection is fabricated.");
    window.Close(); Finish(window.ShutdownTask);
}
finally { Finish(wifiServer.DisposeAsync().AsTask()); }
var historyDirectory = Path.Combine(Path.GetTempPath(), "ccr-ui-history-" + Guid.NewGuid().ToString("N"));
var historyPath = Path.Combine(historyDirectory, "history.sqlite3");
try
{
    var store = new SqliteDiagnosticSessionStore(historyPath);
    window = new MainWindow(new SimulatedDiagnosticAdapter(TimeSpan.FromMilliseconds(30)), value => { export = value; return Task.FromResult(true); }, sessionStore: store);
    workspace = window.Workspace; window.Show(); Finish(workspace.InitializeArchiveAsync());
    Click("ConnectButton"); Finish(workspace.ConnectCommand.ExecutionTask); Click("ScanButton"); Finish(workspace.ScanCommand.ExecutionTask);
    Expect(workspace.SavedSessions.Count == 1 && !workspace.HasArchiveError, "Connect and scan update the same saved session.");
    var firstId = workspace.SavedSessions[0].Id;
    Click("ReadReadinessButton"); Finish(workspace.ReadReadinessCommand.ExecutionTask);
    Click("LiveNav"); Click("LiveToggleButton");
    var captureDeadline = DateTime.UtcNow.AddSeconds(5);
    while (workspace.RpmHistory.Count < 12 && DateTime.UtcNow < captureDeadline) { Finish(workspace.RefreshLiveAsync()); Pump(); Thread.Sleep(2); }
    Expect(workspace.RpmHistory.Count >= 12, "Capture live samples for persistence.");
    window.Close(); Finish(window.ShutdownTask);
    var saved = Complete(store.LoadAsync(firstId));
    Expect(saved is not null && saved.Reason == "Închidere aplicație" && saved.Samples.Count >= 12 && saved.Events.Any(e => e.Action == "Închidere sesiune"), "Normal window close waits for final persistence.");
    Expect(saved!.Modules.Sum(m => m.Faults.Count) == 2, "Stored DTC survive disconnect/close.");
    Expect(saved.Readiness is { IsSimulated: true, MilOn: true, DtcCount: 2 }, "Readiness is included in the final stored snapshot.");

    window = new MainWindow(new SimulatedDiagnosticAdapter(), value => { export = value; return Task.FromResult(true); }, sessionStore: new SqliteDiagnosticSessionStore(historyPath));
    workspace = window.Workspace; window.Show(); Finish(workspace.InitializeArchiveAsync()); Click("HistoryNav");
    Expect(!workspace.IsConnected && workspace.Modules.Count == 0 && workspace.RpmText == "—", "Reopening history must not fabricate an active connection.");
    window.FindControl<ListBox>("SavedSessionsList")!.SelectedItem = workspace.SavedSessions.Single(); Pump();
    Click("OpenSavedSessionButton"); Finish(workspace.OpenSavedSessionCommand.ExecutionTask);
    Expect(workspace.HasSavedDetail && workspace.SavedModules.Sum(m => m.Faults.Count) == 2 && workspace.SavedDetailMeasurements.Contains("rpm"), "Offline stored details and measurements are shown.");
    Expect(workspace.SavedReadinessSummary.Contains("MIL:") && !workspace.HasReadiness, "Saved emissions reopen offline without replacing the current readiness state.");
    Click("ExportSavedSessionButton"); Finish(workspace.ExportSavedSessionCommand.ExecutionTask);
    Expect(export.Contains("RAPORT DE SIMULARE") && export.Contains(saved.SavedAt.ToString("O", System.Globalization.CultureInfo.InvariantCulture)), "Archived export uses the saved date and mode.");
    Expect(export.Contains("Martor motor (MIL)") && export.Contains("Sistem evaporativ"), "Offline CSV includes the saved emission reading.");
    Pass("History UI: automatic persistence, normal close flush, restart, offline viewing and dated CSV export.");

    var realId = Guid.NewGuid().ToString("N"); var stamp = DateTimeOffset.Now.AddDays(-1);
    var real = new SavedDiagnosticSession(realId, 1, stamp, stamp, false, "VF100000000000001", "ELM test", "KWP test", "Citire DTC", [new("7A", "ECU OBD-II · 7A", [new("P0420", "Descriere test", "Memorat")], false)], [], []);
    Finish(store.SaveAsync(real));
    workspace.CurrentPage = "overview"; Pump(); Click("ConnectButton"); Finish(workspace.ConnectCommand.ExecutionTask); Click("ScanButton"); Finish(workspace.ScanCommand.ExecutionTask);
    var activeCodes = workspace.Faults.Select(f => f.Code).ToArray(); Click("HistoryNav");
    window.FindControl<ComboBox>("ArchiveFilterSelector")!.SelectedIndex = 1; window.FindControl<TextBox>("ArchiveSearchInput")!.Text = "000001"; Pump();
    Click("RefreshArchiveButton"); Finish(workspace.RefreshArchiveCommand.ExecutionTask);
    Expect(workspace.SavedSessions.Count == 1 && workspace.SavedSessions[0].Id == realId, "Actual search/filter bindings select real archived vehicle.");
    window.FindControl<ListBox>("SavedSessionsList")!.SelectedItem = workspace.SavedSessions.Single(); Pump(); Click("OpenSavedSessionButton"); Finish(workspace.OpenSavedSessionCommand.ExecutionTask);
    Expect(workspace.IsConnected && workspace.IsSimulation && workspace.Faults.Select(f => f.Code).SequenceEqual(activeCodes) && workspace.SavedModules[0].Faults[0].Code == "P0420", "Archive remains separate from active diagnostic state.");
    Click("ExportSavedSessionButton"); Finish(workspace.ExportSavedSessionCommand.ExecutionTask);
    Expect(!workspace.ReportIsSimulation && export.Contains("RAPORT OBD-II") && !export.Contains("RAPORT DE SIMULARE"), "Saved real report must not use the active simulator mode for export.");
    if (!string.IsNullOrWhiteSpace(output))
    {
        window.Width = 1280; window.Height = 900; Pump(); AvaloniaHeadlessPlatform.ForceRenderTimerTick();
        using var image = window.CaptureRenderedFrame(); image!.Save(Path.Combine(output, "ccr-history.png"), PngBitmapEncoderOptions.Default);
    }
    Pass("History UI: VIN/mode filtering, archived real report export during an active simulator session, no mutation of live diagnostics.");

    window.FindControl<ComboBox>("ArchiveFilterSelector")!.SelectedIndex = 0; window.FindControl<TextBox>("ArchiveSearchInput")!.Text = ""; Pump(); Click("RefreshArchiveButton"); Finish(workspace.RefreshArchiveCommand.ExecutionTask);
    var active = workspace.SavedSessions.Single(s => s.Id != firstId && s.Id != realId);
    window.FindControl<ListBox>("SavedSessionsList")!.SelectedItem = active; Pump();
    Expect(!FindButton("DeleteSavedSessionButton").IsEffectivelyEnabled, "Cannot delete the currently connected session.");
    window.FindControl<ListBox>("SavedSessionsList")!.SelectedItem = workspace.SavedSessions.Single(s => s.Id == firstId); Pump();
    Click("DeleteSavedSessionButton"); Expect(workspace.DeleteSavedConfirmation, "Archived deletion requires confirmation.");
    Click("CancelDeleteSavedButton"); Expect(!workspace.DeleteSavedConfirmation && Complete(store.LoadAsync(firstId)) is not null, "Cancel retains stored session.");
    Click("DeleteSavedSessionButton"); Click("ConfirmDeleteSavedButton"); Finish(workspace.ConfirmDeleteSavedCommand.ExecutionTask);
    Expect(!workspace.DeleteSavedConfirmation && Complete(store.LoadAsync(firstId)) is null && workspace.IsConnected, "Confirmed archive deletion leaves active adapter connected.");
    Pass("History UI: active-session delete protection, cancel/confirm semantics and scoped stored-session deletion.");
    window.Close(); Finish(window.ShutdownTask);

    var invalidDatabase = Path.Combine(historyDirectory, "directory-not-database"); Directory.CreateDirectory(invalidDatabase);
    window = new MainWindow(new SimulatedDiagnosticAdapter(), _ => Task.FromResult(true), sessionStore: new SqliteDiagnosticSessionStore(invalidDatabase));
    workspace = window.Workspace; window.Show(); Finish(workspace.InitializeArchiveAsync());
    Expect(workspace.HasArchiveError, "Storage error must be visible.");
    Click("ConnectButton"); Finish(workspace.ConnectCommand.ExecutionTask); Click("ScanButton"); Finish(workspace.ScanCommand.ExecutionTask);
    Expect(workspace.IsConnected && workspace.ModuleCount == 3 && workspace.HasArchiveError && !workspace.PersistenceStatus.StartsWith("Salvat local"), "Failed storage must not block or misreport diagnosis.");
    window.Close(); Finish(window.ShutdownTask);
    Pass("History failure handling: unusable database is reported without blocking diagnosis or claiming a successful local save.");
}
finally { if (Directory.Exists(historyDirectory)) Directory.Delete(historyDirectory, true); }

Console.WriteLine($"SUCCESS: {checks.Count} integration groups passed.");
if (!string.IsNullOrWhiteSpace(output)) File.WriteAllText(Path.Combine(output, "test-results.txt"), string.Join(Environment.NewLine, checks.Select(x => "PASS " + x)) + Environment.NewLine);
