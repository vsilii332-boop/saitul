using System.Collections.ObjectModel;
using CCR.Core;
using CCR.Core.History;

namespace CCR.Desktop.ViewModels;

public sealed record ArchivedSessionItem(DiagnosticSessionSummary Data)
{
    public string Id => Data.Id;
    public string DateLabel => Data.SavedAt.ToLocalTime().ToString("dd.MM.yyyy HH:mm:ss");
    public string ModeLabel => Data.IsSimulated ? "SIMULARE" : "VEHICUL";
    public string VehicleLabel => Data.Vin ?? (Data.IsSimulated ? "Profil demonstrativ" : "VIN indisponibil");
    public string CountsLabel => Data.ModuleCount == 0 ? "Fără citire DTC" : $"{Data.ModuleCount} module · {Data.FaultCount} coduri";
}

public sealed partial class WorkspaceViewModel
{
    private IDiagnosticSessionStore? _sessionStore;
    private readonly List<Task> _pendingWrites = [];
    private readonly List<SavedLiveSample> _sessionSamples = [];
    private string? _sessionId, _sessionVin;
    private long _sessionRevision;
    private DateTimeOffset _sessionStarted;
    private bool _sessionSimulation, _archiveBusy, _deleteArchiveConfirmation;
    private string _sessionAdapter = "", _sessionProtocol = "", _archiveSearch = "", _archiveError = "";
    private string _persistenceStatus = "Istoric local pregătit.", _archiveListStatus = "", _deleteArchiveId = "";
    private int _archiveFilter, _sampleCheckpoint, _archiveReadGeneration;
    private ArchivedSessionItem? _selectedSavedSession;
    private SavedDiagnosticSession? _loadedSavedSession;

    public ObservableCollection<ArchivedSessionItem> SavedSessions { get; } = [];
    public ObservableCollection<DiagnosticModule> SavedModules { get; } = [];
    public ObservableCollection<SavedSessionEvent> SavedEvents { get; } = [];
    public IReadOnlyList<string> ArchiveFilters { get; } = ["Toate", "Vehicule reale", "Simulări"];
    public AsyncCommand RefreshArchiveCommand { get; private set; } = null!;
    public AsyncCommand OpenSavedSessionCommand { get; private set; } = null!;
    public AsyncCommand ExportSavedSessionCommand { get; private set; } = null!;
    public RelayCommand RequestDeleteSavedCommand { get; private set; } = null!;
    public RelayCommand CancelDeleteSavedCommand { get; private set; } = null!;
    public AsyncCommand ConfirmDeleteSavedCommand { get; private set; } = null!;
    public string ArchiveSearch { get => _archiveSearch; set => Set(ref _archiveSearch, value); }
    public int ArchiveFilter { get => _archiveFilter; set { if (value is >= 0 and <= 2) Set(ref _archiveFilter, value); } }
    public bool IsArchiveBusy => _archiveBusy;
    public bool HasArchiveError => ArchiveError.Length > 0;
    public string ArchiveError { get => _archiveError; private set { if (Set(ref _archiveError, value)) Notify(nameof(HasArchiveError)); } }
    public string PersistenceStatus { get => _persistenceStatus; private set => Set(ref _persistenceStatus, value); }
    public string ArchiveListStatus { get => _archiveListStatus; private set => Set(ref _archiveListStatus, value); }
    public string ArchivePath => _sessionStore?.StoragePath ?? "Istoricul local nu este configurat în această instanță.";
    public bool ReportIsSimulation { get; private set; } = true;
    public bool HasSavedDetail => _loadedSavedSession is not null;
    public bool HasNoSavedDetail => !HasSavedDetail;
    public string SavedDetailTitle => _loadedSavedSession is null ? "Alege o sesiune și apasă Deschide" : (_loadedSavedSession.IsSimulated ? "Raport salvat · SIMULARE" : "Raport salvat · VEHICUL");
    public string SavedDetailDate => _loadedSavedSession?.SavedAt.ToLocalTime().ToString("dd.MM.yyyy HH:mm:ss") ?? "";
    public string SavedDetailVin => _loadedSavedSession is null ? "" : "VIN: " + (_loadedSavedSession.Vin ?? (_loadedSavedSession.IsSimulated ? "simulare" : "indisponibil"));
    public string SavedDetailAdapter => _loadedSavedSession is null ? "" : _loadedSavedSession.Adapter + " · " + _loadedSavedSession.Protocol;
    public string SavedDetailSummary => _loadedSavedSession is null ? "" : _loadedSavedSession.Modules.Count == 0 ? $"Sesiune fără citire DTC · {_loadedSavedSession.Samples.Count} eșantioane live păstrate" : $"{_loadedSavedSession.Modules.Count} module · {_loadedSavedSession.Modules.Sum(m => m.Faults.Count)} coduri · {_loadedSavedSession.Samples.Count} eșantioane live păstrate";
    public string SavedDetailReason => _loadedSavedSession?.Reason ?? "";
    public string SavedDetailMeasurements
    {
        get
        {
            var last = _loadedSavedSession?.Samples.LastOrDefault();
            if (last is null) return "Sesiunea nu conține valori live salvate.";
            var x = last.Values;
            return $"Ultimul eșantion, {last.Time.ToLocalTime():HH:mm:ss}: {x.Rpm?.ToString() ?? "—"} rpm · {x.SpeedKph?.ToString() ?? "—"} km/h · {x.CoolantCelsius?.ToString() ?? "—"} °C · {x.Voltage?.ToString("F2") ?? "—"} V ({x.VoltageSource})";
        }
    }
    public ArchivedSessionItem? SelectedSavedSession
    {
        get => _selectedSavedSession;
        set { var previousId = _selectedSavedSession?.Id; if (Set(ref _selectedSavedSession, value)) { if (previousId != value?.Id) ClearSavedDetail(); RefreshArchiveCommands(); } }
    }
    public bool DeleteSavedConfirmation
    {
        get => _deleteArchiveConfirmation;
        private set { if (Set(ref _deleteArchiveConfirmation, value)) RefreshArchiveCommands(); }
    }

    private void InitializeArchive(IDiagnosticSessionStore? store)
    {
        _sessionStore = store;
        RefreshArchiveCommand = new(ReloadArchiveAsync, () => !_disposed && _sessionStore is not null && !IsArchiveBusy, ArchiveFailure);
        OpenSavedSessionCommand = new(OpenSavedSessionAsync, () => !_disposed && _sessionStore is not null && SelectedSavedSession is not null && !IsArchiveBusy, ArchiveFailure);
        ExportSavedSessionCommand = new(ExportSavedSessionAsync, () => !_disposed && (_loadedSavedSession?.Modules.Count > 0 || _loadedSavedSession?.Readiness is not null) && !IsArchiveBusy, ArchiveFailure);
        RequestDeleteSavedCommand = new(_ => { _deleteArchiveId = SelectedSavedSession!.Id; DeleteSavedConfirmation = true; }, () => !_disposed && _sessionStore is not null && SelectedSavedSession is not null && SelectedSavedSession.Id != _sessionId && !IsArchiveBusy && !ConfirmationVisible);
        CancelDeleteSavedCommand = new(_ => DeleteSavedConfirmation = false, () => !IsArchiveBusy);
        ConfirmDeleteSavedCommand = new(DeleteSavedSessionAsync, () => !_disposed && DeleteSavedConfirmation && _deleteArchiveId != _sessionId && !IsArchiveBusy, ArchiveFailure);
    }

    public async Task InitializeArchiveAsync() { try { await ReloadArchiveAsync(); } catch (Exception error) { ArchiveFailure(error); } }
    private async Task ReloadArchiveAsync()
    {
        if (_sessionStore is null || _disposed) return;
        var generation = ++_archiveReadGeneration;
        SetArchiveBusy(true);
        try
        {
            var rows = await _sessionStore.ListAsync(ArchiveSearch, ArchiveFilter == 0 ? null : ArchiveFilter == 2);
            if (_disposed || generation != _archiveReadGeneration) return;
            var selectedId = SelectedSavedSession?.Id;
            SavedSessions.Clear(); foreach (var row in rows) SavedSessions.Add(new(row));
            SelectedSavedSession = SavedSessions.FirstOrDefault(s => s.Id == selectedId);
            ArchiveListStatus = $"{rows.Count} rezultate · cel mult 100 de sesiuni recente pentru filtrul ales.";
        }
        finally { if (generation == _archiveReadGeneration) SetArchiveBusy(false); }
    }

    private void StartSavedSession()
    {
        _sessionId = Guid.NewGuid().ToString("N"); _sessionRevision = 0; _sessionStarted = DateTimeOffset.Now;
        _sessionSimulation = _adapter.IsSimulated; _sessionVin = _sessionSimulation ? null : _adapter.Vin;
        _sessionAdapter = _adapter.AdapterName; _sessionProtocol = _adapter.ProtocolName;
        _sessionSamples.Clear(); _sampleCheckpoint = 0; RefreshArchiveCommands();
    }
    private SavedDiagnosticSession? CaptureSession(string reason)
    {
        if (_sessionStore is null || _sessionId is null) return null;
        var modules = Modules.Select(m => m with { Faults = m.Faults.ToArray() }).ToArray();
        var events = History.Where(e => e.SessionId == _sessionId).Take(100).Select(e => new SavedSessionEvent(e.Timestamp, e.Action, e.Detail)).ToArray();
        return new(_sessionId, ++_sessionRevision, _sessionStarted, DateTimeOffset.Now, _sessionSimulation, _sessionVin,
            _sessionAdapter, _sessionProtocol, reason, modules, _sessionSamples.ToArray(), events,
            _readiness is null ? null : _readiness with { Monitors = _readiness.Monitors.ToArray() });
    }
    private Task SaveCurrentSessionAsync(string reason) => QueueSessionWrite(CaptureSession(reason));
    private Task QueueSessionWrite(SavedDiagnosticSession? snapshot)
    {
        if (snapshot is null || _sessionStore is null) return Task.CompletedTask;
        _pendingWrites.RemoveAll(t => t.IsCompleted);
        var task = PersistSessionAsync(snapshot); _pendingWrites.Add(task); return task;
    }
    private async Task PersistSessionAsync(SavedDiagnosticSession snapshot)
    {
        try
        {
            await _sessionStore!.SaveAsync(snapshot);
            ArchiveError = ""; PersistenceStatus = "Salvat local la " + snapshot.SavedAt.ToLocalTime().ToString("HH:mm:ss");
            if (!_disposed) await ReloadArchiveAsync();
        }
        catch (Exception error) { ArchiveFailure(error); }
    }
    private async Task SaveLiveSampleAsync(LiveSnapshot sample)
    {
        if (_sessionId is null) return;
        _sessionSamples.Add(new(DateTimeOffset.Now, sample));
        if (_sessionSamples.Count > 60) _sessionSamples.RemoveAt(0);
        if (++_sampleCheckpoint >= 10) { _sampleCheckpoint = 0; await SaveCurrentSessionAsync("Date live"); }
    }

    private async Task OpenSavedSessionAsync()
    {
        var id = SelectedSavedSession!.Id; SetArchiveBusy(true);
        try
        {
            var session = await _sessionStore!.LoadAsync(id);
            if (_disposed || SelectedSavedSession?.Id != id) return;
            if (session is null) { ClearSavedDetail(); ArchiveListStatus = "Sesiunea nu mai există. Apasă Actualizează."; return; }
            _loadedSavedSession = session; SavedModules.Clear(); SavedEvents.Clear();
            foreach (var module in session.Modules) SavedModules.Add(module);
            foreach (var item in session.Events) SavedEvents.Add(item);
            NotifySavedDetail();
        }
        finally { SetArchiveBusy(false); }
    }
    private async Task ExportSavedSessionAsync()
    {
        var session = _loadedSavedSession!; SetArchiveBusy(true);
        try
        {
            ReportIsSimulation = session.IsSimulated;
            var saved = await _saveReport(DiagnosticReport.ToCsv(session.Modules, session.SavedAt, session.Vin, session.Readiness));
            ArchiveListStatus = saved ? "Raportul salvat a fost exportat. Data din CSV este data citirii salvate." : "Export anulat.";
        }
        finally { SetArchiveBusy(false); }
    }
    private async Task DeleteSavedSessionAsync()
    {
        var id = _deleteArchiveId;
        if (id == _sessionId) throw new InvalidOperationException("Deconectează sesiunea curentă înainte de a o șterge din istoric.");
        SetArchiveBusy(true);
        try { await _sessionStore!.DeleteAsync(id); ClearSavedDetail(); DeleteSavedConfirmation = false; await ReloadArchiveAsync(); ArchiveListStatus = "Sesiunea a fost ștearsă din istoricul local."; }
        finally { DeleteSavedConfirmation = false; SetArchiveBusy(false); }
    }
    private void ClearSavedDetail() { _loadedSavedSession = null; SavedModules.Clear(); SavedEvents.Clear(); NotifySavedDetail(); }
    private void NotifySavedDetail()
    {
        foreach (var property in new[] { nameof(HasSavedDetail), nameof(HasNoSavedDetail), nameof(SavedDetailTitle), nameof(SavedDetailDate), nameof(SavedDetailVin), nameof(SavedDetailAdapter), nameof(SavedDetailSummary), nameof(SavedDetailReason), nameof(SavedDetailMeasurements) }) Notify(property);
        Notify(nameof(SavedReadinessSummary)); RefreshArchiveCommands();
    }
    private void SetArchiveBusy(bool value) { if (Set(ref _archiveBusy, value, nameof(IsArchiveBusy))) RefreshArchiveCommands(); }
    private void RefreshArchiveCommands()
    {
        RefreshArchiveCommand?.Refresh(); OpenSavedSessionCommand?.Refresh(); ExportSavedSessionCommand?.Refresh(); RequestDeleteSavedCommand?.Refresh(); CancelDeleteSavedCommand?.Refresh(); ConfirmDeleteSavedCommand?.Refresh();
    }
    private void ArchiveFailure(Exception error) { ArchiveError = "Istoricul local nu a putut fi actualizat: " + error.Message; PersistenceStatus = "Salvarea locală necesită verificare."; }
}
