using CCR.Core;

namespace CCR.Desktop.ViewModels;

public sealed partial class WorkspaceViewModel
{
    private EmissionReadiness? _readiness;
    private string _readinessMessage = "Starea emisiilor nu a fost citită în această sesiune.";
    public AsyncCommand ReadReadinessCommand { get; private set; } = null!;
    public bool HasReadiness => _readiness is not null;
    public string ReadinessMessage => _readinessMessage;
    public string MilText => _readiness?.MilLabel ?? "—";
    public string EmissionDtcText => _readiness?.DtcCount.ToString() ?? "—";
    public string IgnitionText => _readiness?.IgnitionLabel ?? "—";
    public IReadOnlyList<ReadinessMonitor> EmissionMonitors => _readiness?.Monitors ?? [];
    public string ReadinessScope => "Stare de la ultima ștergere a codurilor. Nefinalizat înseamnă că autotestul nu s-a încheiat; nu confirmă un defect. Această citire nu este un verdict ITP.";
    public string SavedReadinessSummary => _loadedSavedSession?.Readiness is { } reading
        ? $"Emisii · {reading.ReadAt.ToLocalTime():dd.MM.yyyy HH:mm:ss} · ECU {reading.Ecu}\n{reading.IgnitionLabel}\n{reading.Summary}\n" + string.Join("\n", reading.Monitors.Select(m => m.Name + ": " + m.Status))
        : "Sesiunea nu conține o citire a stării emisiilor.";

    private async Task ReadReadinessAsync()
    {
        ResetReadiness("Citire în curs. Rezultatul anterior nu este afișat ca actual.");
        EmissionReadiness? result;
        try { result = await _adapter.ReadReadinessAsync(OperationToken); }
        catch { ResetReadiness("Citirea stării emisiilor nu a fost finalizată. Încearcă din nou după verificarea conexiunii."); throw; }
        if (_disposed) return;
        _readiness = result;
        _readinessMessage = result is null ? "Stare indisponibilă: PID 01 nesuportat sau fără răspuns valid de la ECU-ul selectat."
            : $"{(result.IsSimulated ? "SIMULARE" : "VEHICUL")} · ECU {result.Ecu} · citit la {result.ReadAt.ToLocalTime():dd.MM.yyyy HH:mm:ss}";
        NotifyReadiness();
        Status = result is null ? _readinessMessage : "Starea emisiilor a fost citită. " + result.Summary;
        Log("Stare emisii", result?.Summary ?? _readinessMessage);
        await SaveCurrentSessionAsync("Stare emisii");
    }
    private void ResetReadiness(string message = "Starea emisiilor nu a fost citită în această sesiune.")
    {
        _readiness = null; _readinessMessage = message; NotifyReadiness();
    }
    private void NotifyReadiness()
    {
        foreach (var name in new[] { nameof(HasReadiness), nameof(ReadinessMessage), nameof(MilText), nameof(EmissionDtcText), nameof(IgnitionText), nameof(EmissionMonitors) }) Notify(name);
        ExportCommand?.Refresh();
    }
}
