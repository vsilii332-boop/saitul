using System.Text;
using Avalonia.Controls;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using CCR.Core;
using CCR.Core.Elm;
using CCR.Core.History;
using CCR.Desktop.ViewModels;

namespace CCR.Desktop;

public partial class MainWindow : Window
{
    private readonly DispatcherTimer _liveTimer;
    private bool _allowClose;
    public Task ShutdownTask { get; private set; } = Task.CompletedTask;
    public WorkspaceViewModel Workspace { get; }

    public MainWindow() : this(new SimulatedDiagnosticAdapter(), null, settings => settings.UseWifi ? new ElmWifiDiagnosticAdapter(settings.Host, settings.Port) : new SimulatedDiagnosticAdapter(), new SqliteDiagnosticSessionStore(SqliteDiagnosticSessionStore.DefaultPath())) { }

    public MainWindow(IDiagnosticAdapter adapter, Func<string, Task<bool>>? saveReport = null, Func<ConnectionSettings, IDiagnosticAdapter>? adapterFactory = null, IDiagnosticSessionStore? sessionStore = null)
    {
        InitializeComponent();
        Workspace = new(adapter, saveReport ?? SaveReportAsync, adapterFactory, sessionStore);
        DataContext = Workspace;
        _liveTimer = new() { Interval = TimeSpan.FromMilliseconds(750) };
        _liveTimer.Tick += async (_, _) => await Workspace.RefreshLiveAsync();
        Opened += async (_, _) => { _liveTimer.Start(); await Workspace.InitializeArchiveAsync(); };
        Closing += (_, args) =>
        {
            if (_allowClose) return;
            args.Cancel = true;
            if (!ShutdownTask.IsCompleted) return;
            _liveTimer.Stop(); ShutdownTask = SaveAndCloseAsync();
        };
    }

    private async Task<bool> SaveReportAsync(string content)
    {
        var file = await StorageProvider.SaveFilePickerAsync(new()
        {
            Title = Workspace.ReportIsSimulation ? "Exportă raportul de simulare CCR" : "Exportă raportul OBD-II CCR",
            SuggestedFileName = $"CCR-{(Workspace.ReportIsSimulation ? "simulare" : "OBD")}-{DateTime.Now:yyyyMMdd-HHmmss}.csv",
            DefaultExtension = "csv",
            FileTypeChoices = [new("Fișier CSV (separator ;)" ) { Patterns = ["*.csv"] }],
            ShowOverwritePrompt = true
        });
        if (file is null) return false;
        await using var stream = await file.OpenWriteAsync();
        if (stream.CanSeek) stream.SetLength(0);
        using var writer = new StreamWriter(stream, new UTF8Encoding(true));
        await writer.WriteAsync(content);
        return true;
    }

    private async Task SaveAndCloseAsync()
    {
        try { await Workspace.DisposeAsync(); }
        finally { _allowClose = true; Dispatcher.UIThread.Post(Close); }
    }
}
