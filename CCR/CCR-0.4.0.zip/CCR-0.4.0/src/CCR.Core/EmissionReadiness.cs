namespace CCR.Core;

public sealed record ReadinessMonitor(string Name, bool Supported, bool Incomplete)
{
    public string Status => !Supported ? "Nesuportat" : Incomplete ? "Nefinalizat" : "Finalizat";
}

/// <summary>Mode 01 PID 01: monitor status since DTCs were cleared, for one ECU.</summary>
public sealed record EmissionReadiness(string Ecu, DateTimeOffset ReadAt, bool IsSimulated,
    bool MilOn, int DtcCount, bool CompressionIgnition, IReadOnlyList<ReadinessMonitor> Monitors)
{
    public string MilLabel => MilOn ? "Aprins (comandat de ECU)" : "Stins (comandat de ECU)";
    public string IgnitionLabel => CompressionIgnition ? "Aprindere prin compresie (diesel)" : "Aprindere prin scânteie";
    public int IncompleteCount => Monitors.Count(m => m.Supported && m.Incomplete);
    public string Summary => $"MIL: {MilLabel} · {DtcCount} coduri raportate de ECU · {IncompleteCount} monitoare nefinalizate";

    public static EmissionReadiness Decode(ReadOnlySpan<byte> data, string ecu, DateTimeOffset readAt, bool simulated = false)
    {
        if (data.Length != 4) throw new InvalidDataException("Răspuns PID 01 incomplet: sunt necesari 4 octeți.");
        var compression = (data[1] & 8) != 0;
        var monitors = new List<ReadinessMonitor>();
        var continuous = new[] { "Rateuri de aprindere", "Sistem de alimentare", "Componente generale" };
        for (var i = 0; i < continuous.Length; i++) Add(continuous[i], data[1], i, data[1], i + 4);
        // SAE J1979: byte C advertises support; byte D marks incomplete monitors.
        var names = compression
            ? new string?[] { "Catalizator NMHC", "NOx / SCR", null, "Presiune de supraalimentare", null, "Senzor gaze de evacuare", "Filtru de particule", "EGR / VVT" }
            : new string?[] { "Catalizator", "Catalizator încălzit", "Sistem evaporativ", "Aer secundar", "Agent frigorific A/C", "Senzor oxigen", "Încălzire senzor oxigen", "EGR / VVT" };
        for (var i = 0; i < names.Length; i++) if (names[i] is { } name) Add(name, data[2], i, data[3], i);
        return new(ecu, readAt, simulated, (data[0] & 0x80) != 0, data[0] & 0x7F, compression, monitors);

        void Add(string name, byte supportByte, int supportBit, byte incompleteByte, int incompleteBit)
        {
            var supported = (supportByte & (1 << supportBit)) != 0;
            monitors.Add(new(name, supported, supported && (incompleteByte & (1 << incompleteBit)) != 0));
        }
    }
}
