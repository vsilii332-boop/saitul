using System.Globalization;
using System.Text.RegularExpressions;

namespace CCR.Core.Elm;

/// <summary>ELM327 over TCP, limited to standard OBD-II reads. No erase, coding or programming services.</summary>
public sealed class ElmWifiDiagnosticAdapter : IDiagnosticAdapter
{
    private readonly ElmTcpConnection _wire;
    private readonly SemaphoreSlim _operations = new(1);
    private readonly Dictionary<string, HashSet<int>> _pids = [];
    private readonly TimeSpan _requestTimeout;
    private bool _ready, _disposed;
    private int _protocol;
    private string _primaryEcu = "";
    public bool IsConnected => _ready && _wire.IsOpen;
    public bool IsSimulated => false;
    public bool CanClearFaults => false;
    public string AdapterName { get; private set; } = "ELM327 Wi-Fi";
    public string? Vin { get; private set; }
    public string ProtocolName => _protocol switch
    {
        1=>"SAE J1850 PWM", 2=>"SAE J1850 VPW", 3=>"ISO 9141-2", 4=>"ISO 14230-4 KWP · 5 baud", 5=>"ISO 14230-4 KWP · fast init",
        6=>"ISO 15765-4 CAN · 11 bit / 500 kbit", 7=>"ISO 15765-4 CAN · 29 bit / 500 kbit", 8=>"ISO 15765-4 CAN · 11 bit / 250 kbit", 9=>"ISO 15765-4 CAN · 29 bit / 250 kbit", _=>"Nedetectat"
    };
    public IReadOnlyList<CommunicationExchange> RecentTraffic => _wire.RecentTraffic;

    public ElmWifiDiagnosticAdapter(string host, int port, TimeSpan? requestTimeout = null)
    {
        _wire = new(host, port); _requestTimeout = requestTimeout ?? TimeSpan.FromSeconds(6);
    }

    public async Task ConnectAsync(CancellationToken cancellationToken)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        await _operations.WaitAsync(cancellationToken);
        try
        {
            if (IsConnected) return;
            _ready = false; Vin = null; _pids.Clear(); _protocol = 0; _primaryEcu = "";
            await _wire.OpenAsync(cancellationToken);
            var reset = await SendAsync("ATZ", cancellationToken);
            var identity = reset.Replace('\n', '\r').Split('\r', StringSplitOptions.RemoveEmptyEntries).Select(s => s.Trim()).FirstOrDefault(s => s.Contains("ELM", StringComparison.OrdinalIgnoreCase) || s.Contains("OBDLINK", StringComparison.OrdinalIgnoreCase) || s.Contains("STN", StringComparison.OrdinalIgnoreCase));
            if (identity is null) throw new IOException("Adaptorul nu a răspuns ca o interfață ELM327 compatibilă.");
            AdapterName = identity;
            foreach (var command in new[] { "ATE0", "ATL0", "ATS0", "ATH1", "ATSP0" })
            {
                if (!Lines(await SendAsync(command, cancellationToken)).Contains("OK")) throw new IOException("Adaptorul nu acceptă configurarea " + command + ".");
            }
            // ATD0 is optional on older ELM versions. The parser also accepts explicit CAN DLC.
            await SendAsync("ATD0", cancellationToken);
            var initial = await SendAsync("0100", cancellationToken, TimeSpan.FromSeconds(25));
            var initializationError = Lines(initial).FirstOrDefault(line => line == "NO DATA" || line == "?" || line == "STOPPED" || line.Contains("UNABLE TO CONNECT", StringComparison.Ordinal) || line.Contains("ERROR", StringComparison.Ordinal) || line.Contains("BUFFER FULL", StringComparison.Ordinal));
            if (initializationError is not null)
                throw new IOException("Adaptorul Wi-Fi răspunde, dar nu a obținut un răspuns OBD-II valid de la vehicul. Verifică mufa și contactul complet. 0100: " + initializationError);
            var protocol = string.Concat(Lines(await SendAsync("ATDPN", cancellationToken)).Where(s => s != "ATDPN"));
            var reportedProtocol = protocol;
            if (protocol.StartsWith('A')) protocol = protocol[1..];
            if (int.TryParse(protocol, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var protocolNumber) && protocolNumber == 0)
                throw new IOException("Adaptorul nu a identificat încă protocolul vehiculului. Verifică contactul complet. ATDPN: " + reportedProtocol);
            if (protocolNumber is < 1 or > 9) throw new NotSupportedException("Protocolul OBD raportat de adaptor nu este acceptat în această etapă. ATDPN: " + reportedProtocol);
            _protocol = protocolNumber;
            foreach (var message in ObdResponseParser.Parse(initial, "0100", _protocol).Where(m => m.Data.Length > 1 && m.Data[0] == 0x41 && m.Data[1] == 0))
                _pids[message.Ecu] = ObdResponseParser.SupportedPids(message.Data, 0);
            if (_pids.Count == 0) throw new IOException("Adaptorul este accesibil, dar vehiculul nu a răspuns la OBD-II. Verifică mufa, contactul și compatibilitatea mașinii.");
            _primaryEcu = _pids.Keys.Order(StringComparer.Ordinal).First();
            foreach (var start in new[] { 0x20, 0x40 })
            {
                if (!_pids.Values.Any(p => p.Contains(start))) break;
                var command = $"01{start:X2}";
                foreach (var message in await QueryAsync(command, cancellationToken))
                    if (_pids.TryGetValue(message.Ecu, out var supported) && message.Data.Length > 1 && message.Data[0] == 0x41 && message.Data[1] == start)
                        supported.UnionWith(ObdResponseParser.SupportedPids(message.Data, start));
            }
            // VIN is optional on older vehicles. A missing/invalid VIN must not be fabricated.
            try { Vin = ObdResponseParser.Vin(await QueryAsync("0902", cancellationToken), _primaryEcu, ObdResponseParser.IsCan(_protocol)); }
            catch (InvalidDataException) { Vin = null; }
            _ready = true;
        }
        catch { _wire.DropConnection(); _ready = false; throw; }
        finally { _operations.Release(); }
    }

    public Task DisconnectAsync() { _ready = false; _wire.DropConnection(); return Task.CompletedTask; }

    public async Task<IReadOnlyList<DiagnosticModule>> ScanAsync(CancellationToken cancellationToken)
    {
        await _operations.WaitAsync(cancellationToken);
        try
        {
            RequireConnection();
            var replies = new Dictionary<string, IReadOnlyList<ObdMessage>>();
            foreach (var command in new[] { "03", "07", "0A" }) replies[command] = await QueryAsync(command, cancellationToken);
            var ecus = _pids.Keys.Concat(replies.Values.SelectMany(x => x).Select(m => m.Ecu)).Distinct().Order(StringComparer.Ordinal);
            var result = new List<DiagnosticModule>();
            foreach (var ecu in ecus)
            {
                var codes = new Dictionary<string, List<string>>(); var notes = new List<string>(); var storedComplete = false;
                foreach (var (command, sid, label) in new[] { ("03", (byte)0x43, "Memorat"), ("07", (byte)0x47, "În așteptare"), ("0A", (byte)0x4A, "Permanent") })
                {
                    var frames = replies[command].Where(m => m.Ecu == ecu && m.Data.Length > 0 && m.Data[0] == sid).ToArray();
                    if (frames.Length == 0)
                    {
                        var negative = replies[command].FirstOrDefault(m => m.Ecu == ecu && m.Data.Length >= 3 && m.Data[0] == 0x7F);
                        notes.Add(label + (negative is null ? ": fără răspuns." : $": refuz ECU (NRC {negative.Data[2]:X2}).")); continue;
                    }
                    foreach (var frame in frames)
                    {
                        foreach (var code in ObdResponseParser.DtcCodes(frame.Data, ObdResponseParser.IsCan(_protocol)))
                        {
                            if (!codes.TryGetValue(code, out var states)) codes[code] = states = [];
                            if (!states.Contains(label)) states.Add(label);
                        }
                    }
                    if (command == "03") storedComplete = true;
                }
                var faults = codes.OrderBy(x => x.Key, StringComparer.Ordinal).Select(x => new DiagnosticFault(x.Key, ObdResponseParser.Description(x.Key), string.Join(" / ", x.Value))).ToArray();
                result.Add(new(ecu, "ECU OBD-II · " + ecu, faults, false, storedComplete, string.Join(" ", notes)));
            }
            return result;
        }
        finally { _operations.Release(); }
    }

    public Task ClearFaultsAsync(string moduleId, CancellationToken cancellationToken) => throw new NotSupportedException("Conexiunea reală este doar pentru citire în această etapă.");

    public async Task<LiveSnapshot> ReadLiveAsync(CancellationToken cancellationToken)
    {
        await _operations.WaitAsync(cancellationToken);
        try
        {
            RequireConnection();
            var rpm = await PidAsync(0x0C, 2, cancellationToken);
            var speed = await PidAsync(0x0D, 1, cancellationToken);
            var coolant = await PidAsync(0x05, 1, cancellationToken);
            var voltage = await PidAsync(0x42, 2, cancellationToken);
            double? volts = voltage is null ? null : (voltage[0] * 256 + voltage[1]) / 1000d;
            var source = "Tensiune ECU";
            if (!_pids[_primaryEcu].Contains(0x42))
            {
                source = "Tensiune adaptor";
                var reply = string.Concat(Lines(await SendAsync("ATRV", cancellationToken)).Where(s => s != "ATRV"));
                if (Regex.IsMatch(reply, @"^\d{1,2}(?:\.\d{1,2})?V$", RegexOptions.CultureInvariant) && double.TryParse(reply[..^1], NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out var measured) && measured is >= 0 and <= 40) volts = measured;
            }
            return new(rpm is null ? null : (rpm[0] * 256 + rpm[1]) / 4, speed?[0], coolant is null ? null : coolant[0] - 40, volts, source);
        }
        finally { _operations.Release(); }
    }

    private async Task<byte[]?> PidAsync(int pid, int length, CancellationToken cancellationToken)
    {
        if (!_pids[_primaryEcu].Contains(pid)) return null;
        var messages = await QueryAsync($"01{pid:X2}", cancellationToken);
        var matching = messages.Where(m => m.Ecu == _primaryEcu && m.Data.Length >= 2 && m.Data[0] == 0x41 && m.Data[1] == pid).ToArray();
        if (matching.Length == 0) return null;
        if (matching.Length != 1 || matching[0].Data.Length != length + 2) throw new InvalidDataException("Date PID incomplete sau ambigue.");
        return matching[0].Data[2..];
    }
    public async Task<EmissionReadiness?> ReadReadinessAsync(CancellationToken cancellationToken)
    {
        await _operations.WaitAsync(cancellationToken);
        try
        {
            RequireConnection();
            var data = await PidAsync(0x01, 4, cancellationToken);
            return data is null ? null : EmissionReadiness.Decode(data, _primaryEcu, DateTimeOffset.Now);
        }
        finally { _operations.Release(); }
    }
    private async Task<IReadOnlyList<ObdMessage>> QueryAsync(string command, CancellationToken cancellationToken) => ObdResponseParser.Parse(await SendAsync(command, cancellationToken), command, _protocol);
    private Task<string> SendAsync(string command, CancellationToken cancellationToken, TimeSpan? timeout = null) => _wire.ExchangeAsync(command, cancellationToken, timeout ?? _requestTimeout);
    private static IEnumerable<string> Lines(string text) => text.Replace('\n', '\r').Split('\r', StringSplitOptions.RemoveEmptyEntries).Select(s => s.Trim().ToUpperInvariant());
    private void RequireConnection() { ObjectDisposedException.ThrowIf(_disposed, this); if (!IsConnected) throw new InvalidOperationException("Adaptorul nu este conectat la un vehicul OBD-II."); }
    public async ValueTask DisposeAsync() { if (!_disposed) { _disposed = true; _ready = false; await _wire.DisposeAsync(); } }
}
