using System.Text;
using CCR.Core;
using CCR.Core.Elm;
using CCR.Obd.Tests;

var groups = new List<string>();
void Expect(bool value, string why) { if (!value) throw new InvalidOperationException(why); }
void Pass(string name) { groups.Add(name); Console.WriteLine("PASS " + name); }
async Task Fails<T>(Func<Task> action) where T : Exception
{
    try { await action(); } catch (T) { return; }
    throw new InvalidOperationException("Expected " + typeof(T).Name);
}
string Frame(string ecu, params byte[] data) => ecu + data.Length.ToString("X2") + Convert.ToHexString(data) + "\r";
string Legacy(int protocol, params byte[] data)
{
    var header = protocol == 3 ? new byte[] { 0x48, 0x6B, 0x10 } : [(byte)(0x80 | data.Length), 0xF1, 0x10];
    var body = header.Concat(data).ToArray(); return Convert.ToHexString(body) + ((byte)body.Sum(b => b)).ToString("X2") + "\r";
}
const string TestVin = "VF100000000000001";
string VinFrames(string ecu)
{
    var data = new byte[] { 0x49, 2, 1 }.Concat(Encoding.ASCII.GetBytes(TestVin)).ToArray();
    var text = ecu + "1014" + Convert.ToHexString(data[..6]) + "\r";
    for (var index = 6; index < data.Length; index += 7) text += ecu + (0x21 + (index - 6) / 7).ToString("X2") + Convert.ToHexString(data.Skip(index).Take(7).ToArray()) + "\r";
    return text;
}
FakeReply Standard(string command, int protocol = 6, bool extended = false)
{
    var can = ObdResponseParser.IsCan(protocol); var ecu = protocol is 7 or 9 ? "18DAF110" : "7E8";
    string Pack(params byte[] payload) => can ? Frame(ecu, payload) : Legacy(protocol, payload);
    var text = command switch
    {
        "ATZ" => "ATZ\rELM327 v1.5\r",
        "ATE0" or "ATL0" or "ATS0" or "ATH1" or "ATSP0" => "OK\r",
        "ATD0" => "?\r", // Optional command on old clones.
        "ATDPN" => "A" + protocol.ToString("X") + "\r",
        "0100" => "SEARCHING...\r" + Pack(0x41, 0, 0x08, 0x18, 0, (byte)(extended ? 1 : 0)),
        "0120" => Pack(0x41, 0x20, 0, 0, 0, 1),
        "0140" => Pack(0x41, 0x40, 0x40, 0, 0, 0),
        "03" => can ? Pack(0x43, 2, 1, 0x30, 3, 0) : Pack(0x43, 1, 0x30, 3, 0, 0, 0),
        "07" => can ? Pack(0x47, 1, 1, 0x30) : Pack(0x47, 1, 0x30, 0, 0, 0, 0),
        "0A" => can ? Pack(0x4A, 0) : Pack(0x7F, 0x0A, 0x11),
        "010C" => Pack(0x41, 0x0C, 0x1A, 0xF8),
        "010D" => Pack(0x41, 0x0D, 42),
        "0105" => Pack(0x41, 0x05, 130),
        "0142" => Pack(0x41, 0x42, 0x36, 0xB0),
        "ATRV" => "14.2V\r", "0902" => can ? VinFrames(ecu) : "NO DATA\r",
        _ => "?\r"
    };
    return new(text, FragmentSize: 3);
}

try
{
    var messages = ObdResponseParser.Parse("010C\rSEARCHING...\r7E8 04 41 0C 1A F8\r", "010C", 6);
    Expect(messages.Count == 1 && messages[0].Ecu == "7E8" && messages[0].Data.SequenceEqual(new byte[] { 0x41, 0x0C, 0x1A, 0xF8 }), "CAN parsing with echoes and whitespace.");
    Expect(ObdResponseParser.Parse("7E8 8 04 41 0C 1A F8 00 00 00", "010C", 6).Count == 1, "Optional DLC and padding.");
    Expect(ObdResponseParser.Parse("18DAF11004410C1AF8", "010C", 7)[0].Ecu == "18DAF110", "29-bit CAN IDs.");
    Expect(ObdResponseParser.DtcCodes([0x43, 2, 1, 0x30, 3, 0], true).SequenceEqual(new[] { "P0130", "P0300" }), "CAN DTC count.");
    Expect(ObdResponseParser.DtcCodes([0x43, 3, 0, 3, 2, 0, 0], false).SequenceEqual(new[] { "P0300", "P0302" }), "Legacy DTC must not lose the first code.");
    Expect(ObdResponseParser.DtcCode(0xC1, 0x23) == "U0123" && ObdResponseParser.DtcCode(0x52, 0x34) == "C1234", "All DTC families.");
    await Fails<InvalidDataException>(() => Task.FromResult(ObdResponseParser.DtcCodes([0x43, 3, 1, 0x30], true)));
    Pass("CAN 11/29-bit, DLC, echo/status lines and correct CAN-versus-legacy DTC decoding.");

    var vin = ObdResponseParser.Parse(VinFrames("7E8"), "0902", 6);
    Expect(ObdResponseParser.Vin(vin, "7E8", true) == TestVin, "Multi-frame VIN.");
    Expect(ObdResponseParser.Vin(vin, "7E9", true) is null, "Never mix ECUs for VIN.");
    await Fails<InvalidDataException>(() => Task.FromResult(ObdResponseParser.Parse(VinFrames("7E8").Replace("7E822", "7E823"), "0902", 6)));
    await Fails<InvalidDataException>(() => Task.FromResult(ObdResponseParser.Parse("7E81014490201564631\r", "0902", 6)));
    var padded = new byte[] { 0, 0, 0 }.Concat(Encoding.ASCII.GetBytes(TestVin)).ToArray();
    var legacyVin = string.Concat(Enumerable.Range(1, 5).Select(i => Legacy(3, new byte[] { 0x49, 2, (byte)i }.Concat(padded.Skip((i - 1) * 4).Take(4)).ToArray())));
    Expect(ObdResponseParser.Vin(ObdResponseParser.Parse(legacyVin, "0902", 3), "10", false) == TestVin, "Legacy VIN ordered records.");
    var kwp = ObdResponseParser.Parse(Legacy(5, 0x41, 0x0C, 0x1A, 0xF8), "010C", 5);
    Expect(kwp[0].Data[0] == 0x41, "KWP length/checksum.");
    await Fails<InvalidDataException>(() => Task.FromResult(ObdResponseParser.Parse(Legacy(3, 0x41, 0x0D, 42)[..^3] + "FF\r", "010D", 3)));
    Expect(ObdResponseParser.Parse("3132333435363738394B", "", 1).Count == 1, "J1850 CRC reference vector 123456789 -> 4B.");
    Pass("ISO-TP reassembly, missing/wrong frames, legacy VIN, ISO9141/KWP checksum and SAE-J1850 CRC.");

    foreach (var protocol in new[] { 3, 4, 5, 6, 7, 8, 9 })
    {
        await using var server = new FakeElmServer(c => Standard(c, protocol));
        await using var adapter = new ElmWifiDiagnosticAdapter("127.0.0.1", server.Port);
        await adapter.ConnectAsync(CancellationToken.None);
        Expect(adapter.IsConnected && !adapter.IsSimulated && !adapter.CanClearFaults, "Real transport capability flags.");
        var modules = await adapter.ScanAsync(CancellationToken.None);
        Expect(modules.Count == 1 && modules[0].Faults.Count == 2 && !modules[0].IsSimulated && modules[0].IsComplete, "DTC from TCP server.");
        Expect(modules[0].Faults.Single(f => f.Code == "P0130").Status.Contains("În așteptare"), "Stored and pending states merged without losing meaning.");
        var live = await adapter.ReadLiveAsync(CancellationToken.None);
        Expect(live.Rpm == 1726 && live.SpeedKph == 42 && live.CoolantCelsius == 90 && live.Voltage == 14.2 && live.VoltageSource == "Tensiune adaptor", "PID formula and adapter-voltage source.");
        Expect(adapter.Vin == (protocol >= 6 ? TestVin : null), "VIN availability is explicit.");
        var report = DiagnosticReport.ToCsv(modules, DateTimeOffset.Now, adapter.Vin);
        Expect(report.Contains("RAPORT OBD-II") && !report.Contains("RAPORT DE SIMULARE"), "Correct real report labeling.");
        await Fails<NotSupportedException>(() => adapter.ClearFaultsAsync(modules[0].Id, CancellationToken.None));
        Expect(server.Commands.All(c => c is "ATZ" or "ATE0" or "ATL0" or "ATS0" or "ATH1" or "ATSP0" or "ATD0" or "ATDPN" or "0100" or "0902" or "03" or "07" or "0A" or "010C" or "010D" or "0105" or "ATRV"), "No erase/programming commands sent.");
        await adapter.DisconnectAsync(); Expect(!adapter.IsConnected, "Disconnect state.");
    }
    Pass("Full real TCP handshake/DTC/live/report path across seven CAN and K-Line protocol variants; no writes to vehicle.");

    foreach (var failure in new[] { "SEARCHING...\rUNABLE TO CONNECT\r", "NO DATA\r", "BUS INIT: ERROR\r" })
    {
        await using var server = new FakeElmServer(c => c == "0100" ? new(failure) : c == "ATDPN" ? new("A0\r") : Standard(c));
        await using var adapter = new ElmWifiDiagnosticAdapter("127.0.0.1", server.Port);
        try { await adapter.ConnectAsync(CancellationToken.None); throw new InvalidOperationException("Failed vehicle initialization accepted."); }
        catch (IOException error) { Expect(error.Message.Contains("0100:") && !error.Message.Contains("neacceptat"), "Report the failed vehicle request, not an unsupported protocol."); }
        Expect(!adapter.IsConnected && !server.Commands.Contains("ATDPN"), "Do not query protocol after failed ECU initialization.");
    }
    await using (var server = new FakeElmServer(c => c == "ATDPN" ? new("A0\r") : Standard(c)))
    await using (var adapter = new ElmWifiDiagnosticAdapter("127.0.0.1", server.Port))
    {
        try { await adapter.ConnectAsync(CancellationToken.None); throw new InvalidOperationException("Automatic protocol 0 accepted as connected."); }
        catch (IOException error) { Expect(error.Message.Contains("ATDPN: A0"), "A0 means protocol has not been detected."); }
        Expect(!adapter.IsConnected, "A0 must not fabricate an active protocol.");
    }
    Pass("Hardware-log regression: UNABLE TO CONNECT/NO DATA are vehicle initialization failures; A0 is undetected automatic mode.");

    await using (var server = new FakeElmServer(c => Standard(c, 6, true)))
    await using (var adapter = new ElmWifiDiagnosticAdapter("127.0.0.1", server.Port))
    {
        await adapter.ConnectAsync(CancellationToken.None); var live = await adapter.ReadLiveAsync(CancellationToken.None);
        Expect(server.Commands.Contains("0120") && server.Commands.Contains("0140") && server.Commands.Contains("0142") && !server.Commands.Contains("ATRV"), "Extended PID detection.");
        Expect(live.Voltage == 14 && live.VoltageSource == "Tensiune ECU", "ECU voltage formula/source.");
    }
    Pass("Supported PID bitmaps across 00/20/40 and distinction between ECU voltage and adapter voltage.");

    await using (var server = new FakeElmServer(c => c is "03" or "07" or "0A" ? new("NO DATA\r") : Standard(c)))
    await using (var adapter = new ElmWifiDiagnosticAdapter("127.0.0.1", server.Port))
    {
        await adapter.ConnectAsync(CancellationToken.None); var scan = await adapter.ScanAsync(CancellationToken.None);
        Expect(scan.Count == 1 && !scan[0].IsComplete && scan[0].Faults.Count == 0 && scan[0].ReadNote!.Contains("fără răspuns"), "NO DATA is not a clean scan.");
        var report = DiagnosticReport.ToCsv(scan, DateTimeOffset.Now); Expect(report.Contains("Citire incompleta") && !report.Contains("Fara erori"), "Incomplete CSV cannot claim no errors.");
    }
    await using (var server = new FakeElmServer(c => c == "010C" ? new(Frame("7E9", 0x41, 0x0C, 0x20, 0)) : c == "010D" ? new("NO DATA\r") : Standard(c)))
    await using (var adapter = new ElmWifiDiagnosticAdapter("127.0.0.1", server.Port))
    {
        await adapter.ConnectAsync(CancellationToken.None); var live = await adapter.ReadLiveAsync(CancellationToken.None);
        Expect(live.Rpm is null && live.SpeedKph is null && live.CoolantCelsius == 90, "Never invent a zero or borrow another ECU's live value.");
    }
    Pass("NO DATA yields incomplete diagnostics; unavailable live values remain null and ECUs are never mixed.");

    await using (var server = new FakeElmServer(c => c == "03" ? new("7E8", Prompt: false) : Standard(c)))
    await using (var adapter = new ElmWifiDiagnosticAdapter("127.0.0.1", server.Port, TimeSpan.FromMilliseconds(100)))
    {
        await adapter.ConnectAsync(CancellationToken.None); await Fails<TimeoutException>(() => adapter.ScanAsync(CancellationToken.None));
        Expect(!adapter.IsConnected, "A timed-out partial reply invalidates the connection.");
    }
    await using (var server = new FakeElmServer(c => c == "03" ? new("", Prompt: false) : Standard(c)))
    await using (var adapter = new ElmWifiDiagnosticAdapter("127.0.0.1", server.Port))
    {
        await adapter.ConnectAsync(CancellationToken.None); using var cancel = new CancellationTokenSource(TimeSpan.FromMilliseconds(80));
        await Fails<OperationCanceledException>(() => adapter.ScanAsync(cancel.Token)); Expect(!adapter.IsConnected, "Cancelled reply drops TCP connection.");
    }
    await using (var server = new FakeElmServer(_ => new("7E8", Prompt: false, Close: true)))
    await using (var wire = new ElmTcpConnection("127.0.0.1", server.Port))
    {
        await wire.OpenAsync(CancellationToken.None); await Fails<IOException>(() => wire.ExchangeAsync("010C", CancellationToken.None)); Expect(!wire.IsOpen, "EOF invalidates session.");
    }
    Pass("Fragmented prompts, request timeouts, cancellation and remote EOF invalidate the session instead of reusing stale bytes.");

    await using (var server = new FakeElmServer(c => new(c + "-REPLY\r", FragmentSize: 1)))
    await using (var wire = new ElmTcpConnection("127.0.0.1", server.Port))
    {
        await wire.OpenAsync(CancellationToken.None);
        var responses = await Task.WhenAll(wire.ExchangeAsync("ATI", CancellationToken.None), wire.ExchangeAsync("ATRV", CancellationToken.None));
        Expect(responses[0].Contains("ATI-REPLY") && responses[1].Contains("ATRV-REPLY"), "Concurrent calls must not consume each other's bytes.");
        for (var i = 0; i < 105; i++) await wire.ExchangeAsync("ATI", CancellationToken.None);
        Expect(wire.RecentTraffic.Count == 100, "Communication log must be bounded.");
    }
    await using (var server = new FakeElmServer(_ => new(new string('X', 33000))))
    await using (var wire = new ElmTcpConnection("127.0.0.1", server.Port))
    {
        await wire.OpenAsync(CancellationToken.None); await Fails<InvalidDataException>(() => wire.ExchangeAsync("ATI", CancellationToken.None)); Expect(!wire.IsOpen, "Oversized input rejected.");
    }
    await Fails<ArgumentException>(() => Task.FromResult(new ElmTcpConnection("not-an-ip", 35000)));
    await Fails<ArgumentOutOfRangeException>(() => Task.FromResult(new ElmTcpConnection("127.0.0.1", 0)));
    Pass("Serialized commands, bounded traffic log, oversized-response rejection and endpoint validation.");

    Console.WriteLine($"SUCCESS: {groups.Count} OBD integration groups passed.");
    var output = Environment.GetEnvironmentVariable("CCR_TEST_ARTIFACTS");
    if (!string.IsNullOrWhiteSpace(output)) { Directory.CreateDirectory(output); await File.WriteAllTextAsync(Path.Combine(output, "obd-tests.txt"), string.Join(Environment.NewLine, groups.Select(x => "PASS " + x)) + Environment.NewLine); }
    return 0;
}
catch (Exception error) { Console.Error.WriteLine(error); return 1; }
