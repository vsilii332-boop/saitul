using System.Globalization;
using System.Text;

namespace CCR.Core;

public static class DiagnosticReport
{
    public static string ToCsv(IEnumerable<DiagnosticModule> modules, DateTimeOffset createdAt, string? vin = null)
    {
        var rows = modules.ToArray();
        var simulation = rows.All(m => m.IsSimulated);
        var text = new StringBuilder();
        text.AppendLine(simulation ? "\"CCR\",\"RAPORT DE SIMULARE - FARA VEHICUL REAL\"" : "\"CCR\",\"RAPORT OBD-II - DOAR CITIRE; NU ESTE O SCANARE COMPLETA A VEHICULULUI\"");
        text.AppendLine($"\"Data\",{Cell(createdAt.ToString("O", CultureInfo.InvariantCulture))}");
        if (!simulation) text.AppendLine($"\"VIN\",{Cell(vin ?? "Indisponibil")}");
        text.AppendLine("\"Modul\",\"Cod DTC\",\"Descriere\",\"Stare\"");
        foreach (var module in rows)
        {
            if (module.Faults.Count == 0) text.AppendLine($"{Cell(module.Name)},\"\",{Cell(!module.IsComplete ? "Citire incompleta" : module.IsSimulated ? "Fara erori" : "Fara coduri memorate")},{Cell(module.IsSimulated ? "SIMULARE" : "OBD-II")}");
            foreach (var fault in module.Faults) text.AppendLine($"{Cell(module.Name)},{Cell(fault.Code)},{Cell(fault.Description)},{Cell(fault.Status)}");
            if (!string.IsNullOrWhiteSpace(module.ReadNote)) text.AppendLine($"{Cell(module.Name)},\"NOTA\",{Cell(module.ReadNote)},\"ACOPERIRE\"");
        }
        return text.ToString();
    }

    private static string Cell(string value)
    {
        // Keep spreadsheet applications from interpreting external text as a formula.
        if (value.TrimStart().FirstOrDefault() is '=' or '+' or '-' or '@') value = "'" + value;
        return "\"" + value.Replace("\"", "\"\"") + "\"";
    }
}
