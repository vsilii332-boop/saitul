using System.Text;
using Avalonia.Controls;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using CCR.Core;
using CCR.Core.Elm;
using CCR.Desktop.ViewModels;

namespace CCR.Desktop;

public partial class MainWindow : Window
{
    private readonly DispatcherTimer _liveTimer;
    public WorkspaceViewModel Workspace { get; }

    public MainWindow() : this(new SimulatedDiagnosticAdapter(), null, settings => settings.UseWifi ? new ElmWifiDiagnosticAdapter(settings.Host, settings.Port) : new SimulatedDiagnosticAdapter()) { }

    public MainWindow(IDiagnosticAdapter adapter, Func<string, Task<bool>>? saveReport = null, Func<ConnectionSettings, IDiagnosticAdapter>? adapterFactory = null)
    {
        InitializeComponent();
        Workspace = new(adapter, saveReport ?? SaveReportAsync, adapterFactory);
        DataContext = Workspace;
        _liveTimer = new() { Interval = TimeSpan.FromMilliseconds(750) };
        _liveTimer.Tick += async (_, _) => await Workspace.RefreshLiveAsync();
        Opened += (_, _) => _liveTimer.Start();
        Closed += async (_, _) => { _liveTimer.Stop(); await Workspace.DisposeAsync(); };
    }

    private async Task<bool> SaveReportAsync(string content)
    {
        var file = await StorageProvider.SaveFilePickerAsync(new()
        {
            Title = Workspace.IsSimulation ? "Exportă raportul de simulare CCR" : "Exportă raportul OBD-II CCR",
            SuggestedFileName = $"CCR-{(Workspace.IsSimulation ? "simulare" : "OBD")}-{DateTime.Now:yyyyMMdd-HHmmss}.csv",
            DefaultExtension = "csv",
            FileTypeChoices = [new("Fișier CSV") { Patterns = ["*.csv"] }],
            ShowOverwritePrompt = true
        });
        if (file is null) return false;
        await using var stream = await file.OpenWriteAsync();
        if (stream.CanSeek) stream.SetLength(0);
        using var writer = new StreamWriter(stream, new UTF8Encoding(true));
        await writer.WriteAsync(content);
        return true;
    }
}
