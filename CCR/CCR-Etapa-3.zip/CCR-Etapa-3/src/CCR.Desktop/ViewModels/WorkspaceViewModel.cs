using System.Collections.ObjectModel;
using System.Globalization;
using System.Net;
using CCR.Core;

namespace CCR.Desktop.ViewModels;

public sealed record SessionEntry(string Time, string Action, string Detail);

public sealed class WorkspaceViewModel : ObservableObject, IAsyncDisposable
{
    private IDiagnosticAdapter _adapter;
    private readonly Func<ConnectionSettings, IDiagnosticAdapter>? _adapterFactory;
    private readonly Func<string, Task<bool>> _saveReport;
    private readonly CancellationTokenSource _lifetime = new();
    private CancellationTokenSource? _operation;
    private string _currentPage = "overview", _status = "Pregătit. Alege simulatorul sau adaptorul Wi-Fi din setări.";
    private string _wifiHost = "192.168.0.10", _wifiPort = "35000";
    private int _selectedConnectionMode;
    private bool _connected, _busy, _isLive, _confirmation, _disposed, _polling;
    private DiagnosticModule? _selectedModule;
    private LiveSnapshot? _live;
    private IReadOnlyList<double> _rpmHistory = [];
    private CancellationToken OperationToken => _operation?.Token ?? _lifetime.Token;

    public WorkspaceViewModel(IDiagnosticAdapter adapter, Func<string, Task<bool>> saveReport, Func<ConnectionSettings, IDiagnosticAdapter>? adapterFactory = null)
    {
        _adapter = adapter; _saveReport = saveReport; _adapterFactory = adapterFactory;
        NavigateCommand = new(p => CurrentPage = p as string ?? "overview");
        ConnectCommand = new(() => RunAsync("Conectare…", ConnectAsync), () => CanEditConnection && IsConnectionInputValid, HandleError);
        DisconnectCommand = new(() => RunAsync("Deconectare…", DisconnectAsync), () => IsConnected && !IsBusy, HandleError);
        ScanCommand = new(() => RunAsync(IsSimulation ? "Scanare module demonstrative…" : "Citire coduri OBD-II…", ScanAsync), () => IsConnected && !IsBusy, HandleError);
        CancelOperationCommand = new(_ => _operation?.Cancel(), () => IsBusy && _operation is not null);
        RequestClearCommand = new(_ => ConfirmationVisible = true, () => IsConnected && !IsBusy && _adapter.CanClearFaults && Faults.Count > 0);
        CancelClearCommand = new(_ => ConfirmationVisible = false, () => !IsBusy);
        ConfirmClearCommand = new(() => RunAsync("Ștergere erori din simulare…", ClearAsync), () => ConfirmationVisible && IsConnected && !IsBusy && _adapter.CanClearFaults, HandleError);
        ToggleLiveCommand = new(_ => { IsLive = !IsLive; Log(IsLive ? "Date live pornite" : "Date live oprite", IsSimulation ? "Valori generate local de simulator." : "Citire PID-uri suportate de ECU-ul OBD-II."); }, () => IsConnected && !IsBusy);
        ExportCommand = new(() => RunAsync("Pregătire raport CSV…", ExportAsync), () => Modules.Count > 0 && !IsBusy, HandleError);
        Log("Aplicație pornită", "CCR 0.2.0 · simulator și citire OBD-II prin ELM327 Wi-Fi.");
    }

    public ObservableCollection<DiagnosticModule> Modules { get; } = [];
    public ObservableCollection<DiagnosticFault> Faults { get; } = [];
    public ObservableCollection<SessionEntry> History { get; } = [];
    public IReadOnlyList<string> ConnectionModes { get; } = ["Simulator (demo)", "ELM327 Wi-Fi (citire reală)"];
    public RelayCommand NavigateCommand { get; }
    public AsyncCommand ConnectCommand { get; }
    public AsyncCommand DisconnectCommand { get; }
    public AsyncCommand ScanCommand { get; }
    public RelayCommand CancelOperationCommand { get; }
    public RelayCommand RequestClearCommand { get; }
    public RelayCommand CancelClearCommand { get; }
    public AsyncCommand ConfirmClearCommand { get; }
    public RelayCommand ToggleLiveCommand { get; }
    public AsyncCommand ExportCommand { get; }

    public int SelectedConnectionMode
    {
        get => _selectedConnectionMode;
        set
        {
            if (value is < 0 or > 1 || !CanEditConnection || !Set(ref _selectedConnectionMode, value)) return;
            Modules.Clear(); SelectedModule = null; UpdateCounts(); ResetReadings(); NotifyContext(); RefreshCommands();
        }
    }
    public bool UseWifi => SelectedConnectionMode == 1;
    public string WifiHost { get => _wifiHost; set { if (CanEditConnection && Set(ref _wifiHost, value)) { Notify(nameof(ConnectionInputHint)); RefreshCommands(); } } }
    public string WifiPort { get => _wifiPort; set { if (CanEditConnection && Set(ref _wifiPort, value)) { Notify(nameof(ConnectionInputHint)); RefreshCommands(); } } }
    public bool CanEditConnection => !_disposed && !IsConnected && !IsBusy;
    public bool IsConnectionInputValid => !UseWifi || (IPAddress.TryParse(WifiHost.Trim(), out _) && int.TryParse(WifiPort, out var port) && port is >= 1 and <= 65535);
    public string ConnectionInputHint => !IsConnectionInputValid ? "Introdu un IP valid și un port între 1 și 65535." : UseWifi ? "Valorile sunt un exemplu. Folosește IP-ul și portul din manualul adaptorului tău." : "Simulator local. Nu necesită adaptor sau conexiune la o mașină.";
    public bool IsSimulation => IsConnected ? _adapter.IsSimulated : !UseWifi;
    public string BadgeText => IsSimulation ? "DEMO · FĂRĂ VEHICUL" : "WI-FI · DOAR CITIRE";
    public string ConnectButtonLabel => IsSimulation ? "Conectează simulatorul" : "Conectează adaptorul Wi-Fi";
    public string ScanButtonLabel => IsSimulation ? "Scanează vehiculul demo" : "Citește codurile OBD-II";
    public string HeroTitle => IsSimulation ? "Cunoaște mașina. Înțelege datele." : "Conectează adaptorul. Citește datele.";
    public string HeroDescription => IsSimulation ? "Testează fluxul de lucru cu un vehicul demonstrativ. Datele sunt generate local și nu provin de la mașina ta." : "Citire OBD-II standard prin ELM327 Wi-Fi. Alege adaptorul, IP-ul și portul în Conexiune și setări.";
    public string ModuleCountCaption => IsSimulation ? "Calculatoare demonstrative" : "ECU-uri care au răspuns la OBD-II";
    public string FaultCountCaption => IsSimulation ? "Exemple DTC · simulare" : "Coduri citite · vezi notele modulelor";
    public string VehicleTitle => IsSimulation ? "Renault Clio II" : "Vehicul OBD-II";
    public string VehicleSubtitle => IsSimulation ? "2004 · 1.2 16V · profil de simulare" : "Marca, modelul și motorul nu sunt deduse automat din răspunsurile OBD-II.";
    public string VinText => IsSimulation ? "VIN: indisponibil în simulare" : "VIN: " + (IsConnected ? _adapter.Vin ?? "indisponibil" : "necitit");
    public string AdapterIdentity => IsConnected ? _adapter.AdapterName : IsSimulation ? "Simulator CCR" : "ELM327 Wi-Fi";
    public string ProtocolText => IsConnected ? _adapter.ProtocolName : "Nedetectat";
    public string ScopeNote => IsSimulation ? "Rezultatele de mai jos aparțin exclusiv simulatorului CCR." : "Doar OBD-II standard. Nu reprezintă o scanare completă ABS, airbag sau UCH. Ștergerea pe vehicul nu este activată în această etapă.";
    public string LiveDescription => IsSimulation ? "Valori generate de simulator. Actualizare la aproximativ 750 ms." : "PID-uri citite de la primul ECU OBD-II detectat. Ritmul depinde de adaptor; valorile nesuportate sau fără răspuns apar ca —.";
    public string MeasurementSuffix => IsSimulation ? " · demo" : "";
    public string RpmUnit => "rpm" + MeasurementSuffix;
    public string SpeedUnit => "km/h" + MeasurementSuffix;
    public string CoolantUnit => "°C" + MeasurementSuffix;
    public string VoltageUnit => "V" + MeasurementSuffix;
    public string VoltageSource => _live?.VoltageSource ?? (IsSimulation ? "Tensiune · demo" : "Tensiune");
    public string ChartNote => "Ultimele 60 de valori RPM valide" + (IsSimulation ? " din simulator." : " citite de la ECU. Lipsa răspunsului nu este înlocuită cu zero.");
    public string TrafficText => string.Join(Environment.NewLine, _adapter.RecentTraffic.TakeLast(20).Select(t => $"{t.Time:HH:mm:ss}  → {t.Command}  ({t.Milliseconds} ms)\n← {t.Response.Trim().Replace('\r', '\n')[..Math.Min(700, t.Response.Trim().Length)]}"));

    public string CurrentPage
    {
        get => _currentPage;
        set
        {
            if (value is not ("overview" or "diagnostics" or "live" or "service" or "programming" or "history" or "settings")) return;
            if (!Set(ref _currentPage, value)) return;
            foreach (var name in new[] { nameof(PageTitle), nameof(IsOverview), nameof(IsDiagnostics), nameof(IsLivePage), nameof(IsService), nameof(IsProgramming), nameof(IsHistory), nameof(IsSettings) }) Notify(name);
        }
    }
    public string PageTitle => CurrentPage switch { "diagnostics"=>"Diagnoză", "live"=>"Date live", "service"=>"Operațiuni service", "programming"=>"Programare", "history"=>"Istoric sesiune", "settings"=>"Conexiune și setări", _=>"Prezentare generală" };
    public bool IsOverview => CurrentPage == "overview";
    public bool IsDiagnostics => CurrentPage == "diagnostics";
    public bool IsLivePage => CurrentPage == "live";
    public bool IsService => CurrentPage == "service";
    public bool IsProgramming => CurrentPage == "programming";
    public bool IsHistory => CurrentPage == "history";
    public bool IsSettings => CurrentPage == "settings";
    public bool IsConnected { get => _connected; private set { if (Set(ref _connected, value)) { Notify(nameof(IsDisconnected)); Notify(nameof(ConnectionLabel)); Notify(nameof(CanEditConnection)); NotifyContext(); RefreshCommands(); } } }
    public bool IsDisconnected => !IsConnected;
    public bool IsBusy { get => _busy; private set { if (Set(ref _busy, value)) { Notify(nameof(CanEditConnection)); RefreshCommands(); } } }
    public bool IsLive { get => _isLive; private set { if (Set(ref _isLive, value)) Notify(nameof(LiveButtonLabel)); } }
    public string LiveButtonLabel => IsLive ? "Oprește datele live" : "Pornește datele live";
    public bool ConfirmationVisible { get => _confirmation; private set { if (Set(ref _confirmation, value)) RefreshCommands(); } }
    public string ConnectionLabel => IsConnected ? IsSimulation ? "Simulator conectat" : "Adaptor Wi-Fi conectat" : "Deconectat";
    public string Status { get => _status; private set => Set(ref _status, value); }
    public int ModuleCount => Modules.Count;
    public int FaultCount => Modules.Sum(x => x.Faults.Count);
    public bool HasModules => Modules.Count > 0;
    public bool HasNoModules => !HasModules;
    public bool HasFaults => Faults.Count > 0;
    public bool HasNoFaults => !HasFaults && SelectedModule?.IsComplete == true;
    public bool HasModuleNote => !string.IsNullOrWhiteSpace(ModuleReadNote);
    public string ModuleReadNote => SelectedModule?.ReadNote ?? "";
    public string SelectedModuleName => SelectedModule?.Name ?? "Alege un modul după scanare";
    public string EmptyFaultsText => IsSimulation ? "Nu sunt erori în acest modul demonstrativ." : "Nu au fost citite coduri memorate. Verifică și notele despre celelalte stări.";
    public DiagnosticModule? SelectedModule
    {
        get => _selectedModule;
        set { if (!Set(ref _selectedModule, value)) return; UpdateFaults(); Notify(nameof(SelectedModuleName)); }
    }
    public string RpmText => _live?.Rpm?.ToString(CultureInfo.InvariantCulture) ?? "—";
    public string SpeedText => _live?.SpeedKph?.ToString(CultureInfo.InvariantCulture) ?? "—";
    public string CoolantText => _live?.CoolantCelsius?.ToString(CultureInfo.InvariantCulture) ?? "—";
    public string VoltageText => _live?.Voltage?.ToString("F2", CultureInfo.GetCultureInfo("ro-RO")) ?? "—";
    public IReadOnlyList<double> RpmHistory { get => _rpmHistory; private set => Set(ref _rpmHistory, value); }

    private async Task ConnectAsync()
    {
        if (_adapterFactory is not null)
        {
            await _adapter.DisposeAsync();
            _adapter = _adapterFactory(new(UseWifi, WifiHost.Trim(), UseWifi ? int.Parse(WifiPort, CultureInfo.InvariantCulture) : 0));
        }
        await _adapter.ConnectAsync(OperationToken);
        IsConnected = true; ResetReadings();
        Status = IsSimulation ? "Simulator conectat. Poți începe scanarea demonstrativă." : "Adaptor și ECU OBD-II conectate. Citirea este disponibilă.";
        Log("Conectare", AdapterIdentity + " · " + ProtocolText);
    }
    private async Task DisconnectAsync()
    {
        IsLive = false; await _adapter.DisconnectAsync(); ResetConnection();
        Status = "Conexiune închisă."; Log("Deconectare", "Datele active au fost eliminate din interfață.");
    }
    private async Task ScanAsync()
    {
        ReplaceModules(await _adapter.ScanAsync(OperationToken)); CurrentPage = "diagnostics";
        Status = IsSimulation ? $"Scanare demo finalizată: {ModuleCount} module, {FaultCount} erori." : Modules.Any(m => !m.IsComplete) ? "Citire OBD-II incompletă. Verifică notele modulelor." : $"Citire OBD-II finalizată: {ModuleCount} ECU-uri, {FaultCount} coduri citite.";
        Log(IsSimulation ? "Scanare" : "Citire OBD-II", $"{ModuleCount} module · {FaultCount} coduri. " + (IsSimulation ? "Simulare." : "Acoperire OBD-II standard, doar citire."));
    }
    private async Task ClearAsync()
    {
        var module = SelectedModule ?? throw new InvalidOperationException("Alege mai întâi un modul.");
        try
        {
            await _adapter.ClearFaultsAsync(module.Id, OperationToken);
            ReplaceModules(await _adapter.ScanAsync(OperationToken), module.Id);
            Status = "Erorile modulului au fost șterse din simulare.";
            Log("Ștergere DTC · demo", module.Name + " · nu a fost trimisă nicio comandă unui vehicul.");
        }
        finally { ConfirmationVisible = false; }
    }
    private async Task ExportAsync()
    {
        var saved = await _saveReport(DiagnosticReport.ToCsv(Modules, DateTimeOffset.Now, IsSimulation ? null : _adapter.Vin));
        Status = saved ? "Raportul a fost exportat." : "Export anulat.";
        if (saved) Log("Export CSV", IsSimulation ? "Raport de simulare salvat." : "Raport OBD-II salvat în locația aleasă.");
    }
    private async Task RunAsync(string status, Func<Task> action)
    {
        if (_disposed || IsBusy) return;
        using var operation = CancellationTokenSource.CreateLinkedTokenSource(_lifetime.Token);
        _operation = operation; IsBusy = true; Status = status;
        try { await action(); }
        catch (OperationCanceledException) when (operation.IsCancellationRequested) { if (!_disposed) { Status = "Operațiune anulată."; ResetIfLost(); } }
        finally { _operation = null; IsBusy = false; Notify(nameof(TrafficText)); }
    }
    public async Task RefreshLiveAsync()
    {
        if (_disposed || !IsConnected || !IsLive || IsBusy || _polling) return;
        _polling = true;
        try
        {
            var value = await _adapter.ReadLiveAsync(_lifetime.Token);
            if (_disposed || !IsConnected || !IsLive) return;
            _live = value;
            if (value.Rpm.HasValue) RpmHistory = RpmHistory.Append((double)value.Rpm.Value).TakeLast(60).ToArray();
            NotifyReadings();
            if (!IsSimulation && value.Rpm is null && value.SpeedKph is null && value.CoolantCelsius is null) Status = "Nu există răspunsuri valide pentru parametrii solicitați. Valorile indisponibile apar ca —.";
        }
        catch (OperationCanceledException) { }
        catch (Exception error) { var active = IsLive; IsLive = false; if (active && !_disposed) HandleError(error); }
        finally { _polling = false; Notify(nameof(TrafficText)); }
    }
    private void ReplaceModules(IReadOnlyList<DiagnosticModule> modules, string? selectedId = null)
    {
        Modules.Clear(); foreach (var module in modules) Modules.Add(module);
        SelectedModule = Modules.FirstOrDefault(x => x.Id == selectedId) ?? Modules.FirstOrDefault(); UpdateCounts();
    }
    private void UpdateFaults()
    {
        Faults.Clear(); foreach (var fault in SelectedModule?.Faults ?? []) Faults.Add(fault);
        foreach (var name in new[] { nameof(HasFaults), nameof(HasNoFaults), nameof(HasModuleNote), nameof(ModuleReadNote), nameof(EmptyFaultsText) }) Notify(name);
        RefreshCommands();
    }
    private void UpdateCounts() { Notify(nameof(ModuleCount)); Notify(nameof(FaultCount)); Notify(nameof(HasModules)); Notify(nameof(HasNoModules)); RefreshCommands(); }
    private void ResetReadings() { _live = null; RpmHistory = []; NotifyReadings(); }
    private void NotifyReadings() { foreach (var name in new[] { nameof(RpmText), nameof(SpeedText), nameof(CoolantText), nameof(VoltageText), nameof(VoltageSource) }) Notify(name); }
    private void NotifyContext()
    {
        foreach (var name in new[] { nameof(UseWifi), nameof(IsSimulation), nameof(BadgeText), nameof(ConnectButtonLabel), nameof(ScanButtonLabel), nameof(HeroTitle), nameof(HeroDescription), nameof(ModuleCountCaption), nameof(FaultCountCaption), nameof(VehicleTitle), nameof(VehicleSubtitle), nameof(VinText), nameof(AdapterIdentity), nameof(ProtocolText), nameof(ScopeNote), nameof(LiveDescription), nameof(RpmUnit), nameof(SpeedUnit), nameof(CoolantUnit), nameof(VoltageUnit), nameof(VoltageSource), nameof(ChartNote), nameof(ConnectionInputHint), nameof(TrafficText) }) Notify(name);
    }
    private void RefreshCommands()
    {
        ConnectCommand?.Refresh(); DisconnectCommand?.Refresh(); ScanCommand?.Refresh(); CancelOperationCommand?.Refresh(); RequestClearCommand?.Refresh(); CancelClearCommand?.Refresh(); ConfirmClearCommand?.Refresh(); ToggleLiveCommand?.Refresh(); ExportCommand?.Refresh();
    }
    private void Log(string action, string detail) { History.Insert(0, new(DateTimeOffset.Now.ToString("HH:mm:ss"), action, detail)); while (History.Count > 200) History.RemoveAt(History.Count - 1); }
    private void ResetConnection() { IsLive = false; IsConnected = false; ConfirmationVisible = false; Modules.Clear(); SelectedModule = null; UpdateFaults(); ResetReadings(); UpdateCounts(); }
    private void ResetIfLost() { if (IsConnected && !_adapter.IsConnected) ResetConnection(); }
    private void HandleError(Exception error) { ResetIfLost(); Status = "Operațiunea nu a reușit: " + error.Message; Log("Eroare", error.Message); Notify(nameof(TrafficText)); }
    public async ValueTask DisposeAsync()
    {
        if (_disposed) return; _disposed = true; IsLive = false; _lifetime.Cancel();
        await _adapter.DisposeAsync(); IsConnected = false; _lifetime.Dispose();
    }
}
