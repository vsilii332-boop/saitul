# CCR · Car Control & Repair

**Etapa 3 · versiunea 0.2.0 · ELM327 Wi-Fi și citire OBD-II standard**

Aplicație pentru macOS Apple Silicon, cu C# / .NET 10 și Avalonia 12.1.5.
Pachetul conține sursele complete, testele și dependențele fixate în fișiere lock.

## Pornirea pe Mac

1. Închide versiunea CCR anterioară.
2. Dezarhivează pachetul în Downloads. Folderul rezultat este `CCR-Etapa-3`.
3. Cu Macul conectat la internet, execută în Terminal:

```bash
cd ~/Downloads/CCR-Etapa-3 && dotnet run --project src/CCR.Desktop/CCR.Desktop.csproj
```

Prima pornire descarcă pachetele necesare. Păstrează separat folderul etapei 2;
nu este nevoie să înlocuiești fișiere în el. Versiunea nouă afișează **CCR 0.2.0**
și **Etapa 3** în meniul din stânga.

După prima compilare, poți porni aplicația fără restaurarea pachetelor, util
când Macul este conectat la rețeaua adaptorului și nu mai are internet:

```bash
cd ~/Downloads/CCR-Etapa-3 && dotnet run --no-restore --project src/CCR.Desktop/CCR.Desktop.csproj
```

## Conectarea unui ELM327 Wi-Fi

1. Deschide întâi CCR, cât timp ai internet pentru compilare.
2. Cu mașina staționată, conectează adaptorul la mufa OBD și pune contactul.
   Prima verificare se poate face cu motorul oprit.
3. Conectează Macul la rețeaua Wi-Fi a adaptorului, conform instrucțiunilor sale.
   Numele poate conține OBD, ELM, WiFi_OBD sau o denumire a producătorului.
4. În CCR: **Conexiune și setări → ELM327 Wi-Fi (citire reală)**.
5. Introdu adresa IP și portul TCP ale adaptorului. **192.168.0.10 / 35000 sunt
   exemple frecvente, nu valori confirmate pentru adaptorul tău.** Pot fi modificate.
6. Apasă **Conectează adaptorul Wi-Fi**. Un socket TCP deschis nu este suficient:
   CCR verifică inițializarea ELM și un răspuns OBD-II valid de la cel puțin un ECU.
7. După conectare, apasă **Citește codurile OBD-II**, apoi poți porni **Date live**.

Setările IP/port pot fi schimbate când adaptorul este deconectat. Ele sunt
momentan păstrate în sesiune, nu într-un fișier permanent. **Anulează** întrerupe
conectarea sau citirea în curs; după un schimb întrerupt, TCP se închide pentru
a nu confunda răspunsurile vechi cu o comandă nouă.

### Dacă IP-ul și portul nu sunt cunoscute

După conectarea Macului la Wi-Fi-ul adaptorului, poți vedea ruta activă:

```bash
route -n get default
```

Rândurile `gateway` și `interface` ajută la identificarea rețelei. Gateway-ul
este un indiciu, nu o dovadă că acela este serverul ELM. Portul TCP nu se poate
deduce din această comandă. Îl verificăm cu manualul adaptorului sau printr-un
test de conexiune la o adresă și un port indicate. Aplicația nu scanează automat
rețele sau porturi. Dacă Macul pierde internetul pe Wi-Fi-ul adaptorului, poți
copia rezultatul, reconecta rețeaua cu internet și abia apoi îl poți trimite.

## Ce implementează versiunea aceasta

- Simulatorul local din etapa 2 rămâne disponibil și este marcat **DEMO**.
- Conexiune TCP reală către o adresă IP/port introduse de utilizator.
- Inițializare ELM327, detectarea automată a protocolului prin adaptor și citirea
  identității adaptorului. Protocoale: ISO 9141-2, ISO 14230-4 KWP și CAN
  ISO 15765-4; parserul include și J1850 PWM/VPW.
- Detectarea ECU-urilor care răspund la cererile OBD-II standard. Nu este o
  scanare completă a rețelei proprietare a mașinii.
- Citirea codurilor memorate (03), în așteptare (07) și permanente (0A), atunci
  când ECU le acceptă. Stările aceluiași cod sunt păstrate împreună.
- Decodarea formatului DTC și un set mic de descrieri generice locale. Codurile
  necunoscute sunt afișate ca atare, fără descrieri inventate.
- VIN prin modul 09/PID 02, când vehiculul îl furnizează. VIN-ul nu este folosit
  pentru a ghici automat marca, anul sau motorizarea.
- Date live de la primul ECU OBD-II detectat: RPM (0C), viteză (0D), temperatură
  lichid răcire (05) și tensiune ECU (42) dacă PID-ul este suportat. În lipsa
  suportului pentru 42 se încearcă tensiunea măsurată de adaptor prin ATRV;
  interfața afișează sursa tensiunii.
- Grafic RPM cu ultimele 60 de valori valide. PID-urile nesuportate sau fără
  răspuns apar ca **—**. Zero este afișat numai când este citit ca valoare reală.
- Raport CSV distinct pentru simulare și pentru OBD-II real, cu note despre
  citirile incomplete și modurile fără răspuns. `NO DATA` nu înseamnă „fără erori”.
- Jurnalul ultimelor schimburi cu adaptorul și istoricul operațiilor, păstrate
  în memorie pe durata sesiunii. Jurnalul poate conține VIN; verifică-l înainte
  să îl distribui. Nu este trimis automat către un server.

## Ce nu este activat pe vehicul în această etapă

Conexiunea reală este **doar pentru citire**. Nu se trimit modul 04, resetări
service, teste active, codări, programare de chei sau flash ECU. Butonul de
ștergere funcționează în continuare numai în simulator, cu confirmare.

ABS, airbag, UCH și funcțiile Renault/Dacia specifice au nevoie de protocoale și
profiluri separate. Compatibilitatea cu fiecare clonă ELM și fiecare ECU nu
poate fi garantată din versiunea declarată de adaptor. Bluetooth și USB nu sunt
încă implementate. Meniurile Service și Programare rămân etape viitoare.

Profilul Clio II este vizibil numai în simulator. La selectarea modului Wi-Fi,
interfața folosește eticheta generică „Vehicul OBD-II”, fără date de mașină
simulate. Pierderea conexiunii nu activează automat simulatorul.

## Teste și limitele verificării

Compilare .NET 10 pe Linux, Avalonia Headless și servere ELM327 fictive legate
exclusiv la loopback. Au fost verificate:

- **12 grupuri de integrare a interfeței**: simulator, selecție Wi-Fi, validarea
  IP/port, folosirea driverului TCP, anulare, date lipsă, pierdere de conexiune,
  export și blocarea ștergerii reale.
- **7 grupuri OBD/TCP**: CAN 11/29 bit și DLC, DTC CAN versus protocoale vechi,
  ISO-TP/VIN, checksum ISO9141/KWP și CRC J1850, căi complete TCP pe 7 variante
  de protocol, PID-uri extinse, date lipsă și ECU-uri separate, fragmente TCP,
  timeout/anulare/EOF, limitarea dimensiunilor și serializarea comenzilor.

Aceste teste nu înlocuiesc o probă pe mașină. Nu a fost conectat un adaptor
fizic în mediul de dezvoltare. Validarea adaptorului concret și a vehiculului
se face pe Mac; erorile și jurnalul ne vor arăta eventualele diferențe de format.

Pentru compilare și teste:

```bash
dotnet build CCR.slnx -c Release
dotnet run --project tests/CCR.Obd.Tests/CCR.Obd.Tests.csproj
dotnet run --project tests/CCR.Desktop.Tests/CCR.Desktop.Tests.csproj
```

## Structură și date

- `src/CCR.Core` — contracte, simulator, transport ELM/TCP, parser OBD și CSV.
- `src/CCR.Desktop` — interfața Avalonia și starea sesiunii.
- `tests/CCR.Obd.Tests` — emulator ELM/TCP și teste pentru protocoale.
- `tests/CCR.Desktop.Tests` — teste ale ferestrei și comenzilor.

Nu sunt incluse conturi, credențiale, date de client sau loguri provenite de la
vehicule reale. VIN-ul din teste este un exemplu sintetic. Fișierele binare,
cache-urile NuGet și SDK-ul nu sunt incluse în arhivă. Dependențele și licențele
lor sunt prezentate în `THIRD-PARTY.md`.
